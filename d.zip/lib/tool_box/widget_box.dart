import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class WidgetBox {
  /// 색상 관련
  static Color colorStatusBar = Colors.cyan;
  static Color colorAppBar = Colors.cyan;
  static Color colorNavigationBar = Colors.cyan;
  static Color colorWidget = Colors.cyan;
  static Color colorDisabled = Colors.grey;

  /// 텍스트스타일 관련
  static TextStyle tsButton =
      TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold);

  static TextStyle tsDropdownItem =
      TextStyle(color: Colors.blue, fontSize: 19, fontWeight: FontWeight.bold);

  static TextStyle tsNormal = TextStyle(
      color: Colors.black87, fontSize: 15, fontWeight: FontWeight.bold);

  static TextStyle tsTileKey = TextStyle(
      color: Colors.black87, fontSize: 18, fontWeight: FontWeight.bold);

  static TextStyle tsTileValue = TextStyle(color: Colors.black45, fontSize: 16);

  /// Decoration 관련

  static InputDecoration decTextField(
    TextEditingController controller, {
    String labelText,
    String helperText,
    String hintText,
    String suffixText,
  }) {
    return InputDecoration(
      isDense: true,
      enabledBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Colors.grey),
        //  when the TextFormField in unfocused
      ),
      focusedBorder: UnderlineInputBorder(
        borderSide: BorderSide(color: Colors.blue, width: 2),
        //  when the TextFormField in focused
      ),
      border: UnderlineInputBorder(),
      hintText: hintText,
      helperText: helperText,
      labelText: labelText,
      suffixText: suffixText,
      suffix: InkWell(
        onTap: () {
          controller.clear();
        },
        child: Container(
          height: 30,
          width: 30,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(25),
          ),
          child: Icon(
            Icons.clear,
            color: Colors.grey,
            size: 20,
          ),
        ),
      ),
    );
  }

  /// AppBar

  static Widget appBar(String title) {
    return AppBar(
      title: Text(title),
      backgroundColor: colorAppBar,
      elevation: 0,
      // actions: [
      //   IconButton(icon: Icon(Icons.seven_k), onPressed: ()=>openAppSettings())
      // ],
    );
  }

  static Widget btBasic({
    String title = "btBasic",
    double height,
    double width,
    Color color,
    GestureTapCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 5.w, horizontal: 5.w),
        padding: EdgeInsets.symmetric(vertical: 5.w, horizontal: 5.w),
        height: height ?? 40.w,
        width: width ?? 60.w,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: (color != null)
              ? color
              : (onTap != null)
                  ? colorWidget
                  : colorDisabled,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          title,
          style: tsButton,
        ),
      ),
    );
  }

  static Widget btWideFull(String title,
      {double height = 70,
      Color color = Colors.blueAccent,
      GestureTapCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: height,
        decoration: BoxDecoration(
          color: (onTap != null) ? color : colorDisabled,
        ),
        alignment: Alignment.center,
        child: Text(title, style: tsButton),
      ),
    );
  }

  static Widget btWide(String title,
      {double height = 70,
      double width = 100,
      Color color = Colors.blueGrey,
      GestureTapCallback onTap}) {
    return Container(
      alignment: Alignment.center,
      margin: const EdgeInsets.symmetric(horizontal: 10),
      child: InkWell(
        onTap: onTap,
        child: Container(
          height: height,
          width: width,
          decoration: BoxDecoration(color: color),
          alignment: Alignment.center,
          child: Text(title, style: tsButton),
        ),
      ),
    );
  }

  static Widget keyItem(String key,
      {double marginVer = 0,
      double marginHor = 5,
      double fontSize,
      Color color}) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: marginVer,
        horizontal: marginHor,
      ),
      child: Text(
        key,
        style: tsTileKey.copyWith(fontSize: fontSize, color: color),
      ),
    );
  }

  static Widget valueItem(String value,
      {double marginVer = 0, double marginHor = 5, double fontSize}) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: marginVer,
        horizontal: marginHor,
      ),
      child: Text(
        value,
        style: tsTileValue.copyWith(fontSize: fontSize),
      ),
    );
  }

  static Widget itemTitle(String title) {
    return Container(
      padding: const EdgeInsets.only(left: 10, top: 15, bottom: 15),
      child: Text(
        title,
        style: TextStyle(
            fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
      ),
    );
  }

  static Widget tileItem(String key, String value,
      {VoidCallback onPressed,
      IconData iconData = Icons.chevron_right_rounded}) {
    return Container(
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 5, horizontal: 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      keyItem(key),
                      valueItem(value),
                    ],
                  ),
                ),
              ),
              (onPressed == null)
                  ? Container()
                  : IconButton(
                      icon: Icon(
                        iconData,
                        color: Colors.black87,
                      ),
                      onPressed: onPressed,
                    )
            ],
          ),
          Divider(),
        ],
      ),
    );
  }

  static Widget tileSearch(String key, TextEditingController controller,
      {VoidCallback onPressed,
      String labelText,
      String helperText,
      String hintText,
      String suffixText,
      TextInputType textInputType}) {
    return Container(
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  keyItem(key),
                  Container(
                    margin:
                        const EdgeInsets.symmetric(vertical: 7, horizontal: 10),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                              controller: controller,
                              style: tsTileValue,
                              decoration: decTextField(
                                controller,
                                labelText: labelText,
                                suffixText: suffixText,
                                helperText: helperText,
                                hintText: hintText,
                              ),
                              autofocus: true,
                              keyboardType: textInputType,
                              inputFormatters:
                                  (textInputType == TextInputType.number)
                                      ? <TextInputFormatter>[
                                          FilteringTextInputFormatter.allow(
                                              RegExp(r'[0-9]')),
                                        ]
                                      : null),
                        ),
                        Container(
                          width: 70,
                          margin: const EdgeInsets.only(left: 10),
                          child: RaisedButton(
                            padding: const EdgeInsets.all(0),
                            child: Text("검색"),
                            onPressed: onPressed,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  static Widget editItem(
    String key,
    TextEditingController controller, {
    VoidCallback onPressed,
    String labelText,
    String helperText,
    String hintText,
    String suffixText,
    TextInputType textInputType = TextInputType.text,
    double verPadding = 50,
    double horPadding = 20,
    ValueChanged<String> onChanged,
  }) {
    return Container(
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(
                  vertical: verPadding, horizontal: horPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  keyItem(key),
                  Container(
                    margin:
                        const EdgeInsets.symmetric(vertical: 7, horizontal: 10),
                    child: Column(
                      children: [
                        TextField(
                            controller: controller,
                            onChanged: onChanged,
                            style: tsTileValue,
                            decoration: decTextField(
                              controller,
                              labelText: labelText,
                              suffixText: suffixText,
                              helperText: helperText,
                              hintText: hintText,
                            ),
                            autofocus: true,
                            keyboardType: textInputType,
                            inputFormatters:
                                (textInputType == TextInputType.number)
                                    ? <TextInputFormatter>[
                                        FilteringTextInputFormatter.allow(
                                            RegExp(r'[0-9]')),
                                      ]
                                    : null),
                        (onPressed != null)
                            ? Container(
                                alignment: Alignment.center,
                                margin:
                                    const EdgeInsets.symmetric(vertical: 10),
                                child: btWideFull("확인", onTap: onPressed),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  static Widget tileItemVertical(
    String key,
    String value, {
    VoidCallback onPressed,
    IconData iconData = Icons.chevron_right_rounded,
    double keyWidget = 120,
  }) {
    return Container(
      padding: const EdgeInsets.only(top: 5, bottom: 5, right: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: keyWidget,
            child: Text(key, style: tsTileKey),
          ),
          Expanded(child: Text(value, style: tsTileValue)),
        ],
      ),
    );
  }

  static Widget loadingWidget(
      {String title = "LOADING", bool isShowing = true}) {
    return isShowing
        ? Container(
            alignment: Alignment.center,
            // padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: Color.fromRGBO(84, 84, 84, 50),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 15),
                  child: CircularProgressIndicator(),
                ),
                Container(
                  margin: const EdgeInsets.only(top: 15),
                  child: Text(
                    title,
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
              ],
            ),
          )
        : Container();
  }

  static Widget infoWidget({
    Widget child,
    double marginVer = 10,
    double marginHor = 10,
    double paddingLeft = 20,
    double paddingTop = 10,
    double paddingRight = 10,
    double paddingBottom = 10,
    Color color = Colors.white,
  }) {
    if (child == null) {
      child = Container();
    }
    return Container(
      margin: EdgeInsets.symmetric(vertical: marginVer, horizontal: marginHor),
      padding: EdgeInsets.only(
          left: paddingLeft,
          top: paddingTop,
          bottom: paddingBottom,
          right: paddingRight),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color,
        border: Border.all(color: Colors.grey[400], width: 1),
      ),
      child: child,
    );
  }

  /// 다이얼로그 관련
  static Future<bool> showTrueFalseDialog(
    BuildContext context,
    String title,
    String content, {
    String trueTitle = "예",
    String falseTitle = "아니오",
  }) async {
    bool result = await showDialog(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(content),
          actions: <Widget>[
            FlatButton(
              child: Text(trueTitle),
              onPressed: () {
                Navigator.pop(context, true);
              },
            ),
            FlatButton(
              child: Text(falseTitle),
              onPressed: () {
                Navigator.pop(context, false);
              },
            ),
          ],
        );
      },
    );

    return result;
  }

  /// start of 2.0 UI
  static Widget elButton({
    void Function() onPressed,
    String title,
    bool isEnabled = true,
    double width,
  }) {
    return SizedBox(
      width: width,
      child: ElevatedButton(
        onPressed: onPressed,
        child: Text(title),
        style: ButtonStyle(
          backgroundColor:
              MaterialStateProperty.all<Color>(isEnabled ? null : Colors.grey),
        ),
      ),
    );
  }

  static Widget olButton(
      {void Function() onPressed, String title, bool isSelected = false}) {
    return SizedBox(
      child: OutlinedButton(
        onPressed: onPressed,
        child: Text(title),
        style: ButtonStyle(
          backgroundColor:
              MaterialStateProperty.all<Color>(isSelected ? Colors.cyan : null),
          foregroundColor: MaterialStateProperty.all<Color>(
              isSelected ? Colors.white : null),
        ),
      ),
    );
  }

  /// End of 2.0 UI

  static Widget areaContainer(Widget _widget) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.w, horizontal: 10.w),
      padding: EdgeInsets.symmetric(vertical: 20.w, horizontal: 30.w),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey[400], width: 1.w),
      ),
      child: _widget,
    );
  }
}
