import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:oasis_app/pages/common_page/common_page.dart';
import 'package:page_transition/page_transition.dart';

class ToolBox {
  static showToast(String msg, {Toast toastLength = Toast.LENGTH_SHORT}) {
    Fluttertoast.cancel();
    Fluttertoast.showToast(
      msg: msg,
      toastLength: toastLength,
    );
  }

  /// 새창 관련
  // static Future<Object> pushNewPage(
  //     BuildContext context, Widget newPage) async {
  //   return await Navigator.push(context,
  //       PageTransition(type: PageTransitionType.rightToLeft, child: newPage));
  // }

  static Future<Object> replaceNewPage(BuildContext context, Widget newPage,
      {int duration = 0}) async {
    return await Navigator.pushReplacement(
      context,
      PageTransition(
        type: PageTransitionType.fade,
        duration: Duration(seconds: duration),
        child: newPage,
      ),
    );
  }

  static Future<Object> pushPage(
      BuildContext context, String title, Widget widget) async {
    return await Navigator.push(
      context,
      PageTransition(
        type: PageTransitionType.rightToLeft,
        child: CommonPage(
          widget,
          title: title,
        ),
      ),
    );
  }

  static Future<Object> replacePage(
      BuildContext context, String title, Widget widget,
      {int duration = 0}) async {
    return await Navigator.pushReplacement(
      context,
      PageTransition(
        type: PageTransitionType.fade,
        duration: Duration(seconds: duration),
        child: CommonPage(
          widget,
          title: title,
        ),
      ),
    );
  }
}
