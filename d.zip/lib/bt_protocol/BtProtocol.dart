import 'dart:convert';
import 'package:enum_to_string/enum_to_string.dart';
import 'package:flutter/foundation.dart';

enum ProcessStatus {
  UNKNOWN, // 알수없음(접속안됨)
  IDLE, // 대기
  READY, // 준비(공정 설정값이 설정됨)
  GEN, // 소독 중
  STAY, // 유지 중
  RELEASE, // 회수 중
  COMPLETE, // 공정 완료
}

extension ProcessStatusExtension on ProcessStatus {
  static ProcessStatus toEnum(String value) {
    switch (value) {
      case "UNKNOWN":
        return ProcessStatus.UNKNOWN;
      case "IDLE":
        return ProcessStatus.IDLE;
      case "READY":
        return ProcessStatus.READY;
      case "GEN":
        return ProcessStatus.GEN;
      case "STAY":
        return ProcessStatus.STAY;
      case "RELEASE":
        return ProcessStatus.RELEASE;
      case "COMPLETE":
        return ProcessStatus.COMPLETE;
    }
    return null;
  }
}

enum Command {
  INIT, // 시작대기(공정 설정정보 설정 상태)
  START, // 공정 시작
  STOP, // 종료요청(회수과정 후 COMPLETE 로 진입)
  FORCE_STOP, // 강제 종료
  FINISH, // 모든 공정을 종료하고 IDLE 상태로 진입
  REQ_STATUS, // 장비 상태 요청
  REQ_SETTINGS, // 공정 설정 정보 반환 요청
  REQ_RESULT, //공정 결과 반환 요청
  REQ_DATA, // 공정 데이터 반환 요청
  REQ_OTA, // OTA 모드 진입을 요청
}

extension CommandExtension on Command {
  static Command toEnum(String value) {
    switch (value) {
      case "INIT":
        return Command.INIT;
      case "START":
        return Command.START;
      case "STOP":
        return Command.STOP;
      case "FORCE_STOP":
        return Command.FORCE_STOP;
      case "FINISH":
        return Command.FINISH;
      case "REQ_STATUS":
        return Command.REQ_STATUS;
      case "REQ_SETTINGS":
        return Command.REQ_SETTINGS;
      case "REQ_RESULT":
        return Command.REQ_RESULT;
      case "REQ_DATA":
        return Command.REQ_DATA;
      case "REQ_OTA":
        return Command.REQ_OTA;
    }
    return null;
  }
}

enum ResultCode {
  FAIL,
  SUCCESS,
  WRONG_REQ,
  NOT_SET,
  SENSOR_ERROR,
  DISINFECTION_FAIL,
  STAY_FAIL,
  RELEASE_FAIL,
}

extension ResultCodeExtension on ResultCode {
  int get value {
    switch (this) {
      case ResultCode.FAIL:
        return 0;
      case ResultCode.SUCCESS:
        return 1;
      case ResultCode.WRONG_REQ:
        return 11;
      case ResultCode.NOT_SET:
        return 12;
      case ResultCode.SENSOR_ERROR:
        return 13;
      case ResultCode.DISINFECTION_FAIL:
        return 21;
      case ResultCode.STAY_FAIL:
        return 22;
      case ResultCode.RELEASE_FAIL:
        return 23;
    }
    return null;
  }

  static ResultCode toEnum(int value) {
    switch (value) {
      case 0:
        return ResultCode.FAIL;
      case 1:
        return ResultCode.SUCCESS;
      case 11:
        return ResultCode.WRONG_REQ;
      case 12:
        return ResultCode.NOT_SET;
      case 13:
        return ResultCode.SENSOR_ERROR;
      case 21:
        return ResultCode.DISINFECTION_FAIL;
      case 22:
        return ResultCode.STAY_FAIL;
      case 23:
        return ResultCode.RELEASE_FAIL;
    }
    return null;
  }
}

class OasisPayload {
  static final String fCmd = "cmd"; // 요청할 명령
  static final String fData = "data"; // 데이터
  static final String fResult = "result"; // 요청의 결과
  static final String fCid = "cid"; // 차량 식별자(차량 번호
  static final String fWid = "wid"; // 작업자 식별자
  static final String fPhoneNum = "pnb"; // 전화 번호
  static final String fCarNum = "cnb"; // 차량 번호
  static final String fFwVer = "VER"; // 펌웨어 버전

  Command cmd;
  Object data;
  ResultCode result; // Request 명령어에 대한 응답
  String cid; // 차량 식별자
  String wid; // 작업자 식별자
  bool isMyProcess; // 현재 공정이 내가 시작한 공정인지 여부
  String phoneNum; // 알림톡 전송용 전화번호
  String carNum;
  String fwVer;

  OasisPayload(
      {this.cmd,
      this.data,
      this.result,
      this.cid,
      this.wid,
      this.phoneNum,
      this.carNum,
      this.fwVer,
      this.isMyProcess});


  static List<ProcessSetting> processSettingList = [
     ProcessSetting(
      gradeName: "쾌속",
      GV: 2.0,
      GTO: 300,
      SV: 1.5,
      STO: 300,
      RV: 0.1,
      RTO: 500,
      course: 0,
    ),
    ProcessSetting(
      gradeName: "일반",
      GV: 2.0,
      GTO: 300,
      SV: 1.5,
      STO: 600,
      RV: 0.1,
      RTO: 500,
      course: 1,
    ),
    ProcessSetting(
      gradeName: "탈취",
      GV: 2.0,
      GTO: 300,
      SV: 1.5,
      STO: 900,
      RV: 0.1,
      RTO: 500,
      course: 2,
    ),
  ];

  static List<String> gradeNameList() {
    // List<String> list = List<String>();
    List<String> list = [];
    for (ProcessSetting item in processSettingList) {
      list.add(item.gradeName);
    }
    return list;
  }

  // 공정 설정값 명령문 반환 (사용안함)
  static String initCmd(ProcessSetting item, String cid) {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.INIT),
      fData: item.toMap(),
      fCid: cid,
    });
  }

  // 공정 시작 명령문 반환
  static String startProcessCmd(
      ProcessSetting item, String carNum, String wid, String phoneNum) {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.START),
      fData: item.toMap(),
      fCarNum: base64.encode(utf8.encode(carNum)),
      fWid: wid,
      fPhoneNum: phoneNum,
    });
  }

  // 공정 긴급 종료 반환
  static String forceStopProcessCmd() {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.FORCE_STOP),
    });
  }

  // 진행중이던 소독/유지 단계를 취소하고 회수과정을 바로 시작함
  static String stopProcessCmd() {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.STOP),
    });
  }

  // 공정 결과를 요청하고 IDLE 집입을 요청
  static String finishProcessCmd() {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.FINISH),
    });
  }

  // 장비의 현재 상태정보 요정 명령문 반환
  static String reqStatusCmd() {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.REQ_STATUS),
    });
  }

  // 장비 설정 정보 요청 명령문 반환
  static String reqSettingsCmd() {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.REQ_SETTINGS),
    });
  }

  // 장비 공정 결과 요청 명령문 반환
  static String reqResultCmd() {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.REQ_RESULT),
    });
  }

  // 장비 공정 결과 요청 명령문 반환
  static String reqDataCmd(int nowPage) {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.REQ_DATA),
      fData: {"pageIndex": nowPage},
    });
  }

  // OTA 모드 시작 요청 명령문 반환
  static String reqOTACmd() {
    return jsonEncode({
      fCmd: EnumToString.convertToString(Command.REQ_OTA),
    });
  }

  OasisPayload.fromMap(Map<String, dynamic> map) {
    String strCmd = map[fCmd] as String;
    int intResult = map[fResult] as int;
    cmd = CommandExtension.toEnum(strCmd);

    if (cmd == Command.REQ_SETTINGS) {
      data = ProcessSetting.fromMap(map[fData]);
      String _wid = map[fWid] as String;
      if (_wid != null && _wid.isNotEmpty) {
        wid = _wid;
      }
      String _phoneNum = map[fPhoneNum] as String;
      if (_phoneNum != null && _phoneNum.isNotEmpty) {
        phoneNum = _phoneNum;
      }
      String _carNum = map[fCarNum] as String;
      if (_carNum != null && _carNum.isNotEmpty) {
        carNum = utf8.decode(base64.decode(_carNum));
      }
    } else if (cmd == Command.REQ_STATUS) {
      data = ProcessStatusInfo.fromMap(map[fData]);
    } else if (cmd == Command.REQ_RESULT) {
      data = ProcessResultInfo.fromMap(map[fData]);
      fwVer = map[fFwVer] as String;
    } else if (cmd == Command.REQ_DATA) {
      data = ProcessDataInfo.fromMap(map[fData]);
    }
    result = ResultCodeExtension.toEnum(intResult);
  }

  Map<String, dynamic> toMap() {
    var strData;
    if (cmd == Command.REQ_SETTINGS) {
      strData = (data as ProcessSetting).toMap();
    } else if (cmd == Command.REQ_STATUS) {
      strData = (data as ProcessStatusInfo).toMap();
    } else if (cmd == Command.REQ_RESULT) {
      strData = (data as ProcessResultInfo).toMap();
    } else if (cmd == Command.REQ_DATA) {
      strData = (data as ProcessDataInfo).toMap();
    }
    return {
      fCmd: EnumToString.convertToString(cmd),
      fData: strData,
      fResult: EnumToString.convertToString(result),
      fCid: cid,
    };
  }
}

class ProcessSetting {
  static final String fGV = "GV";
  static final String fGTO = "GTO";
  static final String fSV = "SV";
  static final String fSTO = "STO";
  static final String fRV = "RV";
  static final String fRTO = "RTO";
  static final String fVer = "VER";
  static final String fCourse = "COURSE";

  String gradeName; // 차 등급
  // ignore: non_constant_identifier_names
  double GV; // 소독시 목표 PPM
  // ignore: non_constant_identifier_names
  int GTO; //소독단계 timeout
  // ignore: non_constant_identifier_names
  double SV; // 유지 목표 PPM
  // ignore: non_constant_identifier_names
  int STO; // 유지단계 timeout
  // ignore: non_constant_identifier_names
  double RV; // 회수 목표 PPM
  // ignore: non_constant_identifier_names
  int RTO; // 회수단계 timeout
  String ver; // 펌웨어 버전
  int course; // 공정 코스
  // String phoneNumber; // 공정결과를 전달할 전화번호

  ProcessSetting({
    this.gradeName,
    // ignore: non_constant_identifier_names
    this.GV,
    // ignore: non_constant_identifier_names
    this.GTO,
    // ignore: non_constant_identifier_names
    this.SV,
    // ignore: non_constant_identifier_names
    this.STO,
    // ignore: non_constant_identifier_names
    this.RV,
    // ignore: non_constant_identifier_names
    this.RTO,
    this.course,
  });

  ProcessSetting.fromMap(Map<String, dynamic> map) {
    try {
      GV = map[fGV] is int ? (map[fGV] as int).toDouble() : map[fGV];
      GTO = map[fGTO] as int;
      SV = map[fSV] is int ? (map[fSV] as int).toDouble() : map[fSV];
      STO = map[fSTO] as int;
      RV = map[fRV] is int ? (map[fRV] as int).toDouble() : map[fRV];
      RTO = map[fRTO] as int;
      ver = map[fVer] as String;
      course = map[fCourse] as int;
    } catch (e) {}
  }

  Map<String, dynamic> toMap() => {
        fGV: GV,
        fGTO: GTO,
        fSV: SV,
        fSTO: STO,
        fRV: RV,
        fRTO: RTO,
        fVer: ver,
        fCourse: course,
      };

  int getTotalTime() {
    return GTO + STO + RTO;
  }

  String strCourseName() {
    return OasisPayload.processSettingList[course].gradeName;
  }
}

class ProcessStatusInfo {
  static final String fStatus = "status";
  static final String fPpm = "ppm";
  static final String fCount = "count";

  ProcessStatus status = ProcessStatus.UNKNOWN; // 공정상태, 업로드는 안함
  double ppm;
  int count;

  // App에서만 사용하는 공정상태 정보
  int dataLength;
  int totalPage;
  int nowPage;

  ProcessStatusInfo({
    this.status,
    this.ppm,
    this.count,
  });

  ProcessStatusInfo.fromMap(Map<String, dynamic> map) {
    String strStatus = map[fStatus];

    status = ProcessStatusExtension.toEnum(strStatus);
    ppm = map[fPpm] is int ? (map[fPpm] as int).toDouble() : map[fPpm];
    count = map[fCount] as int;
  }

  Map<String, dynamic> toMap() {
    return {
      fStatus: EnumToString.convertToString(status),
      fPpm: ppm,
      fCount: count,
    };
  }

  int leftCount(int courseIndex) {
    ProcessSetting ps = OasisPayload.processSettingList[courseIndex];
    int leftCount = ps.GTO + ps.STO + ps.RTO - count;
    return leftCount;
  }

  double intProgress(int courseIndex) {
    ProcessSetting ps = OasisPayload.processSettingList[courseIndex];
    int totalCount = ps.getTotalTime();
    int nowCount = leftCount(courseIndex);
    // logger.d("totalCount: $totalCount, nowCount: $nowCount");
    return 100 - (nowCount / totalCount * 100);
  }
}

class ProcessResultInfo {
  static final String fGenResult = "GR";
  static final String fStayResult = "SR";
  static final String fReleaseResult = "RR";
  static final String fLength = "length";

  int genResult;
  int stayResult;
  int releaseResult;
  int length;

  ProcessResultInfo({this.genResult, this.stayResult, this.releaseResult});

  ProcessResultInfo.fromMap(Map<String, dynamic> map) {
    genResult = map[fGenResult] as int;
    stayResult = map[fStayResult] as int;
    releaseResult = map[fReleaseResult] as int;
    length = map[fLength] as int;
  }

  Map<String, dynamic> toMap() {
    return {
      fGenResult: genResult,
      fStayResult: stayResult,
      fReleaseResult: releaseResult,
      fLength: length,
    };
  }

  static String strGenResult(ProcessResultInfo info) {
    switch (info.genResult) {
      case -1:
        return "생략";
      case 0:
        return "실패";
      case 1:
        return "성공";
      default:
        return "N/A";
    }
  }

  static String strStayResult(ProcessResultInfo info) {
    switch (info.stayResult) {
      case -1:
        return "생략";
      case 0:
        return "실패";
      case 1:
        return "성공";
      default:
        return "N/A";
    }
  }

  static String strReleaseResult(ProcessResultInfo info) {
    switch (info.releaseResult) {
      case -1:
        return "생략";
      case 0:
        return "실패";
      case 1:
        return "성공";
      default:
        return "N/A";
    }
  }

  static int resultCode(ProcessResultInfo info) {
    if (info.genResult == 1 &&
        // info.stayResult == 1 && // 스테이 실패 발생하지 않도록 수정 필요
        info.releaseResult == 1) {
      return 1;
    } else {
      return 0;
    }
  }
}

class ProcessDataInfo {
  static final String fList = "list";
  static final String fIsEnd = "isEnd";
  static final String fPageIndex = "pageIndex";

  List<double> list;
  bool isEnd;
  int pageIndex;

  ProcessDataInfo({this.list, this.isEnd});

  ProcessDataInfo.fromMap(Map<String, dynamic> map) {
    var tempList = (map[fList] as List)?.map((item) {
      if (item is int) {
        return item.toDouble();
      } else {
        return item;
      }
    })?.toList();
    list = tempList.cast<double>();
    isEnd = map[fIsEnd] as bool;
    pageIndex = map[fPageIndex] as int;
  }

  Map<String, dynamic> toMap() {
    return {
      fList: list,
      fIsEnd: isEnd,
      fPageIndex: pageIndex,
    };
  }
}
