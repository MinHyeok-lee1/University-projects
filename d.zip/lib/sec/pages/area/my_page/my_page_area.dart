import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/sec/model/company.dart';
import 'package:oasis_app/sec/model/oasis_worker.dart';
import 'package:oasis_app/sec/model/page_arguments.dart';
import 'package:oasis_app/sec/pages/area/managements/device/car_list.dart';
import 'package:oasis_app/sec/pages/area/managements/oasis/oasis_list.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;

class MyPageArea extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _MyPageAreaState();
}

class _MyPageAreaState extends State<MyPageArea> {
  AppController ac = Get.find<AppController>();
  ServerProvider sp = Get.find<ServerProvider>();

  // OasisWorker worker;
  // Company company;

  @override
  void initState() {
    // worker = ac.signInResource.value.worker;
    // company = ac.signInResource.value.company;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ub.MyPageWidgets.profileWidget(),
        myInfoWidget(),
      ],
    );
  }

  Widget myInfoWidget() {
    return ub.AreaWidgets.container(
      isExpanded: true,
      isNoBottom: true,
      child: ListView(
        children: [
          ub.ComponentWidgets.itemTitle("account".tr),
          Obx(() => ub.ComponentWidgets.item(
                "name".tr,
                ac.signInResource.value.worker.name,
                onTap: editWorkerName,
              )),
          ub.ComponentWidgets.item(
              "email".tr, ac.signInResource.value.worker.email),
          ub.ComponentWidgets.item(
            "phone".tr,
            ac.signInResource.value.worker.phoneNumber,
            onTap: editWorkerPhoneNumber,
          ),
          ub.ComponentWidgets.item("approval".tr,
              ac.signInResource.value.worker.activated.toString().tr),
          ub.ComponentWidgets.item(
              "authority".tr, ac.signInResource.value.worker.getStrAuth(),
              isLastItem: true),
          ub.ComponentWidgets.itemTitle("company_info".tr),
          ub.ComponentWidgets.item("company_name".tr,
              "${ac.signInResource.value.company.companyName} / ${ac.signInResource.value.company.agentName}"),
          ub.ComponentWidgets.item("company_number".tr,
              ac.signInResource.value.company.companyNumber,
              isLastItem: true),
          ub.ComponentWidgets.itemTitle("service_settings".tr),
          ub.ComponentWidgets.item("sign_out".tr, "",
              onTap: performSignOut, icon: Icon(Icons.logout)),
          ub.ComponentWidgets.item("withdrawal".tr, "",
              onTap: performWithdrawal,
              icon: Icon(Icons.person_remove),
              isLastItem: true),
        ],
      ),
    );
  }

  void editWorkerName() async {
    var result = await Get.toNamed(
      AppManager.common_edit_page.name,
      arguments: PageArguments(
        title: "name".tr,
        value: ac.signInResource.value.worker.name,
      ).toJson(),
    );
    if (result != null) {
      // ac.signInResource.value.worker.name = result;
      Map data = {
        "_id": ac.signInResource.value.worker.id,
        "WN": result,
      };
      await sp.updateWorker(data: data);
    }
  }

  void editWorkerPhoneNumber() async {
    var result = await Get.toNamed(
      AppManager.common_edit_page.name,
      arguments: PageArguments(
              title: "phone".tr,
              value: ac.signInResource.value.worker.phoneNumber,
              keyboardType: PageArguments.keyboardTypeNumber)
          .toJson(),
    );
    if (result != null) {
      ac.signInResource.value.worker.phoneNumber = result;
    }
    setState(() {});
  }

  void performSignOut() async {
    void onConfirmSignOut() async {
      await ac.signOut();
    }

    var result = Get.defaultDialog(
      title: "req_signout_title".tr,
      middleText: "req_signout_content".tr,
      textCancel: "cancel".tr,
      textConfirm: "confirm".tr,
      onConfirm: onConfirmSignOut,
    );
  }

  void performWithdrawal() async {
    Get.defaultDialog();
  }
}
