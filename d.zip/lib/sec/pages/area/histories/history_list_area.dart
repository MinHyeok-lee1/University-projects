import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:oasis_app/sec/model/history.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;

class HistoryListArea extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _HistoryListAreaState();
}

class _HistoryListAreaState extends State<HistoryListArea> {
  AppController ac = Get.find<AppController>();
  ServerProvider sp = Get.find<ServerProvider>();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          children: [
            _HistoryListView(),
          ],
        ),
        _LoadingWidget(),
      ],
    );
  }
}

class _LoadingWidget extends GetView<ServerProvider> {
  @override
  Widget build(BuildContext context) {
    return Obx(() =>
        (controller.isCom.value) ? ub.ComponentWidgets.loading() : Container());
  }
}

class _HistoryListView extends GetView<AppController> {
  final AppController ac = Get.find<AppController>();
  final ServerProvider sp = Get.find<ServerProvider>();
  var refreshKey = GlobalKey<RefreshIndicatorState>();
  final ScrollController con = ScrollController();
  int selectedPage = 0;
  final int numOfPage = 30;

  _HistoryListView() {
    con.addListener(() {
      if (con.position.atEdge) {
        if (con.position.pixels == 0) {
          // lb.logger.d("top");
        } else {
          // lb.logger.d("bottom");
          sp.histories(selectedPage++, numOfPage: numOfPage);
        }
      }
    });
    sp.histories(selectedPage++, numOfPage: numOfPage);
  }

  @override
  Widget build(BuildContext context) {
    return ub.AreaWidgets.container(
      isExpanded: true,
      isNoBottom: true,
      child: Obx(
        () => ListView.builder(
          controller: con,
          itemCount: controller.historyList.value.length,
          itemBuilder: (BuildContext context, int index) {
            return ub.HistoryWidget.listItem(
                controller.historyList.value[index]);
          },
        ),
      ),
    );
  }
}
