import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/sec/model/history.dart';
import 'package:oasis_app/sec/model/page_arguments.dart';
import 'package:oasis_app/sec/pages/area/menu/menu_area.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:share/share.dart';
import 'package:url_launcher/url_launcher.dart';

class HistoryArea extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _HistoryAreaState();
}

class _HistoryAreaState extends State<HistoryArea> {
  AppController ac = Get.find<AppController>();
  ServerProvider sp = Get.find<ServerProvider>();
  PageArguments pageArguments = PageArguments.fromJson(Get.arguments);

  History history;
  String link;

  @override
  void initState() {
    super.initState();
    findHistory();
    link = "${sp.shareUrl}&hid=${pageArguments?.value}";
  }

  void findHistory() async {
    history = await sp.history(pageArguments?.value);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: ub.appBar(pageTitle: pageArguments.title.tr),
        body: (history == null)
            ? ub.ComponentWidgets.loading()
            : Column(
                children: [
                  headerArea(),
                  LineCharts(history),
                  footerArea(),
                ],
              ),
      ),
    );
  }

  Widget headerArea() {
    return ub.AreaWidgets.container(
      isNoBottom: true,
      child: Column(
        children: [
          // 소독일자와 작업자명
          ub.TextWidgets.info("${history.strEndTime()} / ${history.workerName}",
              vertical: 0.h, horizontal: 0),
          Row(
            children: [
              // 차량번호
              Expanded(
                  child: ub.TextWidgets.marker("${history.carNumber}  ",
                      vertical: 0.h, horizontal: 0, bold: true)),
              // 소독 결과
              Chip(
                label: Text(
                  history.strResult(),
                  style: TextStyle(color: Colors.white),
                ),
                backgroundColor: (history.resultCode == 1)
                    ? Colors.lightBlueAccent
                    : Colors.red,
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 0),
              )
            ],
          ),
          // 소요 시간
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(right: 10.w),
                child: Icon(
                  Icons.access_time_rounded,
                  size: 40.w,
                  color: ub.MyColors.greyDark,
                ),
              ),
              ub.TextWidgets.info("req_time".tr + ": ${history.strReqTime()}",
                  vertical: 0, horizontal: 0),
            ],
          ),
          // 장비명과 공정 코스
          Container(
            margin: EdgeInsets.symmetric(vertical: 10.h),
            child: Row(
              children: [
                // 장비명
                ub.ComponentWidgets.bordered(
                  history.deviceNickName ?? history.deviceName,
                  icon: Icon(Icons.devices),
                  bgColor: Colors.black87,
                  textColor: Colors.white,
                ),
                // 코스
                ub.ComponentWidgets.bordered(history.course.toString(),
                    icon: Icon(Icons.golf_course)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget footerArea() {
    return ub.AreaWidgets.container(
      child: Column(
        children: [
          // 오존 PPM 농도
          ub.AreaWidgets.card(
            verticalPadding: 5.h,
            verticalMargin: 10.h,
            top: 10.h,
            child: Container(
              height: 70.h,
              child: Row(
                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // 최대 농도
                  Expanded(
                    child: Column(
                      children: [
                        ub.TextWidgets.info("maximum_concentration".tr),
                        ub.TextWidgets.title(history.maximumPPM.toString(),
                            vertical: 0.h)
                      ],
                    ),
                  ),
                  VerticalDivider(
                    width: 1.w,
                    color: Colors.grey,
                    thickness: 1,
                  ),
                  // 최종 농도
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.only(left: 50.w),
                      child: Column(
                        children: [
                          ub.TextWidgets.info("final_concentration".tr),
                          ub.TextWidgets.title(history.finishPPM.toString(),
                              vertical: 0.h)
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),

          // 버튼들
          Container(
            margin: EdgeInsets.symmetric(vertical: 10.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ub.ComponentWidgets.wideButton(
                  "web_page".tr,
                  width: 0.45.sw,
                  height: 60.h,
                  onPressed: onPressedWeb,
                ),
                ub.ComponentWidgets.wideButton("share".tr,
                    width: 0.45.sw, height: 60.h, onPressed: onPressedShare),
              ],
            ),
          )
        ],
      ),
    );
  }

  void onPressedWeb() async {
    if (await canLaunch(link)) {
      await launch(link);
    }
  }

  void onPressedShare() async {
    Share.share(
      "share_content1".tr + "\n" + "share_content2".tr + "\n $link",
      subject: "share_title".tr,
    );
  }
}

class LineCharts extends StatelessWidget {
  final History history;

  LineCharts(this.history);

  @override
  Widget build(BuildContext context) {
    const cutOffYValue = 0.3;
    const yearTextStyle = TextStyle(
        fontSize: 10, color: Colors.black, fontWeight: FontWeight.bold);

    int index = 0;
    double maxY = ((history.maximumPPM).toInt().toDouble() + 1);
    if (maxY < 3) maxY = 3;

    return Expanded(
      child: Container(
        width: 0.9.sw,
        margin: EdgeInsets.symmetric(vertical: 20.h),
        child: LineChart(
          LineChartData(
            lineTouchData: LineTouchData(enabled: true),
            lineBarsData: [
              LineChartBarData(
                spots: history.processData.map(
                  (value) {
                    // lb.logger.d("index: $index++, value: $value");
                    return FlSpot((index++).toDouble(), value);
                  },
                ).toList(),
                isCurved: false,
                barWidth: 1.h,
                colors: [
                  ub.MyColors.selected,
                ],
                belowBarData: BarAreaData(
                  show: true,
                  colors: [ub.MyColors.selected.withOpacity(0.4)],
                  cutOffY: cutOffYValue,
                  applyCutOffY: false,
                ),
                // aboveBarData: BarAreaData(
                //   show: true,
                //   colors: [Colors.red.withOpacity(0.6)],
                //   cutOffY: cutOffYValue,
                //   applyCutOffY: true,
                // ),
                dotData: FlDotData(
                  show: false,
                ),
              ),
            ],
            minY: 0,
            maxY: maxY,
            minX: 0,
            maxX: history.processData.length.toDouble(),
            titlesData: FlTitlesData(
              bottomTitles: SideTitles(
                  showTitles: true,
                  getTitles: (value) {
                    if (value % 100 == 0) {
                      return value.toInt().toString();
                    } else {
                      return "";
                    }
                  }),
              leftTitles: SideTitles(
                showTitles: true,
                reservedSize: 30.w,
                // margin: 0.w,
                getTitles: (value) {
                  return '${value}';
                },
              ),
            ),
            axisTitleData: FlAxisTitleData(
              leftTitle: AxisTitle(
                showTitle: true,
                titleText: 'PPM',
                textStyle: yearTextStyle,
                margin: -30.w,
              ),
              bottomTitle: AxisTitle(
                showTitle: true,
                margin: -50.h,
                titleText: '',
                textStyle: yearTextStyle,
                textAlign: TextAlign.right,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
