import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/sec/model/device.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;

class MenuArea extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _MenuAreaState();
}

class _MenuAreaState extends State<MenuArea> {
  AppController ac = Get.find<AppController>();
  ServerProvider sp = Get.find<ServerProvider>();

  @override
  void initState() {
    if (ac.historyList.value.length == 0) {
      sp.histories(0);
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ub.MyPageWidgets.profileWidget(),
        scannedDevicesArea(),
        _HistoryListView(),
      ],
    );
  }

  Widget profileWidget() {
    return ub.AreaWidgets.container(
      paddingHorizontal: 10.w,
      child: Row(
        children: [
          Container(
            height: 150.w,
            width: 150.w,
            // color: Colors.red,
            margin: EdgeInsets.only(right: 30.w),
            child: CircleAvatar(
              backgroundImage:
                  NetworkImage(ac.signInResource.value.worker.photoURL),
              backgroundColor: Colors.grey[200],
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ub.TextWidgets.key(
                ac.signInResource.value.company.companyName,
                maxWidth: 700.w,
              ),
              Row(
                children: [
                  ub.TextWidgets.marker(
                    ac.signInResource.value.worker.name,
                    vertical: 5.w,
                    maxWidth: 600.w,
                  ),
                  ub.TextWidgets.marker(
                    "sir".tr,
                    vertical: 5.w,
                    bold: false,
                    maxWidth: 100.w,
                  )
                ],
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget scannedDevicesArea() {
    Device device = ac.signInResource.value.devices[0];
    return ub.AreaWidgets.container(
      height: 300.h,
      title: "scanned_devices".tr,
      badge: ac.signInResource.value.devices.length.toString(),
      tail: ub.TextWidgets.info("더보기 >"),
      child: Expanded(
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: ac.signInResource.value.devices
              .map((Device device) => ub.OasisWidgets.thumb(device))
              .toList(),
        ),
      ),
    );
  }
}

class _HistoryListView extends GetView<AppController> {
  final AppController ac = Get.find<AppController>();

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => ub.AreaWidgets.containerBgGrey(
        title: "최근 소독이력",
        badge: controller.historyList.value.length.toString(),
        tail: InkWell(
          child: ub.TextWidgets.info("더보기 >"),
          onTap: () {
            ac.currentNavIndex.value = 3;
          },
        ),
        isExpanded: true,
        isNoBottom: true,
        child: ListView.builder(
          itemCount: controller.historyList.value.length,
          itemBuilder: (BuildContext context, int index) {
            return ub.HistoryWidget.listItem(
                controller.historyList.value[index]);
          },
        ),
      ),
    );
  }
}
