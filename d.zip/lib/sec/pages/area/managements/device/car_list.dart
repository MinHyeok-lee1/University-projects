import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/model/car.dart';
import 'package:oasis_app/sec/model/device.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;

class CarList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _CarList();
}

class _CarList extends State<CarList> {
  AppController ac = Get.find<AppController>();
  ServerProvider sp = Get.find<ServerProvider>();


  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ub.TextFields.withDeleteButton(
          this,
          controller: teCon,
          hintText: "enter_car_number".tr,
        ),
        ub.ComponentWidgets.wideButton(
          "add_new_car".tr,
          icon: Icon(Icons.add_circle_outline),
          height: 60.h,
          onPressed: addNewDevice,
        ),
        carList(),
      ],
    );
  }

  TextEditingController teCon = TextEditingController();

  Widget carList() {
    return ub.AreaWidgets.container(
      isExpanded: true,
      child: ListView(
        children: ac.signInResource.value.cars
            .map((Car car) => ub.CarWidgets.tile(car, filterText: teCon.text))
            .toList(),
      ),
    );
  }

  void addNewDevice() {}

  @override
  void dispose() {
    ub.KeyboardUtils.hideKeyboard(context);
    super.dispose();
  }
}
