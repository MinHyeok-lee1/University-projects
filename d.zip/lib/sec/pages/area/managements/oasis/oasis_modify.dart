import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/model/device.dart';
import 'package:oasis_app/sec/model/page_arguments.dart';
import 'package:oasis_app/sec/pages/area/managements/device/car_list.dart';
import 'package:oasis_app/sec/pages/area/managements/oasis/oasis_list.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;

class OasisModifyPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _OasisModifyPageState();
}

class _OasisModifyPageState extends State<OasisModifyPage> {
  AppController ac = Get.find<AppController>();
  ServerProvider sp = Get.find<ServerProvider>();

  PageArguments pageArguments = PageArguments.fromJson(Get.arguments);
  Device oasis;

  @override
  void initState() {
    super.initState();
    oasis = ac.getOasis(pageArguments.value);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        // key: _scaffoldKey,
        appBar: ub.appBar(
            pageTitle: pageArguments.title.tr + " " + "modification".tr),
        body: Column(
          children: [
            oasisInfoArea(),
          ],
        ),
      ),
    );
  }

  Widget oasisInfoArea() {
    return ub.AreaWidgets.container(
      isExpanded: true,
      child: ListView(
        children: [
          ub.OasisWidgets.tile(oasis),
          ub.ComponentWidgets.itemTitle("account".tr,top: 10.h),
          ub.ComponentWidgets.item("model", oasis.model),
          ub.ComponentWidgets.item("nickname", oasis.nickName,
              onTap: onTapNickNameModification),
          ub.ComponentWidgets.item("mac", oasis.MAC),
          ub.ComponentWidgets.item("version", oasis.version),
        ],
      ),
    );
  }

  void onTapNickNameModification() async {}
}
