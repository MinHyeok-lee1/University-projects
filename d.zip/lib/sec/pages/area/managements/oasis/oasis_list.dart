import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/model/device.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;

class OasisList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _OasisListState();
}

class _OasisListState extends State<OasisList> {
  AppController ac = Get.find<AppController>();
  ServerProvider sp = Get.find<ServerProvider>();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ub.ComponentWidgets.wideButton(
          "add_new_oasis".tr,
          icon: Icon(Icons.add_circle_outline),
          height: 60.h,
          onPressed: addNewOasis,
        ),
        oasisList(),
      ],
    );
  }

  Widget oasisList() {
    return ub.AreaWidgets.container(
      isExpanded: true,
      child: ListView(
        children: ac.signInResource.value.devices
            .map((Device device) =>
                ub.OasisWidgets.tile(device, isModifyMode: true))
            .toList(),
      ),
    );
  }

  void addNewOasis() {}
}
