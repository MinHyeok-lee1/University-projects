import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/pages/area/managements/device/car_list.dart';
import 'package:oasis_app/sec/pages/area/managements/oasis/oasis_list.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;

class ManagementArea extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _ManagementAreaState();
}

class _ManagementAreaState extends State<ManagementArea> {
  AppController ac = Get.find<AppController>();
  ServerProvider sp = Get.find<ServerProvider>();

  int subAreaIndex = 0;
  final List<String> subAreaTitleList = ["mgm_oasis".tr, "mgm_car".tr];

  @override
  Widget build(BuildContext context) {
    Widget subArea;
    switch (subAreaIndex) {
      case 0:
        subArea = OasisList();
        break;
      case 1:
        subArea = CarList();
        break;
    }
    return Column(
      children: [
        subAreaIcons(),
        Expanded(child: subArea),
      ],
    );
  }

  Widget subAreaIcons() {
    return ub.AreaWidgets.container(
      child: Row(
        children: [
          ub.TextWidgets.underline(
            subAreaTitleList[0],
            isSelected: (subAreaIndex == 0),
            onTap: selectOasisManagement,
          ),
          ub.TextWidgets.underline(
            subAreaTitleList[1],
            isSelected: (subAreaIndex == 1),
            onTap: selectCarManagement,
          ),
        ],
      ),
    );
  }

  Widget subAreaWidget() {
    switch (subAreaIndex) {
      case 0:
        return Container();
      case 1:
        return Container();
    }
    return null;
  }

  void selectOasisManagement() {
    setState(() {
      subAreaIndex = 0;
    });
  }

  void selectCarManagement() {
    setState(() {
      subAreaIndex = 1;
    });
  }
}
