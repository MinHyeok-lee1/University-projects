import 'package:app_settings/app_settings.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/sec/model/res_payload.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;
import 'package:package_info/package_info.dart';
import 'package:sign_button/constants.dart';
import 'package:sign_button/create_button.dart';
import 'package:permission_handler/permission_handler.dart';

class IntroPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _IntroPageState();
}

class _IntroPageState extends State<IntroPage> {
  AppController ac = Get.find<AppController>();
  ServerProvider sp = Get.find<ServerProvider>();

  String verInfo = "";

  bool showSignInButton = false;
  bool showPermissionArea = true;

  @override
  void initState() {
    Get.lazyPut<ServerProvider>(() => ServerProvider());
    Get.lazyPut<AppController>(() => AppController());

    super.initState();

    getAppInfo();

    lb.AckTimer.start(seconds: 2, callback: performSignInProcess);

    SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
      ub.PageTheme.setPageTheme(pageTheme: ub.PageTheme.introPage);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: ub.appBar(),
      body: Column(
        children: [
          logoWidget(), // 500.w
          permissionWidget(), //
          signInWidget(), // 100.w
          appInfoWidget(), // 40.w
        ],
      ),
    );
  }

  /*** Widget Part ***/

  Widget logoWidget() {
    return Expanded(
      child: Container(
        height: 450.h,
        // alignment: Alignment.topCenter,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(vertical: 10.w, horizontal: 10.w),
              child: Image.asset("assets/images/logo.png"),
            ),
            Text(
              "OASIS",
              style: TextStyle(fontSize: 100.w, fontWeight: FontWeight.bold),
            ),
            Text(
              "export".tr,
              style: TextStyle(fontSize: 80.w, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  Widget permissionWidget() {
    return ub.AreaWidgets.containerBgGrey(
        title: "request_permission".tr,
        info: "permission_are_required".tr,
        height: 730.w,
        child: (showPermissionArea)
            ? Column(
                children: [
                  ub.ComponentWidgets.keyValueCard("location".tr,
                      ac.locationStatus.value.isGranted.toString().tr),
                  ub.ComponentWidgets.keyValueCard("bluetooth".tr,
                      ac.bluetoothStatus.value.isGranted.toString().tr),
                  ub.ComponentWidgets.keyValueCard("storage".tr,
                      ac.storageStatus.value.isGranted.toString().tr),
                  ElevatedButton(
                    onPressed: onPressedOfSettingButton,
                    child: Text("setting".tr),
                  )
                ],
              )
            : null);
  }

  Widget signInWidget() {
    return Container(
      // color: Colors.red,
      height: 100.h,
      child: (showSignInButton)
          ? Container(
              alignment: Alignment.center,
              child: SignInButton(
                buttonType: ButtonType.google,
                buttonSize: ButtonSize.medium,
                elevation: 5.w,
                padding: 25.w,
                width: 700.w,
                btnText: "sing_in_with_google".tr,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
                onPressed: tryToSignIn,
              ),
            )
          : Container(),
    );
  }

  Widget appInfoWidget() {
    return Container(
      height: 40.h,
      child: ub.TextWidgets.value(verInfo, alignment: Alignment.bottomCenter),
    );
  }

  /*** Logic Part ***/

  void onPressedOfSettingButton() async {
    await AppSettings.openAppSettings(asAnotherTask: true);
    await ac.permissionCheck();
    performSignInProcess();
  }

  void getAppInfo() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String version = packageInfo.version;
    setState(() {
      verInfo = "$version";
    });
  }

  void performSignInProcess() async {
    /** 권한 체크 **/
    bool result = ac.allowedAllPermission();

    if (result = false) {
      setState(() {
        showPermissionArea = true;
      });
      return;
    }

    // 자동로그인에 실패했을 경우 정식 로그인 시도
    if (ac.currentUser.value == null) {
      setState(() {
        showSignInButton = true;
      });
      return;
    }

    // 서버 로그인 시도
    ResPayload payload = await sp.signIn();
    // 통신 실패 or 서버 에러
    if (payload == null) {
      return Get.snackbar(
        "server_error".tr,
        "retry_later".tr,
        duration: Duration(seconds: 5),
        snackPosition: SnackPosition.BOTTOM,
      );
    }

    // 로그인 성공
    if (payload.result) {
      gotoMenuPage();
    }
    // 서버에 해당 회원이 없을 경우 회원 가입 처리
    else if (payload.error == ResPayload.NO_SUCH_DATA) {}
  }

  void tryToSignIn() async {
    if (await ac.signInGoogleAccount()) {
      performSignInProcess();
    } else {
      goToSignUpPage();
    }
  }

  void gotoMenuPage() async {
    Get.off(AppManager.page_common.page);
  }

  void goToSignUpPage() {}
}
