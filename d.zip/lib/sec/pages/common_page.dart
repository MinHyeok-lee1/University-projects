import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/sec/pages/area/menu/menu_area.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CommonPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _CommonPageState();
}

class _CommonPageState extends State<CommonPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  AppController ac = Get.find<AppController>();
  static bool isFirst = true;

  final List<String> titleList = [
    "home".tr,
    "st".tr,
    "management".tr,
    "histories".tr,
    "my_info".tr
  ];

  @override
  void initState() {
    super.initState();
    if (isFirst) {
      SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
        Get.snackbar(
          "signin_succeed".tr,
          "welcome_user".trParams({"name": ac.currentUser.value.displayName}),
          duration: Duration(seconds: 2),
        );
      });
      isFirst = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        key: _scaffoldKey,
        resizeToAvoidBottomInset: false,
        appBar: ub.appBar(),
        body: Column(
          children: [
            Obx(() =>
                ub.TextWidgets.pageTitle(titleList[ac.currentNavIndex.value])),
            Expanded(
              child: Obx(() => childAreaWidget()),
            ),
            menuWidget(),
          ],
        ),
      ),
    );
  }

  Widget childAreaWidget() {
    switch (ac.currentNavIndex.value) {
      case 0:
        return AppManager.page_menu_area.page();
      case 1:
        break;
      case 2:
        return AppManager.page_management_area.page();
      case 3:
        return AppManager.page_histories.page();
      case 4:
        return AppManager.page_myinfo_area.page();
      default:
        return MenuArea();
    }
    return AppManager.page_menu_area.page();
  }

  Widget menuWidget() {
    const List<String> onImages = [
      "assets/images/nav_home_on.png",
      "assets/images/nav_st_on.png",
      "assets/images/nav_mgt_on.png",
      "assets/images/nav_history_on.png",
      "assets/images/nav_my_on.png",
    ];
    const List<String> offImages = [
      "assets/images/nav_home_off.png",
      "assets/images/nav_st_off.png",
      "assets/images/nav_mgt_off.png",
      "assets/images/nav_history_off.png",
      "assets/images/nav_my_off.png",
    ];
    const List<String> titles = ["홈", "차량소독", "관리", "히스토리", "내정보"];
    List<Widget> menuItems = [];
    for (int index = 0; index < onImages.length; index++) {
      menuItems.add(Obx(
        () => InkWell(
          child: Column(
            children: [
              Container(
                width: 100.w,
                height: 170.w,
                child: (ac.currentNavIndex.value == index)
                    ? Image.asset(onImages[index])
                    : Image.asset(offImages[index]),
              ),
              Container(
                child: Text(
                  titles[index],
                  style: ub.TextWidgets.tsInfo,
                ),
              ),
            ],
          ),
          onTap: () {
            ac.setNavIndex(index);
          },
        ),
      ));
    }
    return Container(
      color: Colors.grey[100],
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: menuItems,
      ),
    );
  }
}
