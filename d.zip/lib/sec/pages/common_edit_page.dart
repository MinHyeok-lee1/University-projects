import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/sec/model/page_arguments.dart';
import 'package:oasis_app/sec/pages/area/menu/menu_area.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CommonEditPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _CommonEditPageState();
}

class _CommonEditPageState extends State<CommonEditPage> {
  AppController ac = Get.find<AppController>();
  // final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  PageArguments pageArguments = PageArguments.fromJson(Get.arguments);

  TextEditingController con = TextEditingController();

  @override
  void initState() {
    super.initState();
    con.text = pageArguments.value;
  }

  @override
  void dispose() async {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        // key: _scaffoldKey,
        appBar: ub.appBar(
            pageTitle: pageArguments.title.tr + " " + "modification".tr),
        body: editArea(),
      ),
    );
  }

  Widget editArea() {
    TextInputType keyboardType;
    switch (pageArguments.keyboardType) {
      case 1:
        keyboardType = TextInputType.number;
        break;
    }
    return ub.AreaWidgets.container(
      title: "이름",
      paddingHorizontal: 30.w,
      child: Column(
        children: [
          ub.TextFields.withDeleteButton(
            this,
            controller: con,
            marginHorizontal: 0,
            keyboardType: keyboardType,
          ),
          ub.ComponentWidgets.wideButton("수정",
              width: 1.sw, onPressed: onPressedEditValue)
        ],
      ),
    );
  }

  void onPressedEditValue() {
    String result;
    if (con.text.isEmpty && pageArguments.allowEmptyReturnValue == false) {
      Get.snackbar(
        "edit_failed".tr,
        "edit_failed_content".tr,
        duration: Duration(seconds: 2),
        snackPosition: SnackPosition.BOTTOM,
      );
      con.text = pageArguments.value;
      return;
    }
    if (pageArguments.value == con.text) {
      result = null;
    } else {
      result = con.text;
    }
    Get.back(result: result);
  }
}
