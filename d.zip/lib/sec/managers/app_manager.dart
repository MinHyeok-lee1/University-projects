import 'package:devicelocale/devicelocale.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/pages/area/histories/history_area.dart';
import 'package:oasis_app/sec/pages/area/histories/history_list_area.dart';
import 'package:oasis_app/sec/pages/area/managements/management_area.dart';
import 'package:oasis_app/sec/pages/area/managements/oasis/oasis_modify.dart';
import 'package:oasis_app/sec/pages/area/menu/menu_area.dart';
import 'package:oasis_app/sec/pages/area/my_page/my_page_area.dart';
import 'package:oasis_app/sec/pages/common_edit_page.dart';

import 'package:oasis_app/sec/pages/common_page.dart';
import 'package:oasis_app/sec/pages/intro_page.dart';
import 'package:oasis_app/sec/tool_box/ui_box.dart' as ub;
import 'package:screen/screen.dart';

class AppManager extends StatefulWidget {
  static Locale _currentLocale;
  static Size _pageSize = Size(1000, 1000);

  static void startApp() async {
    /** 앱 설정 **/
    // main 함수에서 비동기 메소드를 사용할 수 있게함
    // WidgetsFlutterBinding.ensureInitialized();
    // 화면 세로보기 고정
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    // 화면 켜짐 유지
    Screen.keepOn(true);
    // _pageSize = Size(1000, 1000);
    // 테마 설정
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.white,
    ));
    // 현재 지역 설정값 확인(다국어 지원용)
    _currentLocale = await Devicelocale.currentAsLocale;

    /** 앱 실행 **/
    runApp(AppManager());
  }

  static GetPage page_intro = GetPage(
    name: "/intro",
    page: () => IntroPage(),
    // binding: AppBinding(),
  );
  static GetPage page_common = GetPage(
    name: "/common",
    page: () => CommonPage(),
    children: [page_menu_area],
    // binding: AppBinding(),
  );
  static GetPage page_menu_area = GetPage(
    name: "/menu_area",
    page: () => MenuArea(),
    // binding: AppBinding(),
  );
  static GetPage page_management = GetPage(
    name: "/management",
    page: () => CommonPage(),
    children: [page_management_area],
    // binding: AppBinding(),
  );
  static GetPage page_management_area = GetPage(
    name: "/management_area",
    page: () => ManagementArea(),
    // binding: AppBinding(),
  );
  static GetPage page_myinfo_area = GetPage(
    name: "/my_info",
    page: () => MyPageArea(),
    // binding: AppBinding(),
  );
  static GetPage common_edit_page = GetPage(
    name: "/edit_page",
    page: () => CommonEditPage(),
    transition: Transition.rightToLeftWithFade,
    transitionDuration: Duration(milliseconds: 500),
    // binding: AppBinding(),
  );
  static GetPage page_histories = GetPage(
    name: "/histories",
    page: () => HistoryListArea(),
  );
  static GetPage page_history = GetPage(
    name: "/history",
    page: () => HistoryArea(),
  );
  static GetPage page_oasis_modify = GetPage(
    name: "/page_oasis_modify",
    page: () => OasisModifyPage(),
    transition: Transition.rightToLeftWithFade,
    transitionDuration: Duration(milliseconds: 500),
  );

  static List<GetPage<dynamic>> pages = [
    page_intro,
    page_common,
    page_menu_area,
    page_management,
    page_management_area,
    page_myinfo_area,
    common_edit_page,
    page_oasis_modify,
  ];

  @override
  State<StatefulWidget> createState() => _AppManagerState();
}

class _AppManagerState extends State<AppManager> {
  @override
  Widget build(BuildContext context) {
    Get.put<AppController>(AppController(), permanent: true);
    Get.put<ServerProvider>(ServerProvider(), permanent: true);
    return ScreenUtilInit(
      designSize: AppManager._pageSize,
      builder: () => GetMaterialApp(
        builder: (context, widget) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
            child: widget,
          );
        },
        initialBinding: AppBinding(),
        // theme: ub.buttonThemeData,
        initialRoute: AppManager.page_intro.name,
        getPages: AppManager.pages,
        localizationsDelegates: [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: [
          const Locale('ko', ''),
          const Locale('en', ''),
        ],
        locale: AppManager._currentLocale,
        fallbackLocale: Locale('en', 'US'),
        translations: Messages(),
      ),
    );
  }
}

class Messages extends Translations {
  @override
  // TODO: implement keys
  Map<String, Map<String, String>> get keys => {
        'ko_KR': {
          // Page title
          'page_intro': "인트로",
          /** Pages **/
          // intro_page
          'export': "관리자용",
          'request_permission': "권한 요청",
          'permission_are_required': "다음의 권한들이 요구됩니다.",
          'sing_in_with_google': "구글 계정으로 로그인",
          'signin_succeed': '로그인 성공',
          'welcome_user': '@name님 환영합니다.',
          'server_error': '서버 접속 실패',
          'retry_later': '잠시 후 다시 시도하시기 바랍니다.',
          // menu_area
          'home': '홈',
          'sir': " 님",
          "scanned_devices": "검색된 소독기",
          // 권한
          'location': "위치",
          'bluetooth': "블루투스",
          "storage": "저장소",
          // 공통
          'true': "성공",
          'false': "실패",
          'setting': "설정",
          'cancel': "취소",
          'confirm': '확인',
          // management
          'management': '관리',
          'mgm_oasis': '오아시스 관리',
          'mgm_car': '차량 관리',
          'add_new_oasis': "소독기 신규 등록",
          'add_new_car': '차량 신규 등록',
          'enter_car_number': "차량번호 입력",
          // my info
          'my_info': "내 정보",
          'account': '계정 정보',
          'name': '이름',
          'email': '메일주소',
          'phone': '휴대번호',
          'approval': "사용승인",
          'authority': '권한',
          'company_info': '사업체 정보',
          'company_name': '사업체명',
          'company_number': '사업자번호',
          'service_settings': "서비스 설정",
          'sign_out': '로그아웃',
          'withdrawal': '회원탈퇴',
          'req_signout_title': '로그아웃',
          'req_signout_content': '로그아웃 하시겠습니까?',
          // WorkerAuth
          'platform_admin': '플랫폼 관리자',
          'worker': '작업자',
          'manager': '관리자',
          'seller': 'seller',
          // common_edit_page
          'modification': '수정',
          'edit_failed': '수정 실패',
          'edit_failed_content': '값 입력은 필수입니다.',
          // Histories
          'histories': "소독 이력",
          'disinfection_details': "소독 상세이력",
          'req_time': '소요시간',
          'hour': '시간',
          'min': '분',
          'sec': '초',
          'maximum_concentration': "최대 농도",
          'final_concentration': "최종 농도",
          'web_page': "웹에서 확인",
          'share': "공유",
          'share_title': "OASIS 소독 결과",
          'share_content1': "차량용 소독기 오아시스(OASIS)의 소독공정이 완료되었습니다.",
          'share_content2': "공정결과를 확인하세요.",

          //
        },
        'en_US': {
          // Page title
          'page_intro': "Intro",
          /** Pages **/
          // intro_page
          'export': "for EXPERT",
          'request_permission': "Request permission",
          'permission_are_required': "The following permissions are required.",
          'sing_in_with_google': "Sign In with Google",
          'signin_succeed': 'Sign-in Succeed',
          'welcome_user': 'Welcome to @name.',
          'server_error': 'Server connection failure',
          'retry_later': 'Please try again later.',
          // menu_area
          'home': 'Home',
          'sir': "",
          "scanned_devices": "Scanned Devices",
          // 권한
          'location': "Location",
          'bluetooth': "Bluetooth",
          "storage": "Storage",
          // 공통
          'true': "TRUE",
          'false': "FALSE",
          'setting': "SETTING",
          'cancel': "CANCEL",
          'confirm': 'CONFIRM',
          // management
          'management': 'Management',
          'mgm_oasis': 'OASIS',
          'mgm_car': 'CAR',
          'add_new_oasis': "Add New Oasis",
          'add_new_car': 'Add New Car',
          'enter_car_number': "Enter vehicle number",
          // my info
          'my_info': "My Page",
          'account': 'Account',
          'name': 'Name',
          'email': 'Email',
          'phone': 'Phone',
          'approval': "Approval",
          'authority': 'Authority',
          'company_info': 'Company',
          'company_name': 'Name',
          'company_number': 'ID',
          'service_settings': "Service Settings",
          'sign_out': 'SignOut',
          'withdrawal': 'Withdrawal',
          'req_signout_title': 'Sign Out',
          'req_signout_content': 'Do you want to sign out?',
          // WorkerAuth
          'platform_admin': 'Platform Admin',
          'worker': 'Worker',
          'manager': 'Manager',
          'seller': 'Seller',
          // common_edit_page
          'modification': 'modification',
          'edit_failed': 'Edit failed',
          'edit_failed_content': 'Entering a value is required.',
          // Histories
          'histories': "Disinfection history",
          'disinfection_details': "Disinfection details",
          'req_time': 'Time',
          'hour': 'h',
          'min': 'm',
          'sec': 's',
          'maximum_concentration': "Max. ppm",
          'final_concentration': "Final ppm",
          'web_page': "Web page",
          'share': "Share it",
          'share_title': "OASIS Disinfection Results",
          'share_content1':
              "The disinfection process of the vehicle sterilizer OASIS has been completed..",
          'share_content2': "Check the process results.",
        }
      };
}
