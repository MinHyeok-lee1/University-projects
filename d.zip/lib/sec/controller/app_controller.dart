import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/sec/controller/server_provider.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/sec/model/device.dart';
import 'package:oasis_app/sec/model/history.dart';
import 'package:oasis_app/sec/model/oasis_worker.dart';
import 'package:oasis_app/sec/model/sing_in_resource.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:permission_handler/permission_handler.dart';

class AppBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AppController>(() => AppController());
    Get.lazyPut<ServerProvider>(() => ServerProvider());
  }
}

class AppController extends GetxController {
  @override
  void onInit() async {
    // 퍼미션 핸들링
    await permissionCheck();
    // 구글 로그인 시도
    _googleSignIn.onCurrentUserChanged.listen((GoogleSignInAccount account) {
      currentUser.value = account;
      lb.AckTimer.cancel(invokeCallback: true);
    });
    _googleSignIn.signInSilently();

    historyList.value = [];
    super.onInit();
  }

  ///************************
  /// 퍼미션 관련
  ///************************/
  Rxn<PermissionStatus> locationStatus = Rxn<PermissionStatus>();
  Rxn<PermissionStatus> bluetoothStatus = Rxn<PermissionStatus>();
  Rxn<PermissionStatus> storageStatus = Rxn<PermissionStatus>();

  Map<Permission, PermissionStatus> permissionStatus =
      Map<Permission, PermissionStatus>();

  Future<void> permissionCheck() async {
    locationStatus.value = await Permission.location.request();
    bluetoothStatus.value = await Permission.bluetooth.request();
    storageStatus.value = await Permission.storage.request();
  }

  bool allowedAllPermission() {
    print(locationStatus.value.isGranted);
    print(bluetoothStatus.value.isGranted);
    print(storageStatus.value.isGranted);
    if (locationStatus.value.isGranted &&
        bluetoothStatus.value.isGranted &&
        storageStatus.value.isGranted) {
      return true;
    } else {
      return false;
    }
  }

  ///************************
  /// 로그인 관련
  ///************************/

  Rxn<GoogleSignInAccount> currentUser = Rxn<GoogleSignInAccount>();
  static GoogleSignIn _googleSignIn = GoogleSignIn();

  // 구글 계정으로 로그인
  Future<bool> signInGoogleAccount() async {
    try {
      var result = await _googleSignIn.signIn();

      if (result != null) {
        currentUser.value = result;
        return true;
      } else {
        return false;
      }
    } catch (error) {
      logger.d(error.toString());
      return false;
    }
  }

  // 구글 계정에서 로그아웃
  Future<bool> signOutGoogleAccount() async {
    try {
      await _googleSignIn.disconnect();
      currentUser.value = null;
      return true;
    } catch (error) {
      logger.d(error);
      return false;
    }
  }

  Future<void> signOut() async {
    await signOutGoogleAccount();
    // signInResource.value = null;
    Get.offAll(AppManager.page_intro.page, binding: AppBinding());
  }

  // 회원 가입
  void singUpToServer() {}

  // 회원 탈퇴
  void withdrawal() {}

  ///************************
  /// 서버로부터 수신한 리소스 데이터
  ///************************/
  // Rx<bool> isCom = Rx<bool>(false);

  Rxn<SignInResource> signInResource = Rxn<SignInResource>();

  void setWorker(OasisWorker worker) {
    SignInResource _signInResource = signInResource.value;
    _signInResource.worker = worker;
    signInResource.value = _signInResource;
  }

  Rxn<List<History>> historyList = Rxn<List<History>>();

  Device getOasis(String id) {
    for (Device device in signInResource.value.devices) {
      if (device.id == id) {
        return device;
      }
    }
    return null;
  }

  ///************************
  /// 네비게이션바 관련
  ///************************/

  Rx<int> currentNavIndex = Rx<int>(0);

  void setNavIndex(int index) {
    currentNavIndex.value = index;
    update();
  }
}
