import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';

import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/model/history.dart';
import 'package:oasis_app/sec/model/oasis_worker.dart';
import 'package:oasis_app/sec/model/res_payload.dart';
import 'package:oasis_app/sec/model/sing_in_resource.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;

class ServerProvider extends GetConnect {
  AppController ac = Get.find<AppController>();

  final String _oasisUrl = "http://cleanoasis.net";
  final String _devUrl = "https://pcb.cleanoasis.net";
  String baseUrl;
  String shareUrl;
  String _token;
  ResPayload _payload;
  bool _result;

  Rx<bool> isCom = Rx<bool>(false); // 현재 통신중인지 여부

  @override
  void onInit() {
    baseUrl = ((kDebugMode) ? _devUrl : _oasisUrl) + "/mobile";
    shareUrl = ((kDebugMode) ? _devUrl : _oasisUrl) + "/publish?cat=1";
    httpClient.baseUrl = baseUrl;
    httpClient.defaultContentType = "application/json";
    httpClient.defaultDecoder = (val) {
      // lb.logger.d(val);
      try {
        _payload = ResPayload.fromJson(val as Map<String, dynamic>);
        _result = _payload.result;
      } catch (e) {
        lb.logger.e(e.toString());
      } finally {
        isCom.value = false;
      }
    };

    httpClient.addRequestModifier((request) {
      _payload = null;
      _result = false;
      request.headers["token"] = _token;
      isCom.value = true;
      // ac.isCom.refresh();
      return request;
    });

    super.onInit();
  }

  @override
  Future<Response<T>> post<T>(String url, body,
      {String contentType,
      Map<String, String> headers,
      Map<String, dynamic> query,
      Decoder<T> decoder,
      Progress uploadProgress}) async {
    return await super.post(url, body);
  }

  /**
   * 작업자 관련(회원관리 포함)
   */
  Future<ResPayload> signIn() async {
    Map data = {
      "type": "GOOGLE",
      "id": ac.currentUser.value.id,
      "email": ac.currentUser.value.email,
    };
    // await post("/worker/signin", data);
    await post(UrlTool.signInPath(), data);
    if (_result) {
      _token = _payload.token;
      ac.signInResource.value =
          SignInResource.fromJson(jsonDecode(_payload.data));
    }
    return _payload;
  }

  Future<ResPayload> updateWorker({Map data}) async {
    await post(
      UrlTool.genPath(UrlTool.Worker, UrlTool.updateOne),
      data ?? ac.signInResource.value.worker.toJson(),
    );

    if (_result) {
      ac.signInResource.value.worker =
          OasisWorker.fromJson(jsonDecode(_payload.data));
      ac.signInResource.refresh();
    }
    return _payload;
  }

  /**
   * 히스토리(작업일지 관련)
   */
  Future<ResPayload> histories(int selectedPage, {int numOfPage = 10}) async {
    Map data = {
      "CID": ac.signInResource.value.company.id,
      "SP": selectedPage,
      "NOP": numOfPage,
    };

    await post(UrlTool.genPath(UrlTool.History, UrlTool.find), data);

    if (_result) {
      if (selectedPage == 0) {
        ac.historyList.value.clear();
      }
      ac.historyList.value.addAll(
          _payload.dataList.map((data) => History.fromJson(data)).toList());
      ac.historyList.refresh();
    }
    return _payload;
  }

  Future<History> history(String id) async {
    Map data = {
      "_id": id,
    };

    await post(UrlTool.genPath(UrlTool.History, UrlTool.findOne), data);

    History history;
    if (_result) {
      history = History.fromJson(jsonDecode(_payload.data));
    }

    return history;
  }
}

class UrlTool {
  static final String Worker = "/worker";
  static final String History = "/history";

  static final String signIn = "/signin";
  static final String updateOne = "/updateone";
  static final String find = "/find";
  static final String findOne = "/findone";

  static String signInPath() {
    return genPath(Worker, signIn);
  }

  static String genPath(String resource, String role) {
    return resource + role;
  }
}
