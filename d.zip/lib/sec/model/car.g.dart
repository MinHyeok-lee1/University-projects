// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'car.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Car _$CarFromJson(Map<String, dynamic> json) {
  return Car(
    id: json['_id'] as String,
    comID: json['CID'] as String,
    carClass: json['CC'] as int,
    carNumber: json['CN'] as String,
    carPhoneNumber: json['CPN'] as String,
    serialNumber: json['SN'] as String,
  )
    ..createdAt =
        json['CA'] == null ? null : DateTime.parse(json['CA'] as String)
    ..updatedAt =
        json['UA'] == null ? null : DateTime.parse(json['UA'] as String);
}

Map<String, dynamic> _$CarToJson(Car instance) => <String, dynamic>{
      'CA': instance.createdAt?.toIso8601String(),
      'UA': instance.updatedAt?.toIso8601String(),
      '_id': instance.id,
      'CID': instance.comID,
      'CC': instance.carClass,
      'CN': instance.carNumber,
      'CPN': instance.carPhoneNumber,
      'SN': instance.serialNumber,
    };
