// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'history.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

History _$HistoryFromJson(Map<String, dynamic> json) {
  return History(
    id: json['_id'] as String,
    workerID: json['WID'] as String,
    deviceID: json['DID'] as String,
    companyID: json['CID'] as String,
    carID: json['VID'] as String,
    workerName: json['WNM'] as String,
    carNumber: json['CNM'] as String,
    deviceName: json['DNM'] as String,
    deviceNickName: json['DNN'] as String,
    fwVersion: json['VER'] as String,
    endTime: json['ET'] == null ? null : DateTime.parse(json['ET'] as String),
    processData: History._parseToDoubleList(json['PD']),
    maximumPPM: History._parseToDouble(json['MP']),
    finishPPM: History._parseToDouble(json['FP']),
    resultCode: json['RC'] as int,
    course: json['COS'] as int,
  )
    ..createdAt =
        json['CA'] == null ? null : DateTime.parse(json['CA'] as String)
    ..updatedAt =
        json['UA'] == null ? null : DateTime.parse(json['UA'] as String)
    ..resultDetail = (json['RD'] as List)?.map((e) => e as int)?.toList();
}

Map<String, dynamic> _$HistoryToJson(History instance) => <String, dynamic>{
      'CA': instance.createdAt?.toIso8601String(),
      'UA': instance.updatedAt?.toIso8601String(),
      '_id': instance.id,
      'WID': instance.workerID,
      'DID': instance.deviceID,
      'CID': instance.companyID,
      'VID': instance.carID,
      'WNM': instance.workerName,
      'CNM': instance.carNumber,
      'DNM': instance.deviceName,
      'DNN': instance.deviceNickName,
      'VER': instance.fwVersion,
      'ET': instance.endTime?.toIso8601String(),
      'PD': instance.processData,
      'MP': instance.maximumPPM,
      'FP': instance.finishPPM,
      'RC': instance.resultCode,
      'RD': instance.resultDetail,
      'COS': instance.course,
    };
