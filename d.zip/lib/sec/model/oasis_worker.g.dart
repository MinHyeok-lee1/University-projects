// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'oasis_worker.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OasisWorker _$OasisWorkerFromJson(Map<String, dynamic> json) {
  return OasisWorker(
    id: json['_id'] as String,
    comID: json['CID'] as String,
    name: json['WN'] as String,
    phoneNumber: json['PN'] as String,
    googleID: json['GID'] as String,
    email: json['EM'] as String,
    photoURL: json['PU'] as String,
    auth: json['AU'] as int,
    activated: json['AC'] as bool,
  )
    ..createdAt =
        json['CA'] == null ? null : DateTime.parse(json['CA'] as String)
    ..updatedAt =
        json['UA'] == null ? null : DateTime.parse(json['UA'] as String);
}

Map<String, dynamic> _$OasisWorkerToJson(OasisWorker instance) =>
    <String, dynamic>{
      'CA': instance.createdAt?.toIso8601String(),
      'UA': instance.updatedAt?.toIso8601String(),
      '_id': instance.id,
      'CID': instance.comID,
      'WN': instance.name,
      'PN': instance.phoneNumber,
      'GID': instance.googleID,
      'EM': instance.email,
      'PU': instance.photoURL,
      'AU': instance.auth,
      'AC': instance.activated,
    };
