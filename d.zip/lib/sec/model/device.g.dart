// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'device.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Device _$DeviceFromJson(Map<String, dynamic> json) {
  return Device(
    id: json['_id'] as String,
    comID: json['CID'] as String,
    model: json['MD'] as String,
    MAC: json['MAC'] as String,
    version: json['VER'] as String,
    nickName: json['NN'] as String,
    usageTime: json['UT'] == null ? null : DateTime.parse(json['UT'] as String),
    numOfUsage: json['UN'] as int,
  )
    ..createdAt =
        json['CA'] == null ? null : DateTime.parse(json['CA'] as String)
    ..updatedAt =
        json['UA'] == null ? null : DateTime.parse(json['UA'] as String);
}

Map<String, dynamic> _$DeviceToJson(Device instance) => <String, dynamic>{
      'CA': instance.createdAt?.toIso8601String(),
      'UA': instance.updatedAt?.toIso8601String(),
      '_id': instance.id,
      'CID': instance.comID,
      'MD': instance.model,
      'MAC': instance.MAC,
      'VER': instance.version,
      'NN': instance.nickName,
      'UT': instance.usageTime?.toIso8601String(),
      'UN': instance.numOfUsage,
    };
