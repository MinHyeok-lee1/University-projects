import 'package:json_annotation/json_annotation.dart';
import 'package:oasis_app/sec/model/car.dart';
import 'package:oasis_app/sec/model/company.dart';
import 'package:oasis_app/sec/model/device.dart';
import 'package:oasis_app/sec/model/oasis_worker.dart';

part 'sing_in_resource.g.dart';

/**
 * 코드 생성 명령
 * $> flutter pub run build_runner build
 *
 * 자동 코드 생성 명령
 * $> flutter pub run build_runner watch
 */

@JsonSerializable()
class SignInResource {
  OasisWorker worker;
  Company company;
  List<Device> devices = [];
  List<Car> cars = [];

  SignInResource({this.worker,this.company,this.devices,this.cars});

  factory SignInResource.fromJson(Map<String, dynamic> json) =>
      _$SignInResourceFromJson(json);

  Map<String, dynamic> toJson() => _$SignInResourceToJson(this);
}
