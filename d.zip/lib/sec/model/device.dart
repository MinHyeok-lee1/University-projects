import 'package:json_annotation/json_annotation.dart';
import 'package:oasis_app/sec/model/common_datetime.dart';

part 'device.g.dart';

/**
 * 코드 생성 명령
 * $> flutter pub run build_runner build
 *
 * 자동 코드 생성 명령
 * $> flutter pub run build_runner watch
 */

@JsonSerializable()
class Device extends CommonDateTime{
  @JsonKey(name: "_id")
  String id;
  @JsonKey(name: "CID")
  String comID;
  @JsonKey(name: "MD")
  String model;
  @JsonKey(name: "MAC")
  String MAC;
  @JsonKey(name: "VER")
  String version;
  @JsonKey(name: "NN")
  String nickName;
  @JsonKey(name: "UT")
  DateTime usageTime;
  @JsonKey(name: "UN")
  int numOfUsage;
  // @JsonKey(name: "CA")
  // DateTime createdAt;
  // @JsonKey(name: "UA")
  // DateTime updatedAt;

  Device({
    this.id,
    this.comID,
    this.model,
    this.MAC,
    this.version,
    this.nickName,
    this.usageTime,
    this.numOfUsage,
    // this.createdAt,
    // this.updatedAt,
  });

  factory Device.fromJson(Map<String, dynamic> json) => _$DeviceFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceToJson(this);
}
