// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'page_arguments.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PageArguments _$PageArgumentsFromJson(Map<String, dynamic> json) {
  return PageArguments(
    title: json['title'] as String,
    value: json['value'] as String,
    allowEmptyReturnValue: json['allowEmptyReturnValue'] as bool,
    keyboardType: json['keyboardType'] as int,
  );
}

Map<String, dynamic> _$PageArgumentsToJson(PageArguments instance) =>
    <String, dynamic>{
      'title': instance.title,
      'value': instance.value,
      'allowEmptyReturnValue': instance.allowEmptyReturnValue,
      'keyboardType': instance.keyboardType,
    };
