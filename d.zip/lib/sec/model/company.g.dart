// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'company.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Company _$CompanyFromJson(Map<String, dynamic> json) {
  return Company(
    id: json['_id'] as String,
    name: json['NA'] as String,
    address: json['ADR'] as String,
    agentList: json['AL'] as List,
    agentName: json['ANA'] as String,
    agentNumber: json['ANU'] as String,
    AH: json['AH'] as bool,
    carUpdatedAt:
        json['CUA'] == null ? null : DateTime.parse(json['CUA'] as String),
    companyName: json['CNA'] as String,
    companyNumber: json['CNU'] as String,
    EA: json['EA'] as String,
    kind: json['CK'] as String,
    mobileNumber: json['MN'] as String,
    phoneNumber: json['PN'] as String,
    renualUpdateAt:
        json['RUA'] == null ? null : DateTime.parse(json['RUA'] as String),
    servicePoint: json['SPO'] as int,
    servicePointAlarm: json['POA'] as int,
    virtualAccountDate:
        json['VAD'] == null ? null : DateTime.parse(json['VAD'] as String),
    virtualAccountName: json['VA'] as String,
    virtualAccountNumber: json['VAN'] as int,
  )
    ..createdAt =
        json['CA'] == null ? null : DateTime.parse(json['CA'] as String)
    ..updatedAt =
        json['UA'] == null ? null : DateTime.parse(json['UA'] as String);
}

Map<String, dynamic> _$CompanyToJson(Company instance) => <String, dynamic>{
      'CA': instance.createdAt?.toIso8601String(),
      'UA': instance.updatedAt?.toIso8601String(),
      '_id': instance.id,
      'NA': instance.name,
      'AL': instance.agentList,
      'ANA': instance.agentName,
      'ANU': instance.agentNumber,
      'CNU': instance.companyNumber,
      'CNA': instance.companyName,
      'CK': instance.kind,
      'ADR': instance.address,
      'PN': instance.phoneNumber,
      'MN': instance.mobileNumber,
      'AH': instance.AH,
      'EA': instance.EA,
      'SPO': instance.servicePoint,
      'POA': instance.servicePointAlarm,
      'VAN': instance.virtualAccountNumber,
      'VAD': instance.virtualAccountDate?.toIso8601String(),
      'VA': instance.virtualAccountName,
      'CUA': instance.carUpdatedAt?.toIso8601String(),
      'RUA': instance.renualUpdateAt?.toIso8601String(),
    };
