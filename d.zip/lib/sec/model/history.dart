import 'package:intl/intl.dart';
import 'package:json_annotation/json_annotation.dart';

import 'package:oasis_app/sec/model/common_datetime.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;
import 'package:get/get.dart';

part 'history.g.dart';

/**
 * 코드 생성 명령
 * $> flutter pub run build_runner build
 *
 * 자동 코드 생성 명령
 * $> flutter pub run build_runner watch
 */

@JsonSerializable()
class History extends CommonDateTime {
  @JsonKey(name: "_id")
  String id;
  @JsonKey(name: "WID")
  String workerID;
  @JsonKey(name: "DID")
  String deviceID;
  @JsonKey(name: "CID")
  String companyID;
  @JsonKey(name: "VID")
  String carID;
  @JsonKey(name: "WNM")
  String workerName;
  @JsonKey(name: "CNM")
  String carNumber;
  @JsonKey(name: "DNM")
  String deviceName;
  @JsonKey(name: "DNN")
  String deviceNickName;
  @JsonKey(name: "VER")
  String fwVersion;
  @JsonKey(name: "ET")
  DateTime endTime;
  @JsonKey(name: "PD", fromJson: _parseToDoubleList)
  List<double> processData;
  @JsonKey(name: "MP", fromJson: _parseToDouble)
  double maximumPPM;
  @JsonKey(name: "FP", fromJson: _parseToDouble)
  double finishPPM;
  @JsonKey(name: "RC")
  int resultCode;
  @JsonKey(name: "RD")
  List<int> resultDetail = [0, 0, 0];
  @JsonKey(name: "COS")
  int course;

  History({
    this.id,
    this.workerID,
    this.deviceID,
    this.companyID,
    this.carID,
    this.workerName,
    this.carNumber,
    this.deviceName,
    this.deviceNickName,
    this.fwVersion,
    this.endTime,
    this.processData,
    this.maximumPPM,
    this.finishPPM,
    this.resultCode,
    this.course,
  });

  factory History.fromJson(Map<String, dynamic> json) =>
      _$HistoryFromJson(json);

  Map<String, dynamic> toJson() => _$HistoryToJson(this);

  List<int> setResultDetail({int GR, int SR, int RR}) {
    if (GR != null) {
      resultDetail[0] = GR;
    }

    if (SR != null) {
      resultDetail[1] = SR;
    }

    if (RR != null) {
      resultDetail[2] = RR;
    }

    return resultDetail;
  }

  String strEndTime() {
    if (endTime == null) {
      return "N/A";
    }

    String strDateTime =
        DateFormat("yyyy-MM-dd HH:mm").format(endTime.toLocal());
    return strDateTime;
  }

  String strReqTime() {
    if (processData == null || processData.length == 0) {
      return "N/A";
    }

    Duration duration = Duration(seconds: (processData.length));
    int hour = duration.inHours.remainder(60);
    int min = duration.inMinutes.remainder(60);
    int sec = duration.inSeconds.remainder(60);

    String strDuration = "";
    if (hour > 0) {
      strDuration = "$hour" + "hour".tr + " ";
    }
    if (min > 0) {
      strDuration = "$strDuration$min" + "min".tr + " ";
    }
    if (sec > 0) {
      strDuration = "$strDuration$sec" + "sec".tr;
    }
    // return "$min 분 $sec";
    return strDuration;
  }

  String strResult() {
    if (resultCode == null) {
      return "N/A";
    } else if (resultCode == 1) {
      return "성공";
    } else {
      return "실패";
    }
  }

  String strGenResult() {
    if (resultDetail == null || resultDetail.length != 3) {
      return "N/A";
    } else if (resultDetail[0] == 1) {
      return "성공";
    } else if (resultDetail[0] == -1) {
      return "생략";
    } else {
      return "실패";
    }
  }

  String strStayResult() {
    if (resultDetail == null || resultDetail.length != 3) {
      return "N/A";
    } else if (resultDetail[1] == 1) {
      return "성공";
    } else if (resultDetail[1] == -1) {
      return "생략";
    } else {
      return "실패";
    }
  }

  String strReleaseResult() {
    if (resultDetail == null || resultDetail.length != 3) {
      return "N/A";
    } else if (resultDetail[2] == 1) {
      return "성공";
    } else if (resultDetail[2] == -1) {
      return "생략";
    } else {
      return "실패";
    }
  }

  static List<double> _parseToDoubleList(json) {
    return (json == null)
        ? null
        : (json as List)?.map((e) => double.parse(e))?.toList();
  }

  static double _parseToDouble(value) {
    return (value is int) ? (value as int).toDouble() : value;
  }
}
