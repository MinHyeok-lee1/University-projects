import 'package:json_annotation/json_annotation.dart';
import 'package:intl/intl.dart';
import 'package:oasis_app/sec/model/common_datetime.dart';
import 'package:get/get.dart';
part 'oasis_worker.g.dart';

/**
 * 코드 생성 명령
 * $> flutter pub run build_runner build
 *
 * 자동 코드 생성 명령
 * $> flutter pub run build_runner watch
 */

@JsonSerializable()
class OasisWorker extends CommonDateTime {
  static _WorkerAuth Auth = _WorkerAuth();
  static final List<String> _strAuthList = [
    "platform_admin".tr,
    "worker".tr,
    "manager".tr,
    "seller".tr,
  ];

  @JsonKey(name: "_id")
  String id;
  @JsonKey(name: "CID")
  String comID;
  @JsonKey(name: "WN")
  String name;
  @JsonKey(name: "PN")
  String phoneNumber;
  @JsonKey(name: "GID")
  String googleID;
  @JsonKey(name: "EM")
  String email;
  @JsonKey(name: "PU")
  String photoURL;
  @JsonKey(name: "AU")
  int auth; // Auth, 0: MK 관리자, 1: 사업주, 2: 작업자
  @JsonKey(name: "AC")
  bool activated;

  // @JsonKey(name: "CA")
  // DateTime createdAt;
  // @JsonKey(name: "UA")
  // DateTime updatedAt;

  OasisWorker({
    this.id,
    this.comID,
    this.name,
    this.phoneNumber,
    this.googleID,
    this.email,
    this.photoURL,
    this.auth,
    this.activated,
    // this.createdAt,
    // this.updatedAt,
  });

  factory OasisWorker.fromJson(Map<String, dynamic> json) =>
      _$OasisWorkerFromJson(json);

  Map<String, dynamic> toJson() => _$OasisWorkerToJson(this);

  String getStrAuth() {
    return _strAuthList[auth];
  }
}

class _WorkerAuth {
  /**
   * 작업자의 권한
   * 0: MK 관리자, 1: 사업주, 2: 작업자: 3
   * [중용] 권한 수정 시 Worker._strAuthList도 수정해야함
   */

  final int MK_ADMIN_0 = 0; // 본사 소속 관리자
  final int COM_WORKER_1 = 1; // 고객사 직원
  final int COM_MANAGER_2 = 2; // 고객사 관리자
  final int SELLER_3 = 3; // 대리점
}
