// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sing_in_resource.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SignInResource _$SignInResourceFromJson(Map<String, dynamic> json) {
  return SignInResource(
    worker: json['worker'] == null
        ? null
        : OasisWorker.fromJson(json['worker'] as Map<String, dynamic>),
    company: json['company'] == null
        ? null
        : Company.fromJson(json['company'] as Map<String, dynamic>),
    devices: (json['devices'] as List)
        ?.map((e) =>
            e == null ? null : Device.fromJson(e as Map<String, dynamic>))
        ?.toList(),
    cars: (json['cars'] as List)
        ?.map((e) => e == null ? null : Car.fromJson(e as Map<String, dynamic>))
        ?.toList(),
  );
}

Map<String, dynamic> _$SignInResourceToJson(SignInResource instance) =>
    <String, dynamic>{
      'worker': instance.worker,
      'company': instance.company,
      'devices': instance.devices,
      'cars': instance.cars,
    };
