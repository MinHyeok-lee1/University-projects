import 'package:json_annotation/json_annotation.dart';
import 'package:oasis_app/sec/model/common_datetime.dart';

part 'company.g.dart';

/**
 * 코드 생성 명령
 * $> flutter pub run build_runner build
 *
 * 자동 코드 생성 명령
 * $> flutter pub run build_runner watch
 */

@JsonSerializable()
class Company extends CommonDateTime{
  @JsonKey(name: "_id")
  String id;
  @JsonKey(name: "NA")
  String name;
  @JsonKey(name: "AL")
  List<Object> agentList; // 형식 맞추어야
  @JsonKey(name: "ANA")
  String agentName;
  @JsonKey(name: "ANU")
  String agentNumber;
  @JsonKey(name: "CNU")
  String companyNumber;
  @JsonKey(name: "CNA")
  String companyName;
  @JsonKey(name: "CK",)
  String kind;
  @JsonKey(name: "ADR")
  String address;
  @JsonKey(name: "PN")
  String phoneNumber;
  @JsonKey(name: "MN")
  String mobileNumber;
  @JsonKey(name: "AH")
  bool AH;
  @JsonKey(name: "EA")
  String EA;
  @JsonKey(name: "SPO")
  int servicePoint;
  @JsonKey(name: "POA")
  int servicePointAlarm;
  @JsonKey(name: "VAN")
  int virtualAccountNumber;
  @JsonKey(name: "VAD")
  DateTime virtualAccountDate;
  @JsonKey(name: "VA")
  String virtualAccountName;
  @JsonKey(name: "CUA")
  DateTime carUpdatedAt;
  @JsonKey(name: "RUA")
  DateTime renualUpdateAt;
  // @JsonKey(name: "CA")
  // DateTime createdAt;
  // @JsonKey(name: "UA")
  // DateTime updatedAt;

  Company({
    this.id,
    this.name,
    this.address,
    this.agentList,
    this.agentName,
    this.agentNumber,
    this.AH,
    this.carUpdatedAt,
    this.companyName,
    this.companyNumber,
    this.EA,
    this.kind,
    this.mobileNumber,
    this.phoneNumber,
    this.renualUpdateAt,
    this.servicePoint,
    this.servicePointAlarm,
    this.virtualAccountDate,
    this.virtualAccountName,
    this.virtualAccountNumber,
    // this.createdAt,
    // this.updatedAt,
  });

  factory Company.fromJson(Map<String, dynamic> json) =>
      _$CompanyFromJson(json);

  Map<String, dynamic> toJson() => _$CompanyToJson(this);
}
