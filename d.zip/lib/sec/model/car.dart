import 'package:json_annotation/json_annotation.dart';
import 'package:oasis_app/sec/model/common_datetime.dart';

part 'car.g.dart';

/**
 * 코드 생성 명령
 * $> flutter pub run build_runner build
 *
 * 자동 코드 생성 명령
 * $> flutter pub run build_runner watch
 */

@JsonSerializable()
class Car extends CommonDateTime{
  @JsonKey(name: "_id")
  String id;
  @JsonKey(name: "CID")
  String comID;
  @JsonKey(name: "CC")
  int carClass;
  @JsonKey(name: "CN")
  String carNumber;
  @JsonKey(name: "CPN")
  String carPhoneNumber;
  @JsonKey(name: "SN")
  String serialNumber;
  // @JsonKey(name: "CA")
  // DateTime createdAt;
  // @JsonKey(name: "UA")
  // DateTime updatedAt;

  Car({
    this.id,
    this.comID,
    this.carClass,
    this.carNumber,
    this.carPhoneNumber,
    this.serialNumber,
    // this.createdAt,
    // this.updatedAt,
  });

  factory Car.fromJson(Map<String, dynamic> json) =>
      _$CarFromJson(json);

  Map<String, dynamic> toJson() => _$CarToJson(this);
}
