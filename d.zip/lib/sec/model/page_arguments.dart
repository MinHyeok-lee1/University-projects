import 'package:flutter/material.dart';
import 'package:json_annotation/json_annotation.dart';

part 'page_arguments.g.dart';

/**
 * 코드 생성 명령
 * $> flutter pub run build_runner build
 *
 * 자동 코드 생성 명령
 * $> flutter pub run build_runner watch
 */

@JsonSerializable()
class PageArguments {
  static final int keyboardTypeDefault = 0;
  static final int keyboardTypeNumber = 1;

  String title;
  String value;
  bool allowEmptyReturnValue;
  int keyboardType = 0;

  PageArguments({
    this.title,
    this.value,
    this.allowEmptyReturnValue = false,
    this.keyboardType = 0,
  });

  factory PageArguments.fromJson(Map<String, dynamic> json) =>
      _$PageArgumentsFromJson(json);

  Map<String, dynamic> toJson() => _$PageArgumentsToJson(this);
}
