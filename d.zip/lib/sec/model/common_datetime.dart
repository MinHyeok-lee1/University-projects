import 'package:json_annotation/json_annotation.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;

class CommonDateTime {
  @JsonKey(name: "CA")
  DateTime createdAt;
  @JsonKey(name: "UA")
  DateTime updatedAt;

  String strCreatedAt() {
    return lb.TimeHelper.dtToStr(createdAt);
  }

  String strUpdatedAt() {
    return lb.TimeHelper.dtToStr(updatedAt);
  }
}
