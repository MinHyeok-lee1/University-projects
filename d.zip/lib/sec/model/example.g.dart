// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'example.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Example _$ExampleFromJson(Map<String, dynamic> json) {
  $checkKeys(json, requiredKeys: const ['age']);
  return Example(
    firstName: json['firstName'] as String,
    lastName: json['last_name'] as String ?? 'Park',
    age: json['age'] as int,
  );
}

Map<String, dynamic> _$ExampleToJson(Example instance) => <String, dynamic>{
      'firstName': instance.firstName,
      'last_name': instance.lastName,
      'age': instance.age,
    };
