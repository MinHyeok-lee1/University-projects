import 'package:json_annotation/json_annotation.dart';

part 'res_payload.g.dart';

/**
 * 코드 생성 명령
 * $> flutter pub run build_runner build
 *
 * 자동 코드 생성 명령
 * $> flutter pub run build_runner watch
 */

@JsonSerializable()
class ResPayload {
  static const String UNKNOWN = "UNKNOWN";
  static const String NO_SUCH_DATA = "NO_SUCH_DATA";
  static const String FAIL = "FAIL";
  static const String TOKEN_ERROR = "TOKEN_ERROR";

  bool result;
  String data;
  List dataList;
  String error;
  String token;

  ResPayload({this.result, this.data, this.error, this.token, this.dataList});

  factory ResPayload.fromJson(Map<String, dynamic> json) =>
      _$ResPayloadFromJson(json);

  Map<String, dynamic> toJson() => _$ResPayloadToJson(this);
}
