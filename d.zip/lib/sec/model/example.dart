import 'package:json_annotation/json_annotation.dart';

part 'example.g.dart';

/**
 * 코드 생성 명령
 * $> flutter pub run build_runner build
 *
 * 자동 코드 생성 명령
 * $> flutter pub run build_runner watch
 */

@JsonSerializable()
class Example {
  String firstName;
  @JsonKey(name: "last_name", defaultValue: "Park")
  String lastName;
  @JsonKey(required: true)
  int age;

  Example({this.firstName, this.lastName, this.age});

  factory Example.fromJson(Map<String, dynamic> json) =>
      _$ExampleFromJson(json);

  Map<String, dynamic> toJson() => _$ExampleToJson(this);
}
