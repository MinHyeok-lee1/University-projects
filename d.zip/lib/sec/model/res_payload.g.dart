// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'res_payload.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ResPayload _$ResPayloadFromJson(Map<String, dynamic> json) {
  return ResPayload(
    result: json['result'] as bool,
    data: json['data'] as String,
    error: json['error'] as String,
    token: json['token'] as String,
    dataList: json['dataList'] as List,
  );
}

Map<String, dynamic> _$ResPayloadToJson(ResPayload instance) =>
    <String, dynamic>{
      'result': instance.result,
      'data': instance.data,
      'dataList': instance.dataList,
      'error': instance.error,
      'token': instance.token,
    };
