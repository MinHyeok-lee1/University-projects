import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:intl/intl.dart';
import 'package:logger/logger.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/sec/model/page_arguments.dart';

Logger logger = Logger(
  printer: PrettyPrinter(methodCount: 3),
);

GetPage getCurrentPage() {
  GetPage page;
  AppManager.pages.forEach((GetPage _page) {
    if (_page.name == Get.currentRoute) {
      page = _page;
    }
  });
  return page;
}

Widget getCurrentChildArea() {
  GetPage page = getCurrentPage();
  return page.children[0].page();
}


class TimeHelper {
  static final DateFormat dateTimeFormat = DateFormat("yyyy-MM-dd HH:mm");

  static String dtToStr(DateTime dt) {
    if (dt == null) {
      return "N/A";
    }
    return dateTimeFormat.format(dt.toLocal());
  }
}

class AckTimer {
  static Timer ackTimer;
  static void Function() _callback;

  static bool start({int seconds = 2, void Function() callback}) {
    if (ackTimer != null && ackTimer.isActive) {
      return false;
    } else {
      _callback = callback;
      ackTimer = Timer(Duration(seconds: seconds), _callback);
      return true;
    }
  }

  static bool cancel({bool invokeCallback = false}) {
    if (ackTimer != null && ackTimer.isActive) {
      ackTimer.cancel();
      if (invokeCallback) {
        _callback();
        _callback = null;
      }
      return true;
    } else {
      return false;
    }
  }
}
