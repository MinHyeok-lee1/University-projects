import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:oasis_app/sec/controller/app_controller.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/sec/model/car.dart';
import 'package:oasis_app/sec/model/device.dart';
import 'package:oasis_app/sec/model/history.dart';
import 'package:oasis_app/sec/model/page_arguments.dart';
import 'package:oasis_app/sec/tool_box/logic_box.dart' as lb;

/** 테마 관련 **/
ThemeData buttonThemeData = ThemeData(
  elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
          primary: Colors.cyan,
          minimumSize: Size(150.w, 100.w),
          textStyle: TextStyle(fontSize: 40.w))),
  outlinedButtonTheme: OutlinedButtonThemeData(
      style: ElevatedButton.styleFrom(
          // primary: Colors.cyan,
          minimumSize: Size(150.w, 100.w),
          textStyle: TextStyle(fontSize: 40.w))),
);

class PageTheme {
  static final ThemeData _introThemeData = ThemeData(
    scaffoldBackgroundColor: Colors.white,
  );
  static final ThemeData _normalThemeData = ThemeData(
    scaffoldBackgroundColor: Colors.transparent,
  );
  static const int introPage = 0;
  static const int normalPage = 1;

  static setPageTheme({int pageTheme = normalPage}) {
    if (pageTheme == introPage) {
      SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        systemNavigationBarColor: Colors.white,
      ));
      Get.changeTheme(_introThemeData);
    } else if (pageTheme == normalPage) {
      SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        systemNavigationBarColor: Colors.transparent,
      ));
      Get.changeTheme(_normalThemeData);
    }
  }
}

Widget appBar({String pageTitle}) {
  String title = pageTitle ?? lb.getCurrentPage()?.title;
  return (title != null)
      ? AppBar(
          backgroundColor: Colors.transparent,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back_ios_outlined,
              color: MyColors.greyDark,
            ),
            onPressed: () {
              Get.back();
            },
          ),
          titleSpacing: 0,
          title: Container(
            child: TextWidgets.pageTitle(title,
                color: Colors.black,
                alignment: Alignment.centerLeft,
                vertical: 0,
                horizontal: 0),
          ),
          elevation: 0,
        )
      : null;
}

class MyColors {
  static final Color yellow = Color(0xFFFFDB3D);
  static final Color grey = Colors.grey[300];
  static final Color greyLight = Colors.grey[200];
  static final Color greyDark = Colors.grey[500];
  static final Color textInfo = Colors.black54;
  static final Color selected = Colors.lightBlueAccent;
}

class AreaWidgets {
  static Widget container({
    Widget child,
    String title,
    String badge,
    Widget tail,
    String info,
    double height,
    double marginVertical,
    double marginHorizontal,
    double paddingVertical,
    double paddingHorizontal,
    Color bgColor,
    bool centerAlignment = false,
    bool isExpanded = false,
    bool isNoBottom = false,
  }) {
    List<Widget> children = [];
    if (title != null) {
      children.add(
        Row(
          children: [
            TextWidgets.title(title),
            TextWidgets.badge((badge != null) ? " $badge" : ""),
            Expanded(child: Container()),
            tail ?? Container(),
          ],
        ),
      );
    }
    if (info != null) {
      children.add(TextWidgets.info(info));
    }

    children.add((isExpanded) ? Expanded(child: child) : child);
    // children.add(child);
    Container con = Container();

    if (child != null)
      con = Container(
        height: height,
        margin: EdgeInsets.symmetric(
          vertical: marginVertical ?? 30.w,
          horizontal: marginHorizontal ?? 30.w,
        ).copyWith(bottom: (isNoBottom) ? 0 : null),
        padding: EdgeInsets.symmetric(
          vertical: paddingVertical ?? 10.w,
          horizontal: paddingHorizontal ?? 10.w,
        ).copyWith(bottom: (isNoBottom) ? 0 : null),
        decoration: BoxDecoration(
          color: bgColor ?? null,
          borderRadius: BorderRadius.circular(10.w),
        ),
        // alignment: centerAlignment ? Alignment.center : null,
        child: Column(
          children: children,
        ),
      );

    if (isExpanded) {
      return Expanded(child: con);
    }

    return con;
  }

  static Widget containerBgGrey({
    Widget child,
    String title,
    String badge,
    Widget tail,
    String info,
    double height,
    double marginVertical,
    double marginHorizontal,
    double paddingVertical,
    double paddingHorizontal,
    Color bgColor,
    bool centerAlignment = false,
    bool isExpanded = false,
    bool isNoBottom = false,
  }) {
    return container(
      child: child,
      title: title,
      badge: badge,
      tail: tail,
      info: info,
      height: height,
      marginVertical: marginVertical,
      marginHorizontal: marginHorizontal,
      paddingVertical: paddingVertical ?? 30.w,
      paddingHorizontal: paddingHorizontal ?? 30.w,
      bgColor: Colors.grey[200],
      centerAlignment: centerAlignment,
      isExpanded: isExpanded,
      isNoBottom: isNoBottom,
    );
  }

  static Widget card(
      {Widget child,
      double elevation,
      double verticalMargin,
      double horizontalMargin,
      double verticalPadding,
      double horizontalPadding,
      double top}) {
    return Card(
      elevation: elevation ?? 10.w,
      margin: EdgeInsets.symmetric(
          vertical: verticalMargin ?? 10.h,
          horizontal: horizontalMargin ?? 10.w),
      child: Container(
        padding: EdgeInsets.symmetric(
                vertical: verticalPadding ?? 15.h,
                horizontal: horizontalPadding ?? 40.w)
            .copyWith(top: top ?? 20.h),
        child: child,
      ),
    );
  }
}

class ComponentWidgets {
  static Widget loading({String title = "LOADING", bool isShowing = true}) {
    return Center(
      child: Container(
        alignment: Alignment.center,
        // padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        width: 120,
        height: 120,
        decoration: BoxDecoration(
          color: MyColors.greyDark,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.only(top: 15.h),
              child: CircularProgressIndicator(),
            ),
            Container(
              margin: EdgeInsets.only(top: 15.h),
              child: Text(
                title,
                style:
                    TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Widget keyValueCard(String key, String value) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5.w),
      padding: EdgeInsets.symmetric(vertical: 30.w, horizontal: 30.w),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(10.w)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          TextWidgets.key(key),
          Expanded(
            child: Container(
              alignment: Alignment.centerRight,
              child: TextWidgets.value(value, alignment: Alignment.centerRight),
            ),
          ),
        ],
      ),
    );
  }

  static Widget wideButton(String title,
      {Icon icon, double width, double height, void Function() onPressed}) {
    Widget child;
    if (icon == null) {
      child = ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          primary: MyColors.selected,
          alignment: Alignment.center,
        ),
        child: Text(title),
      );
    } else {
      child = ElevatedButton.icon(
        onPressed: onPressed,
        icon: icon,
        style: ElevatedButton.styleFrom(
          primary: MyColors.selected,
          alignment: Alignment.center,
        ),
        label: Text(title),
      );
    }
    return Container(
      width: width ?? 0.9.sw,
      height: height,
      child: child,
    );
  }

  static Widget itemTitle(String title, {double top}) {
    return Container(
      margin: (top != null) ? EdgeInsets.only(top: top) : null,
      color: MyColors.greyLight,
      child: TextWidgets.info(title, horizontal: 40.w, vertical: 20.w),
    );
  }

  static Widget item(
    String key,
    String value, {
    void Function() onTap,
    bool isLastItem = false,
    Icon icon,
  }) {
    return Container(
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(vertical: 40.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                TextWidgets.key(
                  key,
                  horizontal: 30.w,
                  minWidth: 300.w,
                  maxWidth: 300.w,
                ),
                Expanded(
                  child: TextWidgets.value(
                    value,
                    horizontal: 30.w,
                    maxWidth: 700.w,
                    alignment: Alignment.centerRight,
                    color: (onTap != null) ? MyColors.selected : null,
                  ),
                ),
                (onTap != null)
                    ? InkWell(
                        child: Container(
                          margin: EdgeInsets.only(right: 20.w),
                          child: Icon(
                            icon?.icon ?? Icons.keyboard_arrow_right,
                            color: MyColors.greyDark,
                          ),
                        ),
                        onTap: onTap,
                      )
                    : Container(),
              ],
            ),
          ),
          (isLastItem)
              ? Container()
              : Divider(
                  height: 1.h,
                  thickness: 0.7,
                  color: MyColors.grey,
                )
        ],
      ),
    );
  }

  static Widget bordered(String title,
      {double height, Icon icon, Color bgColor, Color textColor}) {
    return Container(
      height: height ?? 45.h,
      margin: EdgeInsets.only(right: 15.w),
      padding: EdgeInsets.symmetric(horizontal: 15.w),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.w),
        border: Border.all(color: MyColors.greyDark, width: 2.w),
        color: bgColor,
      ),
      child: Row(
        children: [
          (icon != null)
              ? Container(
                  padding: EdgeInsets.only(right: 15.w),
                  child: Icon(
                    icon.icon,
                    size: 40.w,
                    color: textColor ?? MyColors.greyDark,
                  ),
                )
              : Container(),
          TextWidgets.value(title, color: textColor),
        ],
      ),
    );
  }
}

class TextWidgets {
  static TextStyle tsMarker = TextStyle(
    fontSize: 60.w,
    fontWeight: FontWeight.bold,
  );
  static TextStyle tsTitle = TextStyle(
    fontSize: 50.w,
    fontWeight: FontWeight.bold,
  );
  static TextStyle tsInfo = TextStyle(
    fontSize: 40.w,
    color: MyColors.textInfo,
  );
  static TextStyle tsKey = TextStyle(
    fontWeight: FontWeight.bold,
    fontSize: 45.w,
  );
  static TextStyle tsValue = TextStyle(
    fontSize: 45.w,
  );
  static TextStyle tsBadge = TextStyle(
    fontSize: 45.w,
    fontWeight: FontWeight.bold,
    color: Colors.lightBlueAccent,
  );

  static Widget _text(
    String title, {
    Alignment alignment,
    TextStyle style,
    double vertical,
    double horizontal,
    double maxWidth,
    double minWidth,
    Color color,
    bool bold,
  }) {
    style = (bold == null)
        ? style
        : (bold)
            ? style.copyWith(fontWeight: FontWeight.bold)
            : style.copyWith(fontWeight: FontWeight.normal);
    style = (color == null) ? style : style.copyWith(color: color);
    return Container(
      alignment: alignment ?? Alignment.centerLeft,
      constraints: BoxConstraints(
          maxWidth: maxWidth ?? double.infinity, minWidth: minWidth ?? 0),
      padding: EdgeInsets.symmetric(
        vertical: vertical ?? 0.w,
        horizontal: horizontal ?? 0.w,
      ),
      // color: color,
      child: Text(
        title,
        style: style,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  static Widget pageTitle(
    String title, {
    Alignment alignment,
    double vertical,
    double horizontal,
    double maxWidth,
    double minWidth,
    Color color,
    bool bold,
  }) {
    return _text(
      title,
      alignment: alignment,
      bold: bold,
      vertical: vertical ?? 30.w,
      horizontal: horizontal ?? 30.w,
      maxWidth: maxWidth,
      color: color,
      style: tsTitle.copyWith(fontWeight: FontWeight.w900),
    );
  }

  static Widget marker(
    String title, {
    Alignment alignment,
    double vertical,
    double horizontal,
    double maxWidth,
    double minWidth,
    Color color,
    bool bold,
  }) {
    return _text(
      title,
      alignment: alignment,
      bold: bold,
      vertical: vertical ?? 20.w,
      horizontal: horizontal ?? 0.w,
      maxWidth: maxWidth,
      minWidth: minWidth,
      color: color,
      style: tsMarker,
    );
  }

  static Widget title(
    String title, {
    Alignment alignment,
    double vertical,
    double horizontal,
    double maxWidth,
    double minWidth,
    Color color,
    bool bold,
  }) {
    return _text(
      title,
      alignment: alignment,
      bold: bold,
      vertical: vertical ?? 20.w,
      horizontal: horizontal ?? 0.w,
      maxWidth: maxWidth,
      minWidth: minWidth,
      color: color,
      style: tsTitle,
    );
  }

  static Widget info(
    String title, {
    Alignment alignment,
    double vertical,
    double horizontal,
    double maxWidth,
    double minWidth,
    Color color,
    bool bold,
  }) {
    return _text(
      title,
      alignment: alignment,
      bold: bold,
      vertical: vertical ?? 15.w,
      horizontal: horizontal ?? 0.w,
      maxWidth: maxWidth,
      minWidth: minWidth,
      color: color,
      style: tsInfo,
    );
  }

  static Widget key(
    String title, {
    Alignment alignment,
    double vertical,
    double horizontal,
    double maxWidth,
    double minWidth,
    Color color,
    bool bold,
  }) {
    return _text(
      title,
      alignment: alignment,
      bold: bold,
      vertical: vertical,
      horizontal: horizontal,
      maxWidth: maxWidth,
      minWidth: minWidth,
      color: color,
      style: tsKey,
    );
  }

  static Widget value(
    String title, {
    Alignment alignment,
    double vertical,
    double horizontal,
    double maxWidth,
    double minWidth,
    Color color,
    bool bold,
  }) {
    return _text(
      title,
      alignment: alignment,
      bold: bold,
      vertical: vertical,
      horizontal: horizontal,
      maxWidth: maxWidth,
      minWidth: minWidth,
      color: color,
      style: tsValue,
    );
  }

  static Widget badge(
    String title, {
    Alignment alignment,
    double vertical,
    double horizontal,
    double maxWidth,
    double minWidth,
    Color color,
    bool bold,
  }) {
    return _text(
      title,
      alignment: alignment,
      bold: bold,
      vertical: vertical,
      horizontal: horizontal,
      maxWidth: maxWidth,
      minWidth: minWidth,
      color: color,
      style: tsBadge,
    );
  }

  static Widget underline(String title,
      {bool isSelected = false, void Function() onTap}) {
    return InkWell(
      child: Container(
        margin: EdgeInsets.only(right: 30.w),
        padding: EdgeInsets.only(bottom: 3.h),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: (isSelected) ? MyColors.selected : Colors.transparent,
              width: 4.h,
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 50.w,
                // fontWeight: FontWeight.bold,
                color: (isSelected) ? MyColors.selected : null,
              ),
            ),
          ],
        ),
      ),
      onTap: onTap,
    );
  }
}

class OasisWidgets {
  static Widget nameAndMAC(String name, String mac) {
    return Column(
      children: [
        TextWidgets.title(name),
        TextWidgets.info(mac),
      ],
    );
  }

  static Widget thumb(Device device, {bool isConnected = true}) {
    return Container(
      width: 500.w,
      child: AreaWidgets.card(
        child: Column(
          children: [
            TextWidgets.title(device.nickName ?? device.model),
            TextWidgets.info(device.MAC, vertical: 0.w),
            Container(
              alignment: Alignment.centerRight,
              margin: EdgeInsets.only(top: 10.w),
              child: Icon(
                Icons.devices,
                size: 100.w,
                color: isConnected ? MyColors.selected : null,
              ),
            ),
            ComponentWidgets.wideButton("소독 시작"),
          ],
        ),
      ),
    );
  }

  static Widget tile(Device device, {bool isModifyMode = false}) {
    Widget header = Container();
    Widget tail = Container(width: 30.w);

    if (isModifyMode == false) {
      header = Container(
        child: IconButton(
          onPressed: null,
          icon: Icon(Icons.check_circle_outline),
          color: MyColors.grey,
        ),
      );
    } else {
      tail = Container(
        width: 50.w,
        child: IconButton(
          onPressed: () {
            Get.to(AppManager.page_oasis_modify.page,
                arguments:
                    PageArguments(title: "장비 수정", value: device.id).toJson());
          },
          icon: Icon(Icons.more_vert),
          color: MyColors.grey,
        ),
      );
    }
    return Container(
      child: AreaWidgets.card(
        horizontalPadding: (isModifyMode == false) ? 0.w : null,
        child: Row(
          children: [
            header,
            Expanded(
              child: Column(
                children: [
                  TextWidgets.title(device.nickName ?? device.model ?? "N/A"),
                  TextWidgets.info(device.MAC, vertical: 0.w),
                ],
              ),
            ),
            Icon(
              Icons.devices,
              size: 120.w,
              color: MyColors.grey,
            ),
            tail,
          ],
        ),
      ),
    );
  }
}

class CarWidgets {
  static Widget tile(Car car, {String filterText}) {
    if (filterText != null &&
        filterText.isNotEmpty &&
        !car.carNumber.contains(filterText)) return Container();
    return Container(
      child: AreaWidgets.card(
        verticalPadding: 50.w,
        top: 30.w,
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  TextWidgets.title(
                    car.carNumber,
                    vertical: 20.w,
                  ),
                  TextWidgets.info(
                    "등록".tr + "  ${car.strCreatedAt()}",
                    maxWidth: 700.w,
                    alignment: Alignment.centerLeft,
                    vertical: 0.w,
                  ),
                  TextWidgets.info(
                    "수정".tr + "  ${car.strUpdatedAt()}",
                    maxWidth: 700.w,
                    alignment: Alignment.centerLeft,
                    vertical: 0.w,
                  ),
                ],
              ),
            ),
            Icon(
              Icons.car_rental,
              size: 120.w,
              color: MyColors.grey,
            ),
            Container(
              width: 50.w,
              child: IconButton(
                onPressed: null,
                icon: Icon(Icons.more_vert),
                color: MyColors.grey,
              ),
            )
          ],
        ),
      ),
    );
  }
}

class KeyboardUtils {
  static hideKeyboard(BuildContext context) {
    FocusScope.of(context).unfocus();
  }
}

class TextFields {
  static Widget withDeleteButton(
    State state, {
    TextEditingController controller,
    String hintText,
    Icon icon,
    double marginVertical,
    double marginHorizontal,
    double paddingHorizontal,
    void Function() onPressed,
    void Function(String) onChanged,
    TextInputType keyboardType,
  }) {
    void onPressedTextFieldIcon() async {
      state.setState(() {
        controller.clear();
        KeyboardUtils.hideKeyboard(state.context);
      });
    }

    void onChangedFilterText(String value) {
      state.setState(() {});
    }

    return AreaWidgets.container(
      marginVertical: marginVertical ?? 10.w,
      marginHorizontal: marginHorizontal ?? 50.w,
      paddingHorizontal: paddingHorizontal ?? 0.w,
      child: TextField(
        keyboardType: keyboardType,
        decoration: InputDecoration(
          hintText: hintText,
          suffixIcon: (controller.text.length == 0)
              ? null
              : IconButton(
                  icon: icon ?? Icon(Icons.clear),
                  onPressed: onPressed ?? onPressedTextFieldIcon,
                ),
        ),
        controller: controller,
        onChanged: (value) {
          if (onChanged == null) {
            onChangedFilterText(value);
          } else {
            onChanged(value);
          }
        },
      ),
    );
  }
}

class HistoryWidget {
  static Widget listItem(History history) {
    return InkWell(
      child: AreaWidgets.card(
        verticalPadding: 10.h,
        verticalMargin: 5.h,
        elevation: 3,

        // top: 20.h,
        child: Column(
          children: [
            TextWidgets.info("${history.strEndTime()} / ${history.workerName}",
                vertical: 0.w),
            Row(
              children: [
                Expanded(
                    child: TextWidgets.title("${history.carNumber}  ",
                        vertical: 0.w)),
                ComponentWidgets.bordered(
                  history.deviceNickName ?? history.deviceName,
                  icon: Icon(Icons.devices),
                ),
                Chip(
                  label: Text(
                    history.strResult(),
                    style: TextStyle(color: Colors.white),
                  ),
                  backgroundColor: (history.resultCode == 1)
                      ? Colors.lightBlueAccent
                      : Colors.red,
                  padding: EdgeInsets.symmetric(horizontal: 10.w),
                )
              ],
            )
          ],
        ),
      ),
      onTap: () {
        Get.to(AppManager.page_history.page,
            arguments: PageArguments(
                    title: "disinfection_details".tr, value: history.id)
                .toJson());
      },
    );
  }
}

class MyPageWidgets {
  static Widget profileWidget() {
    AppController ac = Get.find<AppController>();
    return AreaWidgets.container(
      paddingHorizontal: 10.w,
      child: Row(
        children: [
          Container(
            height: 120.w,
            width: 120.w,
            // color: Colors.red,
            margin: EdgeInsets.only(right: 30.w),
            child: CircleAvatar(
              backgroundImage:
                  NetworkImage(ac.signInResource.value.worker.photoURL),
              backgroundColor: Colors.grey[200],
            ),
          ),
          Expanded(
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Obx(() => TextWidgets.key(
                      ac.signInResource.value.company.companyName,
                      maxWidth: 700.w,
                    )),
                Obx(
                  () => RichText(
                    text: TextSpan(
                      style: TextWidgets.tsMarker.copyWith(color: Colors.black),
                      text: ac.signInResource.value.worker.name,
                      children: <TextSpan>[
                        TextSpan(
                          style: TextWidgets.tsMarker
                              .copyWith(fontWeight: FontWeight.normal),
                          text: "sir".tr,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
