import 'dart:async';
import 'dart:convert';
import 'package:enum_to_string/enum_to_string.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart'
    as BtSerial;
import 'package:oasis_app/bt_protocol/BtProtocol.dart';
import 'package:oasis_app/model/worker.dart';
import 'package:oasis_app/pages/device_management/device_registration_area.dart';
import 'package:oasis_app/pages/oasis/oasis_area.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

const String _oasisDevName = "OASIS";
const String _oasisServiceID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"; // 원본
const String _meterDevName = "MK_METER";
const String _meterServiceID = "0000ffe0-0000-1000-8000-00805f9b34fb";

class BleProvider with ChangeNotifier {
  BleProvider() {
    logger.d("### BLE Provider");
    _initListener();
  }

  static final FlutterBlue _flutterBlue = FlutterBlue.instance;

  static List<Meter> meterList = [];
  static List<Oasis> oasisList = [];

  static _BleListWidget oasisWidgetList = _BleListWidget(
    showOasis: true,
    showMeter: false,
  );
  static _BleListWidget meterWidgetList = _BleListWidget(
    showMeter: true,
    showOasis: false,
  );
  static _BleListWidget unRegOasisWidgetList = _BleListWidget(
    showOasis: true,
    showMeter: false,
    showUnRegOasisOnly: true,
  );

  static bool isScanning = false;

  static bool needBlink = true; // 데이터 수신시 화면을 깜빡일지 여부,

  static List<double> meterDataList = [0, 0, 0, 0, 0, 0];

  // 안드로이드에 페어된 오아시스가 있을 경우 페러잉 제거
  static removePairedOasis() async {
    List<BtSerial.BluetoothDevice> list =
        await BtSerial.FlutterBluetoothSerial.instance.getBondedDevices();
    for (BtSerial.BluetoothDevice device in list) {
      if (device.name.startsWith(_oasisDevName)) {
        await BtSerial.FlutterBluetoothSerial.instance
            .removeDeviceBondWithAddress(device.address);
      }
    }
  }

  void _initListener() async {
    _flutterBlue.isScanning.listen((bool event) {
      isScanning = event;
      notifyListeners();
    });

    _flutterBlue.scanResults.listen((List<ScanResult> results) {
      for (ScanResult result in results) {
        if (result.device.name.startsWith(_meterDevName)) {
          _addInMeterList(result.device);
        } else if (result.device.name.startsWith(_oasisDevName)) {
          _addInOasisList(result.device);
        }
      }
    });
  }

  void startScan() async {
    if (isScanning) {
      logger.d("# BLE Scanning already");
      return;
    }

    logger.d("# start BLE Scan");
    // 오아시스 안전하게 삭제함
    for (Oasis oasis in oasisList) {
      oasis.destroy();
    }
    oasisList.clear();

    // 메터기 리스트를 안전하게 삭제함
    for (Meter meter in meterList) {
      meter.destroy();
    }
    // 메터키 리스트 초기화
    meterList.clear();

    // 기 연결된 장치로 메터기 리스트 재구성
    List<BluetoothDevice> devices = await _flutterBlue.connectedDevices;
    for (BluetoothDevice device in devices) {
      if (device.name.startsWith(_oasisDevName)) {
        _addInOasisList(device);
      }
      if (device.name.startsWith(_meterDevName)) {
        _addInMeterList(device);
      }
    }

    // 스캔 시작
    _flutterBlue
        .startScan(timeout: Duration(seconds: 5))
        .whenComplete(() => stopScan());
  }

  void stopScan() {
    // logger.d("# stop BLE Scan");
    _flutterBlue.stopScan();
  }

  void _addInOasisList(BluetoothDevice ble) {
    for (Oasis oasis in oasisList) {
      if (oasis.device.id == ble.id) {
        return;
      }
    }

    oasisList.add(Oasis(ble, () {
      notifyListeners();
    }));
    notifyListeners();
  }

  void _addInMeterList(BluetoothDevice ble) {
    for (Meter meter in meterList) {
      if (meter.device.id == ble.id) {
        return;
      }
    }

    meterList.add(Meter(ble, () {
      notifyListeners();
    }));
    notifyListeners();
  }

  Future disconnectAllOasis() async {
    for (Oasis oasis in oasisList) {
      await oasis.disconnect();
      oasis.destroy();
    }
    oasisList.clear();
  }

  // 단지 BLE 메시지 수신에 따른 화면 재구성용
  void doNotAnything() {}
}

class _BleListWidget extends StatefulWidget {
  final bool showOasis;
  final bool showMeter;
  final bool showUnRegOasisOnly;

  _BleListWidget({
    this.showMeter = true,
    this.showOasis = true,
    this.showUnRegOasisOnly = false,
  });

  @override
  State<StatefulWidget> createState() => _BleListWidgetState();
}

class _BleListWidgetState extends State<_BleListWidget> {
  AppProvider _ap;
  BleProvider _bp;

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    _bp = Provider.of<BleProvider>(context);

    List<Widget> children = [];

    children.add(Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.only(left: 15, top: 10, bottom: 5),
            child: Text(
              (widget.showOasis) ? "장비 목록" : "측정기 목록",
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87),
            ),
          ),
          Divider(
            height: 2,
            color: Colors.blue[200],
            thickness: 2,
          ),
        ],
      ),
    ));
    if (widget.showOasis) {
      for (Oasis oasis in BleProvider.oasisList) {
        // 작업자가 MK 어드민일 경우
        if (_ap.worker.auth == Worker.Auth.MK_ADMIN_0) {
          // 등록되지 않은 장비 등록
          if (_ap.isRegOasis(oasis.device.id.id) == false) {
            children.add(oasisWidget(oasis));
          }
          // 등록된 장비 등록
          if (_ap.isRegOasis(oasis.device.id.id)) {
            children.add(oasisWidget(oasis));
          }
        }
        // 작업자가 일반 고객사의 작업자일 경우
        else {
          // 등록되지 않은 장비만 반환
          if (widget.showUnRegOasisOnly) {
            if (_ap.isRegOasis(oasis.device.id.id) == false) {
              children.add(unRegOasisWidget(oasis));
            }
          }
          // 등록된 장비만 반환
          else {
            if (_ap.isRegOasis(oasis.device.id.id)) {
              children.add(oasisWidget(oasis));
            }
          }
        }
      }
    }
    if (widget.showMeter) {
      for (Meter meter in BleProvider.meterList) {
        children.add(meterWidget(meter));
      }
    }
    return ListView(
      children: children,
    );
  }

  Widget oasisWidget(Oasis oasis) {
    Color tileColor;
    if (oasis.state == BluetoothDeviceState.disconnected) {
      tileColor = Colors.grey[200];
    } else if (oasis.state == BluetoothDeviceState.connected) {
      tileColor = Colors.lightBlue[100];
    }
    return Container(
      child: Column(
        children: [
          ListTile(
            leading: Icon(Icons.clean_hands_sharp),
            title: Text(
                _ap.getDeviceNickName(oasis.device.id.id) ?? oasis.device.name),
            subtitle: Text(oasis.device.id.id),
            trailing: Container(
              width: 100,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[400], width: 1),
                color: Colors.white,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Text(
                  EnumToString.convertToString(oasis.statusInfo.status) ??
                      "N/A"),
            ),
            tileColor: tileColor,
            onTap: () {
              ToolBox.pushPage(context, "소독기 제어", (OasisArea(oasis)));
            },
          ),
          Divider(
            height: 1,
            thickness: 1,
            color: Colors.grey[400],
          )
        ],
      ),
    );
  }

  Widget meterWidget(Meter meter) {
    IconData iconData;
    Color iconColor;
    Color tileColor;
    if (meter.state == BluetoothDeviceState.disconnected) {
      iconData = Icons.bluetooth_disabled;
      tileColor = Colors.grey[200];
    } else if (meter.state == BluetoothDeviceState.connected) {
      iconData = Icons.bluetooth_connected;
      iconColor = Colors.lightBlue;
      tileColor = Colors.lightBlue[100];
    }
    return Container(
      child: Column(
        children: [
          ListTile(
            leading: Icon(Icons.speed),
            title: Text(meter.device.name),
            subtitle: Text(meter.device.id.id),
            trailing: Container(
              width: 60,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey[400], width: 1),
                      color: meter.rxColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  Icon(iconData, color: iconColor),
                ],
              ),
            ),
            tileColor: tileColor,
            onTap: () {
              if (meter.state == BluetoothDeviceState.disconnected) {
                // logger.d("connect");
                meter.connect();
              } else if (meter.state == BluetoothDeviceState.connected) {
                // logger.d("disconnect");
                meter.disconnect();
              }
            },
          ),
          Divider(
            height: 1,
            thickness: 1,
            color: Colors.grey[400],
          )
        ],
      ),
    );
  }

  // 등록되지 않은 오아이스 위젯, 장비 등록시 사용
  Widget unRegOasisWidget(Oasis oasis) {
    return WidgetBox.infoWidget(
      marginVer: 3,
      marginHor: 5,
      paddingLeft: 10,
      paddingRight: 0,
      child: InkWell(
        onTap: () async {
          await ToolBox.pushPage(
              context, "장비 등록", DeviceRegistrationArea(oasis));
          _bp.startScan();
        },
        child: Row(
          children: [
            Container(
              width: 50,
              child: Icon(
                Icons.devices,
                color: Colors.black54,
                size: 30,
              ),
            ),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  WidgetBox.keyItem(oasis.device.name,
                      marginVer: 5, fontSize: 20),
                  WidgetBox.valueItem(oasis.device.id.id, marginVer: 2),
                ],
              ),
            ),
            IconButton(
              icon: Icon(Icons.app_registration),
              onPressed: null,
            )
          ],
        ),
      ),
    );
  }
}

class BLE {
  BluetoothDevice device;
  BluetoothDeviceState state;

  Function notifier;

  StreamSubscription<BluetoothDeviceState> _conListener;
  StreamSubscription<List<BluetoothService>> _serviceListener;
  StreamSubscription<List<int>> _valueListener;
  BluetoothCharacteristic _char;

  ProcessStatusInfo statusInfo = ProcessStatusInfo();
  ProcessSetting processSetting = OasisPayload.processSettingList[0];
  ProcessResultInfo processResult = ProcessResultInfo();

  String carID; // 차량 식별자
  String workerID; // 작업자 식별자
  String phoneNumber; // 알림톡을 전송할 번호
  String carNumber; // 차량 넘버
  String receivedMsg = "";

  Timer ackTimer;
  int _failCount = 0;
  Command lastCommand;
  bool isCommunicating = false; // 현재 통신중인지 여부, 인디케이터 출력용
  bool isEnd = false; // 공정 완료 후 모든 공정 데이터를 수신했는지 여부

  BLE(this.device, this.notifier) {
    _conListener = device.state.listen((event) {
      state = event;
      switch (event) {
        case BluetoothDeviceState.disconnected:
          _serviceListener?.cancel();
          _valueListener?.cancel();
          statusInfo.status = ProcessStatus.UNKNOWN;
          _char = null;
          break;

        case BluetoothDeviceState.connected:
          receivedMsg = "";
          _serviceListener = device.discoverServices().asStream().listen(
            (services) async {
              for (BluetoothService service in services) {
                bool isSelected = false;
                if (service.uuid.toString() == _oasisServiceID ||
                    service.uuid.toString() == _meterServiceID) {
                  List<BluetoothCharacteristic> chars = service.characteristics;
                  for (BluetoothCharacteristic char in chars) {
                    if (char.properties.notify) {
                      _valueListener = char.value
                          .listen((List<int> value) => _onData(value));
                      await char.setNotifyValue(true);
                    }
                    if (char.properties.write) {
                      _char = char;
                      isSelected = true;
                    }
                  }
                  if (isSelected) break;
                }
              }
              String message = OasisPayload.reqSettingsCmd();
              await Future.delayed(Duration(seconds: 1));
              this.write(message);
            },
          );
          break;
        case BluetoothDeviceState.connecting:
          break;
        case BluetoothDeviceState.disconnecting:
          break;
      }
      notifier();
    });
  }

  static Color rxColorDefault = Colors.grey;
  static Color rxColorEvent = Colors.blue;
  Color rxColor = rxColorDefault;

  void rxBlanker() {
    if (BleProvider.needBlink == false) return;
    rxColor = rxColorEvent;
    notifier();
    Future.delayed(Duration(milliseconds: 100), () {
      rxColor = rxColorDefault;
      notifier();
    });
  }

  Future connect() async {
    // logger.d("connect $state");
    if (state == BluetoothDeviceState.disconnected)
      await device.connect(
        autoConnect: true, // 연결된 상태에서 장비가 사라졌다 다시 나타난 경우 자동 접속 여부
      );
  }

  Future disconnect() async {
    // logger.d("disconnect: $state");
    if (state == BluetoothDeviceState.connected) await device.disconnect();
  }

  void destroy() {
    _conListener?.cancel();
    _valueListener?.cancel();
    _serviceListener?.cancel();
    _char = null;
  }

  void _startAckTimer() {
    ackTimer = Timer(Duration(seconds: 2), _ackTimeout);
    if (!ackTimer.isActive) {
      logger.d("_startAckTimer, ${ackTimer.isActive}");
    }
  }

  void _cancelAckTimer() {
    if (ackTimer == null) return;
    ackTimer.cancel();
    _failCount = 0;
    if (ackTimer.isActive) {
      logger.d("_cancelAckTimer, ${ackTimer.isActive}");
    }
  }

  void _ackTimeout() {
    if (!ackTimer.isActive) {
      return;
    }
    if (_failCount < 2) {
      // sendProCMD(Command.REQ_DATA);
      write(lastTxData);
      _failCount++;
    } else {
      if (kDebugMode) {
        ToolBox.showToast("공정 데이터 수신 실패: $_failCount ${statusInfo.nowPage}");
      }
    }
    logger.d("_ackTimeout, failCount: $_failCount, ${ackTimer.isActive}");
  }

  // 센싱 데이터가 측정된 경우 호출됨
  void _onData(List<int> value) {
    this.isCommunicating = false;
    notifier();
    _cancelAckTimer();

    int openCount = 0;
    int closeCount = 0;

    // logger.d(receivedMsg.length);
    receivedMsg = "$receivedMsg${String.fromCharCodes(value)}";
    // logger.d(receivedMsg);

    int flagIndex = 0;
    // 수신이 시작되기 전이면

    if (receivedMsg.startsWith("{")) {
      for (int i = 0; i < receivedMsg.length; i++) {
        if (receivedMsg[i] == "{") openCount++;
        if (receivedMsg[i] == "}") closeCount++;
        if (openCount == closeCount) {
          String msg = receivedMsg.substring(flagIndex, i + 1);
          flagIndex = i + 1;
          _onMessage(msg);
        }
      }
      receivedMsg = receivedMsg.substring(flagIndex);
      if (receivedMsg.isEmpty) {
        openCount = 0;
        closeCount = 0;
      }
    } else {
      receivedMsg = "";
    }
  }

  void _onMessage(String message) {
    logger.d(message);
  }

  String lastTxData;

  void write(String data) async {
    this.isCommunicating = true;
    notifier();
    lastTxData = data;
    if (_char == null) {
      logger.d("Null char");
      return;
    }
    logger.d("sendData=> $data");

    List<int> totalBuff = utf8.encode("$data\n");

    // totalBuff.add(utf8.encoder('\n'));
    int page = 0;
    int size = 50;
    List<int> buf = [];
    // logger.d("size: ${totalBuff.length}");
    while (true) {
      int start = page * size;
      int end = start + size;

      if (end < totalBuff.length) {
        buf = totalBuff.sublist(start, end);
        // logger.d("start: $start, end: $end, bufLeng: ${buf.length}");
        await _char.write(buf);
      } else {
        buf = totalBuff.sublist(start);
        // logger.d("start: $start, buf: ${buf.length}");
        await _char.write(buf);
        break;
      }
      page++;
    }
    _startAckTimer();
  }
}

class Meter extends BLE {
  Meter(BluetoothDevice device, Function notifier) : super(device, notifier);

  @override
  void _onMessage(String message) {
    rxBlanker();

    logger.d(message);

    try {
      var jsonObject = jsonDecode(message);
      for (int i = 0; i < BleProvider.meterDataList.length; i++) {
        if (_parseValue(jsonObject, "s${i + 1}") != null)
          BleProvider.meterDataList[i] = _parseValue(jsonObject, "s${i + 1}");
      }
    } catch (e) {
      logger.d(e);
    } finally {
      notifier();
    }
    // logger.d(BleProvider.meterDataList);
  }

  double _parseValue(dynamic jsonObject, String key) {
    if (jsonObject[key] != null &&
        jsonObject[key] >= 0 &&
        jsonObject[key] < 10) {
      return jsonObject[key] as double;
    }
    return null;
  }
}

class Oasis extends BLE {
  Oasis(BluetoothDevice device, Function notifier) : super(device, notifier);

  @override
  void _onMessage(String message) {
    try {
      logger.d(message);
      OasisPayload payload = OasisPayload.fromMap(jsonDecode(message));
      // logger.d(payload.toMap());
      lastCommand = payload.cmd;
      // logger.d(lastCommand.toString());

      switch (payload.cmd) {
        case Command.INIT:
          break;
        case Command.START:
          break;
        case Command.STOP:
          break;
        case Command.FORCE_STOP:
          break;
        case Command.FINISH:
          break;
        case Command.REQ_STATUS:
          statusInfo = payload.data;
          if (statusInfo.status == ProcessStatus.GEN ||
              statusInfo.status == ProcessStatus.STAY ||
              statusInfo.status == ProcessStatus.RELEASE) {
            _addChartData();
          }
          if (statusInfo.status == ProcessStatus.COMPLETE) {
            sendProCMD(Command.REQ_RESULT);
          }
          break;
        case Command.REQ_SETTINGS:
          processSetting = payload.data;
          if (kDebugMode) {
            ToolBox.showToast("FW VER. : ${processSetting.ver}");
          }
          workerID = payload.wid;
          phoneNumber = payload.phoneNum;
          carNumber = payload.carNum;
          break;
        case Command.REQ_RESULT:
          _clearChartData();
          processResult = payload.data;
          processSetting.ver = payload.fwVer;
          statusInfo.dataLength = processResult.length;
          statusInfo.totalPage = (processResult.length / 50).ceil();
          statusInfo.nowPage = 0;
          isEnd = false;
          sendProCMD(Command.REQ_DATA);
          break;
        case Command.REQ_DATA:
          ProcessDataInfo result = payload.data;
          if (statusInfo.nowPage == result.pageIndex) {
            _addChartData(data: result);
          } else {
            if (kDebugMode) {
              ToolBox.showToast("잘못된 공정 데이터가 수신되었습니다");
            }
          }
          statusInfo.nowPage++;
          if (statusInfo.nowPage < statusInfo.totalPage) {
            sendProCMD(Command.REQ_DATA);
          } else {
            isEnd = true;
          }

          break;
        case Command.REQ_OTA:
          if (kDebugMode) {
            ToolBox.showToast("OTA 응답 수신");
          }
          break;
      }
      if (payload.result != ResultCode.SUCCESS &&
          payload.result != ResultCode.NOT_SET) {
        if (payload.result == ResultCode.SENSOR_ERROR) {
          ToolBox.showToast("센서 초기화 중. 잠시 후에 다시 시도해주세요.");
        } else {
          if (kDebugMode) {
            ToolBox.showToast(
                "요청 실패: ${EnumToString.convertToString(payload.result)}");
          }
        }
      }
    } catch (e) {
      logger.e(e.toString());
    }
  }

  sendProCMD(Command command) {
    String message;
    switch (command) {
      case Command.INIT:
        break;
      case Command.START:
        _clearChartData();
        if (carNumber == null || carNumber.isEmpty) {
          return ToolBox.showToast("차량번호를 입력해주세요.");
        }
        message = OasisPayload.startProcessCmd(
          processSetting,
          carNumber,
          workerID,
          phoneNumber,
        );
        break;
      case Command.STOP:
        message = OasisPayload.stopProcessCmd();
        break;
      case Command.FORCE_STOP:
        message = OasisPayload.forceStopProcessCmd();
        break;
      case Command.FINISH:
        message = OasisPayload.finishProcessCmd();
        break;
      case Command.REQ_STATUS:
        message = OasisPayload.reqStatusCmd();
        break;
      case Command.REQ_SETTINGS:
        message = OasisPayload.reqSettingsCmd();
        break;
      case Command.REQ_RESULT:
        message = OasisPayload.reqResultCmd();
        break;
      case Command.REQ_DATA:
        message = OasisPayload.reqDataCmd(statusInfo.nowPage);
        // _startAckTimer();
        break;
      case Command.REQ_OTA:
        message = OasisPayload.reqOTACmd();
    }
    // logger.d(message);
    write(message);
  }

  List<FlSpot> chartData = [];

  int chartIndex = 0;

  _addChartData({ProcessDataInfo data}) {
    // 실시간 차트 데이터 수신
    if (data == null) {
      chartData.add(FlSpot((++chartIndex).toDouble(), statusInfo.ppm));
    }
    // 공정 종료 후 리스트 형태의 차트 데이터 수신 시
    else {
      for (var item in data.list) {
        chartData.add(FlSpot((++chartIndex).toDouble(), item.toDouble()));
      }
    }
  }

  _clearChartData() {
    chartData.clear();
    chartIndex = 0;
  }
}
