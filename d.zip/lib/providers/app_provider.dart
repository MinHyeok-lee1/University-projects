import 'dart:async';
import 'dart:convert';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:logger/logger.dart';
import 'package:oasis_app/main.dart';
import 'package:oasis_app/model/car.dart';
import 'package:oasis_app/model/company.dart';
import 'package:oasis_app/model/device.dart';
import 'package:oasis_app/model/history.dart';
import 'package:oasis_app/model/worker.dart';
import 'package:oasis_app/pages/sign/sign_in_area.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_blue/flutter_blue.dart' as BLE;
import 'package:permission_handler/permission_handler.dart';

Logger logger = Logger(
  printer: PrettyPrinter(methodCount: 3),
);

class AppProvider with ChangeNotifier {
  static AppProvider ins;
  String serverUrl; // 서버 기본 주소
  String publishUrl; // QR코드나 알림톡으로 전달할 공정 결과용 주소
  String mobileUrl; // 모바일 앱이 사용하는 주소

  AppProvider() {
    if (kDebugMode) {
      //serverUrl = "http://cleanoasis.net";
      serverUrl = "https://pcb.cleanoasis.net";
    } else {
      serverUrl = "http://cleanoasis.net";
    }

    publishUrl = "$serverUrl/publish?cat=1";
    mobileUrl = "$serverUrl/mobile";

    permissionHandler();
    _googleSignIn.onCurrentUserChanged.listen((GoogleSignInAccount account) {
      currentUser = account;
      notifyListeners();
    });
    _googleSignIn.signInSilently();

    _initBTStateListener();
    _initConnectivityListener();
    ins = this;
  }

  /// 퍼미션 관련
  Map<Permission, PermissionStatus> statuses =
      Map<Permission, PermissionStatus>();

  void permissionHandler() async {
    statuses = await [
      Permission.location,
      Permission.bluetooth,
      Permission.storage,
    ].request();
    notifyListeners();
  }

  bool allowedAllPermission() {
    if (statuses[Permission.location].isGranted &&
        statuses[Permission.storage].isGranted &&
        statuses[Permission.bluetooth].isGranted) {
      return true;
    } else {
      return false;
    }
  }

  /// Bluetooth State 관련

  BLE.BluetoothState btState = BLE.BluetoothState.unknown;

  void _initBTStateListener() {
    BLE.FlutterBlue.instance.state.listen((event) {
      // logger.d("New BLE State: $event");
      btState = event;
      notifyListeners();
    });
  }

  /// Internet Connectivity 관련

  ConnectivityResult conState = ConnectivityResult.none;

  void _initConnectivityListener() {
    Connectivity().onConnectivityChanged.listen((event) {
      logger.d("New Connectivity State: $event");
      conState = event;
      notifyListeners();
    });
  }

  ///화면 사이즈 관련

  double width;
  double height;

  void setScreenSize(double width, double height) {
    this.width = width;
    this.height = height;
  }

  /// 구글계정 로그인

  GoogleSignInAccount currentUser; // 현재 로그인된 구글 계쩡

  GoogleSignIn _googleSignIn = GoogleSignIn();

  Future<bool> signInGoogle() async {
    try {
      var result = await _googleSignIn.signIn();
      logger.d(result.toString());
      if (result != null) {
        currentUser = result;
        return true;
      } else {
        return false;
      }
    } catch (error) {
      logger.d(error.toString());
      return false;
    }
  }

  Future<void> signOutGoogle() async {
    try {
      await _googleSignIn.disconnect();
      currentUser = null;
      worker = null;
      company = null;
      notifyListeners();
    } catch (error) {}
  }

  /// 서버 통신 관련

  Worker worker; // 사용자 계정 정보
  Company company; // 사업자 정보
  List<Car> carList; // 사업체 소유의 차량들
  List<Device> deviceList; // 사업체 소유의 소독기들
  String token; // 통신용 토큰

  Future<ResPayload> _requestPost(
      BuildContext context, String path, Map data) async {
    data["token"] = token; // 토큰 주입

    // logger.d(data.toString());
    http.Response res = await http.post(
      Uri.parse(mobileUrl + path),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(data),
    );

    logger.d(res.body);

    ResPayload payload;
    try {
      payload = ResPayload.fromMap(jsonDecode(res.body));
      if (payload.result == false && payload.error == ResPayload.TOKEN_ERROR) {
        signOutApp(context, toastMessage: "로그아웃 되었습니다.");
      }
      // logger.d(payload.toMap());
    } catch (e) {
      logger.d(e);
    }

    return payload;
  }

  // 서버로 로그인
  Future<ResPayload> signInToServer(BuildContext context) async {
    Map data = {
      "type": "GOOGLE",
      "id": currentUser.id,
      "email": currentUser.email,
    };

    ResPayload res = await _requestPost(context, "/worker/signin", data);
    if (res.result) {
      token = res.token;
      worker = Worker.fromMap(jsonDecode(res.data));
      notifyListeners();
      return res;
    }
    return res;
  }

  // 서버로 회원 가입
  Future<ResPayload> signUpToServer(BuildContext context, Worker worker) async {
    ResPayload res =
        await _requestPost(context, "/worker/signup", worker.toMap());
    return res;
  }

  // 회원 탈퇴
  Future<ResPayload> withdrawalFromServer(BuildContext context) async {
    ResPayload res =
        await _requestPost(context, "/worker/withdrawal", worker.toMap());
    return res;
  }

  // 회원 정보 수정
  Future<ResPayload> updateWorkerInfo(BuildContext context,
      {Worker otherWorker}) async {
    Worker _worker = worker;
    if (otherWorker != null) {
      _worker = otherWorker;
    }
    ResPayload res =
        await _requestPost(context, "/worker/updateone", _worker.toMap());
    if (res.result == true && _worker == null) {
      signInToServer(context);
    }
    return res;
  }

  // 내 회사 정보 조회
  Future<ResPayload> findMyCompany(BuildContext context) async {
    Map data = {
      "_id": worker.comID,
    };
    ResPayload res = await _requestPost(context, "/company/find/id", data);
    if (res.result) {
      company = Company.fromMap(jsonDecode(res.data));
    }
    return res;
  }

  // 작업자 리스트 조회
  Future<List<Worker>> findWorkers(BuildContext context) async {
    Map data = {
      "CID": company.id,
    };

    logger.d("try");
    var res = await _requestPost(context, "/worker/find", data);
    logger.d("res: " + res.toString());
    return res.dataList.map((e) => Worker.fromMap(e)).toList();
  }

  /// 차량 관련

  // 차량 등록
  Future<ResPayload> registerCar(BuildContext context, Car car) async {
    ResPayload res = await _requestPost(context, "/car/register", car.toMap());
    if (res.result == true) {
      await findCars(context);
    }
    return res;
  }

  // 회사 소유 차량 조회
  Future<ResPayload> findCars(
    BuildContext context,
  ) async {
    Map data = {
      "CID": worker.comID,
    };
    ResPayload res = await _requestPost(context, "/car/find", data);

    carList = res.dataList.map((e) {
      return Car.fromMap(e);
    }).toList();
    notifyListeners();
    return res;
  }

  // 차량 정보 수정
  Future<ResPayload> updateCar(BuildContext context, Car car) async {
    ResPayload res = await _requestPost(context, "/car/update", car.toMap());
    if (res.result == true) {
      findCars(context);
    }
    return res;
  }

  // 차량 삭제
  // ignore: non_constant_identifier_names
  Future<ResPayload> deleteCar(
      BuildContext context, String id, String carNumber) async {
    Map data = {
      "_id": id,
      "CN": carNumber,
    };

    ResPayload res = await _requestPost(context, "/car/delete", data);
    if (res.result == true) {
      findCars(context);
    }
    return res;
  }

  // 입력값에 해당하는 사업자들 검색
  Future<ResPayload> findCompanies(
      BuildContext context, String companyName, String companyNumber) async {
    Map data = {
      "CNA": companyName,
      "CNU": companyNumber,
    };

    var res = await _requestPost(context, "/company/find", data);
    return res;
  }

  // 사업자 비밀번호 확인
  Future<bool> confirmCompanyPW(BuildContext context, String pw) async {
    Map data = {
      "CNU": worker.comID,
      "PW": pw,
    };

    var res = await _requestPost(context, "/company/confirm/pw", data);
    return res.result;
  }

  /// 히스토리 관련

  // 히스토리 추가
  Future<ResPayload> createHistory(
      BuildContext context, History history) async {
    Map data = history.toMap();

    ResPayload res = await _requestPost(context, "/history/create", data);
    return res;
  }

  // 히스토리 리스트 조회
  Future<List<History>> findHistories(
      BuildContext context, int selectedPage) async {
    Map data = {
      "CID": company.id,
      "SP": selectedPage,
      "NOP": 10,
    };

    var res = await _requestPost(context, "/history/find", data);
    return res.dataList.map((e) => History.fromMap(e)).toList();
  }

  Future<History> findHistory(BuildContext context, String id) async {
    Map data = {
      "_id": id,
    };

    var res = await _requestPost(context, "/history/findone", data);
    return History.fromMap(jsonDecode(res.data));
  }

  Future<void> shareHistory(
      BuildContext context, String id, String phoneNumber) async {
    Map data = {
      "_id": id,
      "num": phoneNumber,
    };
    await _requestPost(context, "/history/share", data);
  }

  /// 소독기 장비 관련

  // 장비 등록
  Future<ResPayload> registerDevice(BuildContext context, Device device) async {
    ResPayload res =
        await _requestPost(context, "/device/register", device.toMap());
    if (res.result == true) {
      await findDevices(context);
    }
    return res;
  }

  // 모든 장비 조회
  Future<List<Device>> findDevices(BuildContext context) async {
    Map data = {
      "CID": worker.comID,
    };

    var res = await _requestPost(context, "/device/find", data);

    deviceList = res.dataList.map((e) {
      return Device.fromMap(e);
    }).toList();
    notifyListeners();
    return deviceList;
  }

  Future<Device> findOneDevice(BuildContext context,
      {String id, String MAC}) async {
    Map data = {
      "_id": id,
      "MAC": MAC,
    };

    var res = await _requestPost(context, "/device/fine/one", data);
    if (res.result) {
      return Device.fromMap(jsonDecode(res.data));
    } else {
      return null;
    }
  }

  // 장비 닉네임 변경
  Future<ResPayload> updateDeviceNickName(
      BuildContext context, String id, String newNickName) async {
    Map data = {
      "_id": id,
      "NN": newNickName,
    };

    ResPayload res = await _requestPost(context, "/device/update", data);
    if (res.result == true) {
      findDevices(context);
    }
    return res;
  }

  // 장비 삭제

  Future<ResPayload> deleteDevice(
      BuildContext context,
      String id,
      // ignore: non_constant_identifier_names
      String MAC) async {
    Map data = {
      "_id": id,
      "MAC": MAC,
    };

    ResPayload res = await _requestPost(context, "/device/delete", data);
    if (res.result == true) {
      findDevices(context);
    }
    return res;
  }

  /// 기타 툴등

  String carNumberByID(String id) {
    for (Car car in carList) {
      if (car.id == id) {
        return car.carNumber;
      }
    }
    return null;
  }

  String carIDByCarNumber(String num) {
    for (Car car in carList) {
      if (car.carNumber == num) {
        return car.id;
      }
    }
    return null;
  }

  bool isRegOasis(String id) {
    for (Device device in deviceList) {
      if (device.MAC == id) {
        return true;
      }
    }
    return false;
  }

  // ignore: non_constant_identifier_names
  String getDeviceID(String MAC) {
    for (Device device in deviceList) {
      if (device.MAC == MAC) return device.id;
    }
    return null;
  }

  // ignore: non_constant_identifier_names
  String getDeviceNickName(String MAC) {
    for (Device device in deviceList) {
      if (device.MAC == MAC) return device.nickName;
    }
    return null;
  }

  // 앱으로 로그아웃 하고 로그인 화면으로 이동
  void signOutApp(BuildContext context, {String toastMessage}) async {
    if (toastMessage != null && toastMessage.isNotEmpty) {
      ToolBox.showToast(toastMessage);
    }
    await signOutGoogle();
    Navigator.popUntil(context, (route) => route.isFirst);
    ToolBox.replaceNewPage(
      context,
      SignInArea(
        delaySec: 1,
      ),
      duration: 1,
    );
  }
}

class ResPayload {
  static final String _fResult = "result";
  static final String _fData = "data";
  static final String _fDataList = "dataList";
  static final String _fError = "error";
  static final String _fToken = "token";

  static const String UNKNOWN = "UNKNOWN";
  static const String NO_SUCH_DATA = "NO_SUCH_DATA";
  static const String FAIL = "FAIL";
  static const String TOKEN_ERROR = "TOKEN_ERROR";

  bool result;
  String data;
  List dataList;
  String error;
  String token;

  ResPayload({this.result, this.data, this.error, this.token});

  ResPayload.fromMap(Map<String, dynamic> map) {
    result = map[_fResult] as bool;
    data = map[_fData] as String;
    error = map[_fError] as String;
    dataList = map[_fDataList];
    token = map[_fToken];
  }

  Map<String, dynamic> toMap() {
    return {
      _fResult: result,
      _fData: data,
      _fDataList: dataList,
      _fError: error,
      _fToken: token,
    };
  }
}
