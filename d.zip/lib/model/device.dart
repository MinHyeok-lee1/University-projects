import 'package:intl/intl.dart';
import 'package:oasis_app/providers/app_provider.dart';

class Device {
  static final String _fID = "_id";
  static final String _fComID = "CID";
  static final String _fModel = "MD";
  static final String _fMAC = "MAC";
  static final String _fVer = "VER";
  static final String _fNickName = "NN";
  static final String _fCreatedAt = "CA";
  static final String _fUpdatedAt = "UA";
  static final String _fUsageTime = "UT";

  String id;
  String comID;
  String model;
  // ignore: non_constant_identifier_names
  String MAC;
  String version;
  String nickName;
  DateTime createdAt;
  DateTime updatedAt;
  int usageTime;

  Device({
    this.id,
    this.comID,
    this.model,
    // ignore: non_constant_identifier_names
    this.MAC,
    this.version,
    this.nickName,
    this.createdAt,
    this.updatedAt,
    this.usageTime,
  });

  Device.fromMap(Map<String, dynamic> map) {
    try {
      id = map[_fID];
      comID = map[_fComID];
      model = map[_fModel];
      MAC = map[_fMAC];
      version = map[_fVer];
      nickName = map[_fNickName];
      createdAt = DateTime.parse(map[_fCreatedAt]);
      if (map[_fUpdatedAt] != null) {
        updatedAt = DateTime.parse(map[_fUpdatedAt]);
      }
      usageTime = map[_fUsageTime];
    } on Exception catch (e) {
      logger.d(e.toString());
    }
  }

  Map<String, dynamic> toMap({bool isForServer = false}) {
    return {
      _fID: id,
      _fComID: comID,
      _fModel: model,
      _fMAC: MAC,
      _fVer: version,
      _fNickName: nickName,
      _fCreatedAt: createdAt.toString(),
      _fUpdatedAt: updatedAt.toString(),
      _fUsageTime: usageTime,
    };
  }

  String strCreateTime() {
    if (createdAt == null) {
      return "N/A";
    }

    String strDateTime =
        DateFormat("yyyy-MM-dd HH:mm").format(createdAt.toLocal());
    return strDateTime;
  }

  String strUpdateTime() {
    if (updatedAt == null) {
      return "N/A";
    }

    String strDateTime =
        DateFormat("yyyy-MM-dd HH:mm").format(updatedAt.toLocal());
    return strDateTime;
  }
}
