import 'package:intl/intl.dart';


class WorkerAuth {
  /**
   * 작업자의 권한
   * 0: MK 관리자, 1: 사업주, 2: 작업자: 3
   * [중용] 권한 수정 시 Worker._strAuthList도 수정해야함
   */

  final int MK_ADMIN_0 = 0; // 본사 소속 관리자
  final int COM_WORKER_1 = 1; // 고객사 직원
  final int COM_MANAGER_2 = 2; // 고객사 관리자
  final int SELLER_3 = 3; // 대리점
}

class Worker {
  static final List<String> _strAuthList = [
    "플랫폼 관리자",
    "작업자",
    "관리자",
    "대리점",
  ];

  static final String _fID = "_id";
  static final String _fComID = "CID";
  static final String _fName = "WN";
  static final String _fPhoneNumber = "PN";
  static final String _fGoogleID = "GID";
  static final String _fEmail = "EM";
  static final String _fPhotoURL = "PU";
  static final String _fAuth = "AU";
  static final String _fActivated = "AC";
  static final String _fCreatedAt = "CA";
  static final String _fUpdatedAt = "UA";

  String id;
  String comID;
  String name;
  String phoneNumber;
  String googleID;
  String email;
  String photoURL;
  int auth; // Auth, 0: MK 관리자, 1: 사업주, 2: 작업자
  bool activated;
  DateTime createdAt;
  DateTime updatedAt;

  static WorkerAuth Auth = WorkerAuth();

  Worker({
    this.id,
    this.comID,
    this.name,
    this.phoneNumber,
    this.googleID,
    this.email,
    this.photoURL,
    this.auth,
    this.activated,
    this.createdAt,
    this.updatedAt,
  });

  Worker.fromMap(Map<String, dynamic> map) {
    id = map[_fID];
    comID = map[_fComID];
    name = map[_fName];
    phoneNumber = map[_fPhoneNumber];
    googleID = map[_fGoogleID];
    email = map[_fEmail];
    photoURL = map[_fPhotoURL];
    auth = map[_fAuth];
    activated = map[_fActivated];
    createdAt = DateTime.parse(map[_fCreatedAt]);
    updatedAt = DateTime.parse(map[_fUpdatedAt]);
  }

  Map<String, dynamic> toMap() {
    return {
      _fID: id,
      _fComID: comID,
      _fName: name,
      _fPhoneNumber: phoneNumber,
      _fGoogleID: googleID,
      _fEmail: email,
      _fPhotoURL: photoURL,
      _fAuth: auth,
      _fActivated: activated,
      _fCreatedAt: createdAt.toString(),
      _fUpdatedAt: updatedAt.toString(),
    };
  }

  String strCreateTime() {
    if (createdAt == null) {
      return "N/A";
    }

    String strDateTime =
        DateFormat("yyyy-MM-dd HH:mm").format(createdAt.toLocal());
    return strDateTime;
  }

  String strUpdateTime() {
    if (updatedAt == null) {
      return "N/A";
    }

    String strDateTime =
        DateFormat("yyyy-MM-dd HH:mm").format(updatedAt.toLocal());
    return strDateTime;
  }

  String getStrAuth() {
    return _strAuthList[auth];
  }
}
