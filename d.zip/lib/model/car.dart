import 'package:intl/intl.dart';

class Car {
  static const List<String> classList = [
    "경차",
    "소형",
    "중형",
    "대형",
    "SUV",
    "승합",
    "상용",
    "전기",
    "외제"
  ];

  static final String _fID = "_id";
  static final String _fComID = "CID";
  static final String _fCarClass = "CC";
  static final String _fCarNumber = "CN";
  static final String _fSerialNumber = "SN";
  static final String _fCreatedAt = "CA";
  static final String _fUpdatedAt = "UA";

  String id;
  String comID;
  int carClass;
  String carNumber;
  String serialNumber;
  DateTime createdAt;
  DateTime updatedAt;

  Car({
    this.id,
    this.comID,
    this.carClass,
    this.carNumber,
    this.serialNumber,
    this.createdAt,
    this.updatedAt,
  });

  String strCarClass() {
    if (carClass != null && carClass > 0 && carClass < classList.length + 1) {
      return classList[carClass - 1];
    } else {
      return "N/A";
    }
  }

  Car.fromMap(Map<String, dynamic> map) {
    id = map[_fID];
    comID = map[_fComID];
    carClass = map[_fCarClass];
    carNumber = map[_fCarNumber];
    serialNumber = map[_fSerialNumber];
    createdAt =
        (map[_fCreatedAt] == null) ? null : DateTime.parse(map[_fCreatedAt]);
    if (map[_fUpdatedAt] != null) {
      updatedAt = DateTime.parse(map[_fUpdatedAt]);
    }
  }

  Map<String, dynamic> toMap() {
    return {
      _fID: id,
      _fComID: comID,
      _fCarClass: carClass,
      _fCarNumber: carNumber,
      _fSerialNumber: serialNumber,
      _fCreatedAt: createdAt.toString(),
      _fUpdatedAt: updatedAt.toString(),
    };
  }

  String strCreateTime() {
    if (createdAt == null) {
      return "N/A";
    }

    String strDateTime =
        DateFormat("yyyy-MM-dd HH:mm").format(createdAt.toLocal());
    return strDateTime;
  }

  String strUpdateTime() {
    if (updatedAt == null) {
      return "N/A";
    }

    String strDateTime =
        DateFormat("yyyy-MM-dd HH:mm").format(updatedAt.toLocal());
    return strDateTime;
  }
}
