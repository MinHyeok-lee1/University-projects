class Company {
  static final String _fID = "_id";
  static final String _fName = "NA";
  static final String _fComName = "CNA";
  static final String _fComNumber = "CNU";
  static final String _fPhoneNumber = "PN";
  static final String _fMobileNumber = "MN";

  String id;
  String name;
  String comName;
  String comNumber;
  String phoneNumber;
  String mobileNumber;

  Company({this.id, this.name, this.comNumber, this.comName, this.phoneNumber});

  Company.fromMap(Map<String, dynamic> map) {
    id = map[_fID];
    name = map[_fName];
    comName = map[_fComName];
    comNumber = map[_fComNumber];
    phoneNumber = map[_fPhoneNumber];
    mobileNumber = map[_fMobileNumber];
  }

  Map<String, dynamic> toMap() {
    return {
      _fID: id,
      _fName: name,
      _fComName: comName,
      _fComNumber: comNumber,
      _fPhoneNumber: phoneNumber,
      _fMobileNumber: mobileNumber,
    };
  }
}
