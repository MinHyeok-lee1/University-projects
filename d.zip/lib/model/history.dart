import 'package:intl/intl.dart';
import 'package:oasis_app/bt_protocol/BtProtocol.dart';

class History {
  static final String _fID = "_id";
  static final String _fWorkerID = "WID";
  static final String _fDeviceID = "DID";
  static final String _fCompanyID = "CID";
  static final String _fCarID = "VID";

  static final String _fWorkName = "WNM";
  static final String _fCarNumber = "CNM";
  static final String _fDeviceName = "DNM";
  static final String _fDeviceNickName = "DNN";
  static final String _fFwVersion = "VER";

  static final String _fEndTime = "ET";
  static final String _fProcessData = "PD";
  static final String _fMaximumPPM = "MP";
  static final String _fFinishPPM = "FP";
  static final String _fResultCode = "RC";
  static final String _fResultDetail = "RD";
  static final String _fCourse = "COS";

  String id;
  String workerID;
  String deviceID;
  String companyID;
  String carID;
  String workerName;
  String carNumber;
  String deviceName;
  String deviceNickName;
  String fwVersion;
  DateTime endTime;
  List<double> processData;
  double maximumPPM;
  double finishPPM;
  int resultCode;
  List<int> resultDetail = [0, 0, 0];
  int course;

  History({
    this.id,
    this.workerID,
    this.deviceID,
    this.companyID,
    this.carID,
    this.workerName,
    this.carNumber,
    this.deviceName,
    this.deviceNickName,
    this.fwVersion,
    this.endTime,
    this.processData,
    this.maximumPPM,
    this.finishPPM,
    this.resultCode,
    this.course,
  });

  History.fromMap(Map<String, dynamic> map) {
    // logger.d(map[_fProcessData]);
    id = map[_fID];
    workerID = map[_fWorkerID];
    deviceID = map[_fDeviceID];
    companyID = map[_fCompanyID];
    carID = map[_fCarID];

    workerName = map[_fWorkName];
    carNumber = map[_fCarNumber];
    deviceName = map[_fDeviceName];
    deviceNickName = map[_fDeviceNickName];
    fwVersion = map[_fFwVersion];

    endTime = DateTime.parse(map[_fEndTime]);
    processData = (map[_fProcessData] as List)
        ?.map((item) => double.parse(item))
        ?.toList();
    maximumPPM = map[_fMaximumPPM] is int
        ? (map[_fMaximumPPM] as int).toDouble()
        : map[_fMaximumPPM];
    finishPPM = map[_fFinishPPM] is int
        ? (map[_fFinishPPM] as int).toDouble()
        : map[_fFinishPPM];
    resultCode = map[_fResultCode];
    resultDetail = List<int>.from(map[_fResultDetail]);
    course = map[_fCourse] as int;
  }

  Map<String, dynamic> toMap() {
    return {
      _fID: id,
      _fWorkerID: workerID,
      _fDeviceID: deviceID,
      _fCompanyID: companyID,
      _fCarID: carID,
      _fWorkName: workerName,
      _fCarNumber: carNumber,
      _fDeviceName: deviceName,
      _fDeviceNickName: deviceNickName,
      _fFwVersion: fwVersion,
      _fEndTime: endTime.toString(),
      _fProcessData: processData,
      _fMaximumPPM: maximumPPM,
      _fFinishPPM: finishPPM,
      _fResultCode: resultCode,
      _fResultDetail: resultDetail,
      _fCourse: course,
    };
  }

  // ignore: non_constant_identifier_names
  List<int> setResultDetail({int GR, int SR, int RR}) {
    if (GR != null) {
      resultDetail[0] = GR;
    }

    if (SR != null) {
      resultDetail[1] = SR;
    }

    if (RR != null) {
      resultDetail[2] = RR;
    }

    return resultDetail;
  }

  String strEndTime() {
    if (endTime == null) {
      return "N/A";
    }

    String strDateTime =
        DateFormat("yyyy-MM-dd HH:mm").format(endTime.toLocal());
    return strDateTime;
  }

  String strReqTime() {
    if (processData == null || processData.length == 0) {
      return "N/A";
    }

    Duration duration = Duration(seconds: (processData.length));
    int hour = duration.inHours.remainder(60);
    int min = duration.inMinutes.remainder(60);
    int sec = duration.inSeconds.remainder(60);

    String strDuration = "";
    if (hour > 0) {
      strDuration = "$hour시간 ";
    }
    if (min > 0) {
      strDuration = "$strDuration$min분 ";
    }
    if (sec > 0) {
      strDuration = "$strDuration$sec초";
    }
    // return "$min 분 $sec";
    return strDuration;
  }

  String strResult() {
    if (resultCode == null) {
      return "N/A";
    } else if (resultCode == 1) {
      return "성공";
    } else {
      return "실패";
    }
  }

  String strGenResult() {
    if (resultDetail == null || resultDetail.length != 3) {
      return "N/A";
    } else if (resultDetail[0] == 1) {
      return "성공";
    } else if (resultDetail[0] == -1) {
      return "생략";
    } else {
      return "실패";
    }
  }

  String strStayResult() {
    if (resultDetail == null || resultDetail.length != 3) {
      return "N/A";
    } else if (resultDetail[1] == 1) {
      return "성공";
    } else if (resultDetail[1] == -1) {
      return "생략";
    } else {
      return "실패";
    }
  }

  String strReleaseResult() {
    if (resultDetail == null || resultDetail.length != 3) {
      return "N/A";
    } else if (resultDetail[2] == 1) {
      return "성공";
    } else if (resultDetail[2] == -1) {
      return "생략";
    } else {
      return "실패";
    }
  }

  String strCourseName() {
    if (course == null) {
      return "N/A";
    } else {
      // return OasisPayload.processSettingList[course].gradeName ?? "N/A";
      for(ProcessSetting setting in OasisPayload.processSettingList){
        if(setting.course == course){
          return setting.gradeName;
        }
      }
      return "N/A";
    }
  }
}
