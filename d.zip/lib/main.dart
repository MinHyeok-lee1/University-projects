import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:oasis_app/bt_protocol/BtProtocol.dart';
import 'package:oasis_app/pages/common_page/common_page.dart';
import 'package:oasis_app/pages/menu_area.dart';
import 'package:oasis_app/pages/sign/sign_in_area.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/providers/ble_provider.dart';
import 'package:oasis_app/sec/managers/app_manager.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';
import 'package:screen/screen.dart';
import 'providers/app_provider.dart';

const bool useScreenUtil = true;
const bool useNewVersion = true;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kDebugMode) {
    OasisPayload.processSettingList.clear();
    OasisPayload.processSettingList.add(
      ProcessSetting(
        gradeName: "소독(15분)",
        GV: 2.0,
        GTO: 60 * 5,
        SV: 2.0,
        STO: 60 * 5,
        RV: 0.3,
        RTO: 60 * 5,
        course: 0,
      ),
    );
    OasisPayload.processSettingList.add(
      ProcessSetting(
        gradeName: "탈취(30분)",
        GV: 3.0,
        GTO: 60 * 5,
        SV: 2.5,
        STO: 60 * 20,
        RV: 0.3,
        RTO: 60 * 5,
        course: 1,
      ),
    );
  }

  if (!useNewVersion) {
    WidgetsFlutterBinding.ensureInitialized();
    // 화면 세로보기 고정
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    // 화면 켜짐 유지
    Screen.keepOn(true);

    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: WidgetBox.colorStatusBar,
      systemNavigationBarColor: WidgetBox.colorNavigationBar,
    ));
    runApp(App());
  } else {
    AppManager.startApp();
  }
}

class App extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => AppState();
}

class AppState extends State<App> {
  @override
  void initState() {
    super.initState();
    BleProvider.removePairedOasis();
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
        ChangeNotifierProvider(create: (_) => BleProvider()),
      ],
      child: ScreenUtilInit(
        designSize: Size(1000, 1000),
        // designSize: ScreenUtil.defaultSize,
        builder: () => MaterialApp(
          builder: (context, widget) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
              child: widget,
            );
          },
          theme: ThemeData(
            elevatedButtonTheme: ElevatedButtonThemeData(
                style: ElevatedButton.styleFrom(
                    primary: Colors.cyan,
                    minimumSize: Size(150.w, 100.w),
                    textStyle: TextStyle(fontSize: 40.w))),
            outlinedButtonTheme: OutlinedButtonThemeData(
                style: ElevatedButton.styleFrom(
                    // primary: Colors.cyan,
                    minimumSize: Size(150.w, 100.w),
                    textStyle: TextStyle(fontSize: 40.w))),
          ),
          initialRoute: "/",
          routes: {
            "/": (context) => CommonPage(SignInArea()),
            "/main": (context) => CommonPage(MenuArea()),
          },
        ),
      ),
    );
  }
}
