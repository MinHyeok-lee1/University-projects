import 'package:flutter/material.dart';
import 'package:oasis_app/model/car.dart';
import 'package:oasis_app/pages/common_page/select_info_page.dart';
import 'package:oasis_app/pages/common_page/edit_info_page.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class CarManagementArea extends StatefulWidget {
  final Car car;

  CarManagementArea(this.car);

  @override
  _CarManagementAreaState createState() => _CarManagementAreaState(this.car);
}

class _CarManagementAreaState extends State<CarManagementArea> {
  Car _car;

  AppProvider _ap;

  _CarManagementAreaState(this._car);

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return Column(
      children: [
        Expanded(
          child: ListView(
            children: [
              WidgetBox.itemTitle("차량 정보"),
              WidgetBox.tileItem(
                "차량 등급",
                _car.strCarClass() ?? "N/A",
                onPressed: _editCarClass,
                iconData: Icons.edit,
              ),
              WidgetBox.tileItem(
                "차량 번호(번호판)",
                _car.carNumber ?? "N/A",
                onPressed: _editCarNumber,
                iconData: Icons.edit,
              ),
              WidgetBox.tileItem(
                "차대 번호",
                _car.serialNumber ?? "N/A",
                onPressed: _editSerialNumber,
                iconData: Icons.edit,
              ),
              WidgetBox.tileItem("등록일", _car.strCreateTime()),
              WidgetBox.tileItem("수정일", _car.strUpdateTime()),
              WidgetBox.itemTitle("차량 설정"),
              WidgetBox.tileItem(
                "차량 삭제",
                "이 장비를 서버에서 삭제합니다.",
                onPressed: _deleteCar,
                iconData: Icons.delete,
              ),
            ],
          ),
        ),
        WidgetBox.btWideFull("수정", onTap: _editCarInfo)
      ],
    );
  }

  void _editCarClass() async {
    int result = await ToolBox.pushPage(
        context,
        "차량 등급 수정",
        SelectInfoPage(
          "차량 등급",
          _car.carClass - 1,
          Car.classList,
        ));
    if (result != null) {
      logger.d(result);
      setState(() {
        _car.carClass = (result + 1);
      });
    }
  }

  void _editCarNumber() async {
    var result = await ToolBox.pushPage(
        context,
        "차량 번호(번호판) 수정",
        EditInfoPage(
          "차량 번호",
          _car.carNumber ?? "N/A",
        ));
    if (result != null) {
      setState(() {
        _car.carNumber = result;
      });
    }
  }

  void _editSerialNumber() async {
    var result = await ToolBox.pushPage(
        context,
        "차대 번호 수정",
        EditInfoPage(
          "차대 번호",
          _car.serialNumber ?? "N/A",
        ));
    if (result != null) {
      setState(() {
        _car.serialNumber = result;
      });
    }
  }

  void _deleteCar() async {
    bool result = await WidgetBox.showTrueFalseDialog(
      context,
      "차량삭제",
      "정말로 차량을 삭제하시겠습니까?",
    );
    if (!result) {
      return;
    }

    ResPayload payload = await _ap.deleteCar(context, _car.id, _car.carNumber);
    if (payload.error != ResPayload.TOKEN_ERROR) {
      Navigator.pop(context);
    }
  }

  void _editCarInfo() async {
    ResPayload payload = await _ap.updateCar(context, _car);

    if (payload.error != ResPayload.TOKEN_ERROR) {
      Navigator.pop(context);
    }
  }
}
