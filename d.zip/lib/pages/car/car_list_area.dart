import 'package:flutter/material.dart';
import 'package:oasis_app/model/car.dart';
import 'package:oasis_app/pages/car/car_management_area.dart';
import 'package:oasis_app/pages/car/car_registration_area.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class CarListArea extends StatefulWidget {
  @override
  _CarListAreaState createState() => _CarListAreaState();
}

class _CarListAreaState extends State<CarListArea> {
  AppProvider _ap;

  List<bool> ccSelection = [
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true
  ];

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return Scaffold(
      body: Column(
        children: [
          // _carClassWidget(),
          Expanded(
            child: ListView.builder(
              itemCount: _ap.carList.length,
              itemBuilder: (context, index) {
                Car car = _ap.carList[index];
                return _carWidget(car);
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewCar,
        child: Icon(Icons.add),
      ),
    );
  }

  bool ccSelectAll = true;

  Widget _carClassWidget() {
    List<Widget> children = [];
    children.add(InkWell(
      onTap: () {
        setState(() {
          ccSelectAll = !ccSelectAll;
          for (int i = 0; i < Car.classList.length; i++) {
            if (ccSelectAll) {
              ccSelection[i] = true;
            } else {
              ccSelection[i] = false;
            }
          }
        });
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        decoration: BoxDecoration(
            border: Border.all(color: Colors.black54),
            borderRadius: BorderRadius.circular(10),
            color: (ccSelectAll) ? Colors.lightBlue : null),
        child: Text(
          "ALL",
          style: TextStyle(
            fontSize: 15,
            color: (ccSelectAll) ? Colors.white : null,
          ),
        ),
      ),
    ));
    for (int i = 0; i < Car.classList.length; i++) {
      children.add(InkWell(
        onTap: () {
          setState(() {
            ccSelection[i] = !ccSelection[i];
          });
        },
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          decoration: BoxDecoration(
              border: Border.all(color: Colors.black54),
              borderRadius: BorderRadius.circular(10),
              color: (ccSelection[i]) ? Colors.lightBlue : null),
          child: Text(
            Car.classList[i],
            style: TextStyle(
              fontSize: 15,
              color: (ccSelection[i]) ? Colors.white : null,
            ),
          ),
        ),
      ));
    }

    return WidgetBox.infoWidget(
      marginVer: 3,
      marginHor: 5,
      paddingLeft: 10,
      paddingRight: 10,
      child: Align(
        alignment: Alignment.topLeft,
        child: Wrap(
          children: children,
        ),
      ),
    );
  }

  Widget _carWidget(Car car) {
    return WidgetBox.infoWidget(
        marginVer: 3,
        marginHor: 5,
        paddingLeft: 10,
        paddingRight: 0,
        child: InkWell(
          onTap: () async {
            ToolBox.pushPage(context, "차량 정보 수정", CarManagementArea(car));
          },
          child: Row(
            children: [
              Container(
                width: 50,
                child: Icon(
                  Icons.car_rental,
                  color: Colors.black54,
                  size: 30,
                ),
              ),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    WidgetBox.keyItem(car.carNumber,
                        marginVer: 5, fontSize: 20),
                    WidgetBox.valueItem(car.strCarClass(), marginVer: 2),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(Icons.arrow_forward_ios_rounded),
                onPressed: null,
              )
            ],
          ),
        ));
  }

  // 새로운 차량을 추가하는 페이지 호출
  void _addNewCar() {
    ToolBox.pushPage(context, "차량 등록", CarRegistrationArea());
  }
}
