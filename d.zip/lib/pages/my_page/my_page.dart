import 'package:flutter/material.dart';
import 'package:oasis_app/pages/common_page/edit_info_page.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class MyPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => MyPageState();
}

class MyPageState extends State<MyPage> {
  AppProvider _ap;

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);

    return ListView(
      children: [
        WidgetBox.itemTitle("개인 정보"),
        WidgetBox.tileItem(
          "이름",
          _ap.worker?.name ?? "N/A",
          onPressed: _editName,
          iconData: Icons.edit,
        ),
        WidgetBox.tileItem("이메일", _ap.worker?.email ?? "N/A"),
        WidgetBox.tileItem(
          "휴대폰번호",
          _ap.worker?.phoneNumber ?? "N/A",
          onPressed: _editPhoneNumber,
          iconData: Icons.edit,
        ),
        WidgetBox.tileItem("권한", _ap.worker?.getStrAuth() ?? "N/A"),
        WidgetBox.tileItem("가입일", _ap.worker?.strCreateTime() ?? "N/A"),
        WidgetBox.tileItem("갱신일", _ap.worker?.strUpdateTime() ?? "N/A"),
        WidgetBox.itemTitle("사업체 정보"),
        WidgetBox.tileItem("상호명", _ap.company?.comName ?? "N/A"),
        WidgetBox.tileItem("사업자번호", _ap.company?.comNumber.toString() ?? "N/A"),
        WidgetBox.itemTitle("서비스 설정"),
        WidgetBox.tileItem(
          "로그아웃",
          "현재 계정에서 로그아웃합니다.",
          onPressed: _signOut,
          iconData: Icons.logout,
        ),
        WidgetBox.tileItem("회원탈퇴", "서비스에서 회원 탈퇴합니다.",
            onPressed: _withdrawal, iconData: Icons.delete),
      ],
    );
  }

  // 이름 변경 처리
  void _editName() async {
    String result = await ToolBox.pushPage(
        context, "이름 수정", EditInfoPage("이름", _ap.worker.name));
    if (result != null && result.isNotEmpty && _ap.worker.name != result) {
      _ap.worker.name = result;
      _ap.updateWorkerInfo(context,);
    }
  }

  // 전화번호 변경 처리
  void _editPhoneNumber() async {
    String result = await ToolBox.pushPage(
        context, "휴대폰번호", EditInfoPage("휴대폰번호 수정", _ap.worker.phoneNumber,isNumberOnly: true,));
    if (result != null &&
        result.isNotEmpty &&
        _ap.worker.phoneNumber != result) {
      _ap.worker.phoneNumber = result;
      _ap.updateWorkerInfo(context,);
    }
  }

  // 로그아웃 처리
  void _signOut() async {
    bool result = await WidgetBox.showTrueFalseDialog(
        context, "로그아웃", "현재 계정에서 로그아웃 하시겠습니까?");
    if (!result) {
      return;
    }
    _ap.signOutApp(context);
  }

  // 회원 탈퇴 처리
  void _withdrawal() async {
    bool result = await WidgetBox.showTrueFalseDialog(
      context,
      "회원탈퇴",
      "정말로 회원탈퇴 하시겠습니까?",
    );
    if (!result) {
      return;
    }

    await _ap.withdrawalFromServer(context,);

    _ap.signOutApp(context);
  }
}
