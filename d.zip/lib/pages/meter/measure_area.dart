import 'dart:async';
import 'dart:io';

import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/providers/ble_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:path_provider/path_provider.dart';
import 'package:charts_flutter/flutter.dart' as charts;

class MeasureArea extends StatefulWidget {
  @override
  _MeasureAreaState createState() => _MeasureAreaState();
}

class _MeasureAreaState extends State<MeasureArea> {
  bool __isTracing = false;

  List<double> newValueList = [0,0,0,0,0,0]; // 최신 오존값을 가지는 리스트
  Timer updateTimer; // 주기적으로 최신 값을 update하여 monitor에 반영되도록함
  int index = 0;

  List<Color> colorList = [
    Colors.black,
    Colors.red,
    Colors.yellow,
    Colors.blue,
    Colors.grey,
    Colors.green,
  ];

  @override
  void initState() {
    super.initState();
    BleProvider.needBlink = false;
    BleProvider.meterDataList = [null, null, null, null, null, null];
    WidgetsBinding.instance.addPostFrameCallback((_) {
      updateTimer = Timer.periodic(Duration(seconds: 1), (timer) {
        updateValueList();
      });
    });
  }

  @override
  void dispose() {
    updateTimer.cancel();
    BleProvider.needBlink = true;
    logger.d(BleProvider.needBlink);
    super.dispose();
  }

  void updateValueList() {
    logger.d(BleProvider.meterDataList.length);
    logger.d(newValueList.length);
    for (int i = 0; i < BleProvider.meterDataList.length; i++) {
      newValueList[i] = BleProvider.meterDataList[i];
      if (__isTracing) {
        stackedValueList[i].data.add(PpmItem(index, newValueList[i]));
      }
    }
    BleProvider.meterDataList = [null, null, null, null, null, null];
    index++;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          // chartArea(),
          ValueChart(this.stackedValueList),
          monitor(),
          controller(),
        ],
      ),
    );
  }

  Widget monitor() {
    int monitorIndex = 0;
    return Container(
      alignment: Alignment.centerLeft,
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.grey[400],
        ),
      ),
      child: Wrap(
        children: newValueList.map(
          (double value) {
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 5),
              width: 60,
              child: Column(
                children: [
                  Text(
                    "#${monitorIndex++}",
                    style: TextStyle(color: colorList[monitorIndex - 1]),
                  ),
                  Divider(
                    color: Colors.grey[400],
                    thickness: 1,
                  ),
                  Text(value.toString()),
                ],
              ),
            );
          },
        ).toList(),
      ),
    );
  }

  Widget controller() {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          WidgetBox.btBasic(
            title: (__isTracing) ? "종료" : "시작",
            onTap: (__isTracing) ? endTrace : startTrace,
          ),
          WidgetBox.btBasic(title: "저장", onTap: saveTraceResult),
        ],
      ),
    );
  }

  List<charts.Series<PpmItem, int>> stackedValueList =
      [];

  chartArea() {
    return Expanded(
      child: Container(
        child: charts.NumericComboChart(stackedValueList,
            animate: false,
            defaultRenderer: new charts.LineRendererConfig(),
            // Custom renderer configuration for the point series.
            customSeriesRenderers: [
              new charts.PointRendererConfig(
                  // ID used to link series to this renderer.
                  customRendererId: 'customPoint')
            ]),
      ),
    );
  }

  void setIsTracing(bool value) {
    setState(() {
      __isTracing = value;
    });
  }

  void startTrace() {
    // stackedValueList.clear();
    //
    // for (int i = 0; i < newValueList.length; i++) {
    //   stackedValueList.add(charts.Series<PpmItem, int>(
    //     id: "#$i",
    //     domainFn: (PpmItem item, _) => item.index,
    //     measureFn: (PpmItem item, _) => item.ppm,
    //     data: List<PpmItem>(),
    //   ));
    // }

    stackedValueList = [
      charts.Series<PpmItem, int>(
        id: "S1",
        domainFn: (PpmItem item, _) => item.index,
        measureFn: (PpmItem item, _) => item.ppm,
        data: [],
        colorFn: (_, __) => charts.MaterialPalette.black,
      ),
      charts.Series<PpmItem, int>(
        id: "S2",
        domainFn: (PpmItem item, _) => item.index,
        measureFn: (PpmItem item, _) => item.ppm,
        data: [],
        colorFn: (_, __) => charts.MaterialPalette.red.shadeDefault,
      ),
      charts.Series<PpmItem, int>(
        id: "S3",
        domainFn: (PpmItem item, _) => item.index,
        measureFn: (PpmItem item, _) => item.ppm,
        data: [],
        colorFn: (_, __) => charts.MaterialPalette.yellow.shadeDefault,
      ),
      charts.Series<PpmItem, int>(
        id: "S4",
        domainFn: (PpmItem item, _) => item.index,
        measureFn: (PpmItem item, _) => item.ppm,
        data: [],
        colorFn: (_, __) => charts.MaterialPalette.blue.shadeDefault,
      ),
      charts.Series<PpmItem, int>(
        id: "S5",
        domainFn: (PpmItem item, _) => item.index,
        measureFn: (PpmItem item, _) => item.ppm,
        data: [],
        colorFn: (_, __) => charts.MaterialPalette.gray.shadeDefault,
      ),
      charts.Series<PpmItem, int>(
        id: "S6",
        domainFn: (PpmItem item, _) => item.index,
        measureFn: (PpmItem item, _) => item.ppm,
        data: [],
        colorFn: (_, __) => charts.MaterialPalette.green.shadeDefault,
      )
    ];
    index = 0;
    logger.d(stackedValueList.length);
    setIsTracing(true);
  }

  void endTrace() {
    setIsTracing(false);
  }

  void saveTraceResult() async {
    List<List<dynamic>> rows = [];
    List<dynamic> row = [];

    for (int i = 0; i <= stackedValueList.length; i++) {
      if (i == 0) {
        row.add("index");
      } else {
        row.add("S$i");
      }
    }
    rows.add(row);

    for (int i = 0; i < stackedValueList[0].data.length; i++) {
      List<dynamic> row = [];
      row.add(stackedValueList[0].data[i].index);
      for (var ppmEle in stackedValueList) {
        row.add(ppmEle.data[i].ppm);
      }
      rows.add(row);
    }

    String dir = (await getExternalStorageDirectory()).absolute.path;
    String file = "$dir";

//        File f = File(file + "/사용이력(${DateTime.now()}).csv");
    File f = File(file + "/${DateTime.now().toString()}.csv");

    String csv = ListToCsvConverter().convert(rows);

    f.writeAsString(csv);

    logger.d("save");

    if (f != null) {
      ToolBox.showToast("저장되었습니다.");
    }
  }
}

// ignore: must_be_immutable
class ValueChart extends StatelessWidget {
  List<charts.Series<PpmItem, int>> stackedValueList;

  ValueChart(this.stackedValueList);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        child: charts.NumericComboChart(stackedValueList,
            animate: false,
            defaultRenderer: new charts.LineRendererConfig(),
            // Custom renderer configuration for the point series.
            customSeriesRenderers: [
              new charts.PointRendererConfig(
                  // ID used to link series to this renderer.
                  customRendererId: 'customPoint')
            ]),
      ),
    );
  }
}

class PpmItem {
  final int index;
  final double ppm;

  PpmItem(this.index, this.ppm);

  @override
  String toString() {
    return "$index / $ppm";
  }
}
