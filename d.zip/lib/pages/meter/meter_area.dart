import 'package:flutter/material.dart';
import 'package:oasis_app/pages/meter/measure_area.dart';
import 'package:oasis_app/providers/ble_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class MeterArea extends StatefulWidget {
  @override
  _MeterAreaState createState() => _MeterAreaState();
}

class _MeterAreaState extends State<MeterArea> {
  BleProvider _bp;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _bp.startScan());
  }

  @override
  Widget build(BuildContext context) {
    _bp = Provider.of<BleProvider>(context);

    return Container(
      child: Column(
        children: [
          Expanded(child: BleProvider.meterWidgetList),
          WidgetBox.btWideFull(
            "측정 시작",
            onTap: _startMeasure,
          ),
        ],
      ),
    );
  }

  // 측정 시작
  void _startMeasure() async {
    await ToolBox.pushPage(context, "오존 측정", MeasureArea());
  }
}
