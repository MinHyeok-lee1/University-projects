import 'dart:async';
import 'package:enum_to_string/enum_to_string.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'package:oasis_app/bt_protocol/BtProtocol.dart';
import 'package:oasis_app/model/car.dart';
import 'package:oasis_app/model/device.dart';
import 'package:oasis_app/model/history.dart';
import 'package:oasis_app/model/worker.dart';
import 'package:oasis_app/pages/oasis/car_selection_area.dart';
import 'package:oasis_app/pages/oasis/ota_page.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/providers/ble_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

// ignore: must_be_immutable
class OasisArea extends StatefulWidget {
  Oasis oasis;

  OasisArea(this.oasis);

  @override
  _OasisAreaState createState() => _OasisAreaState();
}

class _OasisAreaState extends State<OasisArea> with WidgetsBindingObserver {
  AppProvider _ap;
  BleProvider _bp; // 화면 재구성용으로 필요

  Timer conTimer;

  TextEditingController phoneCon = TextEditingController();
  TextEditingController carNumCon = TextEditingController();

  int _selectedCourse = -1;

  @override
  void initState() {
    // logger.d(":: initState on OasisArea");
    super.initState();

    if (widget.oasis.state == BluetoothDeviceState.disconnected) {
      widget.oasis.device.connect();
    }
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.oasis.workerID = _ap.worker.id;
    });
  }

  @override
  void dispose() {
    _bp.doNotAnything();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    logger.d(state.toString());

    if (state == AppLifecycleState.paused) {
      conTimer = Timer(Duration(seconds: 5), _handleConTimer);
    } else if (state == AppLifecycleState.resumed) {
      if (conTimer != null && conTimer.isActive) conTimer.cancel();
      if (widget.oasis.state == BluetoothDeviceState.disconnected) {
        widget.oasis.device.connect();
      }
    }
  }

  void _handleConTimer() {
    logger.d("fired");
    widget.oasis.device.disconnect();
  }

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    _bp = Provider.of<BleProvider>(context);

    return Stack(
      alignment: Alignment.center,
      children: [
        Column(
          children: [
            _oasisInfoArea(),
            _statusInfoWidget(),
            _controlArea(),
          ],
        ),
        (widget.oasis.statusInfo.status == ProcessStatus.UNKNOWN)
            ? WidgetBox.loadingWidget(title: "연결 중")
            : (widget.oasis.isCommunicating)
                ? WidgetBox.loadingWidget(title: "통신 중")
                : Container(),
      ],
    );
  }

  Widget _oasisInfoArea() {
    return WidgetBox.areaContainer(
      Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Expanded(
            child: Container(
              alignment: Alignment.centerLeft,
              // margin: const EdgeInsets.only(left: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _ap.getDeviceNickName(widget.oasis.device.id.id) ??
                        widget.oasis.device.name,
                    style: _areaTitle,
                  ),
                  Padding(padding: EdgeInsets.only(bottom: 10.w)),
                  Text(widget.oasis.device.id.id),
                ],
              ),
            ),
          ),
          WidgetBox.elButton(
              title: "재접속",
              onPressed: () async {
                await widget.oasis.disconnect();
                await Future.delayed(Duration(seconds: 1));
                await widget.oasis.connect();
              },
              isEnabled: (widget.oasis.state == BluetoothDeviceState.connected)
                  ? true
                  : false),
          (kDebugMode && widget.oasis.statusInfo.status == ProcessStatus.IDLE)
              ? WidgetBox.elButton(
                  // height: 40,
                  title: "OTA",
                  onPressed: () async {
                    Navigator.push(
                      context,
                      PageTransition(
                        type: PageTransitionType.rightToLeft,
                        child: OTAPage(
                          widget.oasis,
                        ),
                      ),
                    );
                  },
                  isEnabled:
                      (widget.oasis.state == BluetoothDeviceState.connected)
                          ? true
                          : false)
              : Container(),
        ],
      ),
    );
  }

  Widget _controlArea() {
    Widget centerButton() {
      GestureTapCallback onTap;
      IconData iconData;

      if (widget.oasis.statusInfo.status == ProcessStatus.UNKNOWN) {
      } else if (widget.oasis.statusInfo.status == ProcessStatus.IDLE) {
        iconData = Icons.play_arrow_rounded;
        onTap = () {
          widget.oasis.workerID = _ap.worker.id;
          widget.oasis.phoneNumber = phoneCon.text;
          widget.oasis.carNumber = carNumCon.text;
          if (_selectedCourse == -1) {
            widget.oasis.processSetting = OasisPayload.processSettingList[0];
          }
          widget.oasis.sendProCMD(Command.START);
        };
      } else if (widget.oasis.statusInfo.status == ProcessStatus.GEN ||
          widget.oasis.statusInfo.status == ProcessStatus.STAY) {
        iconData = Icons.stop;

        onTap = () async {
          bool result = await WidgetBox.showTrueFalseDialog(
              context, "공정 종료", "소독을 종료하시겠습니까? 소독을 종료하셔도 회수 과정은 진행됩니다.");
          if (result) {
            widget.oasis.sendProCMD(Command.STOP);
          }
        };
      } else if (widget.oasis.statusInfo.status == ProcessStatus.RELEASE) {
        iconData = Icons.stop;

        onTap = () async {
          bool result = await WidgetBox.showTrueFalseDialog(
              context,
              "강제 종료",
              "현재 소독과정을 마무리하고 있습니다. "
                  "소독을 강제 종료하면 유해한 물질에 노출될 수 있습니다. "
                  "그럼에도 강제종료하시겠습니까?");
          if (result) {
            widget.oasis.sendProCMD(Command.FORCE_STOP);
          }
        };
      } else if (widget.oasis.statusInfo.status == ProcessStatus.COMPLETE &&
          widget.oasis.isEnd) {
        iconData = Icons.stop_circle_outlined;
        onTap = () {
          uploadHistory();
          widget.oasis.sendProCMD(Command.FINISH);
        };
      }

      return Container(
        alignment: Alignment.center,
        child: (iconData == null)
            ? Container()
            : InkWell(
                onTap: onTap,
                child: Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(
                      color: Colors.grey,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: Icon(
                    iconData,
                    size: 40,
                    color: (onTap != null) ? Colors.blueGrey : Colors.grey,
                  ),
                ),
              ),
      );
    }

    return (widget.oasis.statusInfo.status == ProcessStatus.UNKNOWN)
        ? Container()
        : Container(
            color: Colors.grey[100],
            child: Column(
              children: [
                Divider(
                  color: Colors.grey,
                  height: 1,
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  child: centerButton(),
                ),
              ],
            ),
          );
  }

  Widget _statusInfoWidget() {
    IconData iconData;
    Widget childWidget = Container();

    switch (widget.oasis.statusInfo.status) {
      case ProcessStatus.UNKNOWN:
        iconData = Icons.bluetooth_searching;
        break;
      case ProcessStatus.IDLE:
        iconData = Icons.car_repair;
        childWidget = Column(
          children: [
            _carIdSelector(),
            _courseSelector(),
            _phoneNumberWidget(),
          ],
        );
        break;
      case ProcessStatus.READY:
        iconData = Icons.settings;
        break;
      case ProcessStatus.GEN:
        iconData = Icons.input;
        childWidget = _rtProcessInfoWidget();
        break;
      case ProcessStatus.STAY:
        iconData = Icons.blur_circular;
        childWidget = _rtProcessInfoWidget();
        break;
      case ProcessStatus.RELEASE:
        iconData = Icons.logout;
        childWidget = _rtProcessInfoWidget();
        break;
      case ProcessStatus.COMPLETE:
        iconData = Icons.flag;
        childWidget = _processResultWidget();
        break;
      default:
        iconData = Icons.settings;
    }

    return Expanded(
      child: Container(
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              alignment: Alignment.center,
              height: 100,
              child: Icon(
                iconData,
                size: 100,
                color: Colors.lightBlue,
              ),
            ),
            // 현재 상태 문자
            Container(
              child: Text(
                EnumToString.convertToString(widget.oasis.statusInfo.status) ??
                    "N/A",
                style: WidgetBox.tsTileKey,
              ),
            ),
            childWidget,
          ],
        ),
      ),
    );
  }

  Widget _carIdSelector() {
    return WidgetBox.infoWidget(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("차량번호", style: WidgetBox.tsTileKey),
          Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 15),
              padding: const EdgeInsets.symmetric(vertical: 5),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                controller: carNumCon,
                style: WidgetBox.tsTileKey,
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: "차량번호",
                  hintStyle: WidgetBox.tsTileValue,
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.all(0),
                ),
                onChanged: (value) {
                  setState(() {
                    widget.oasis.carID = null;
                  });
                },
              ),
            ),
          ),
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () async {
              Car car = await ToolBox.pushPage(
                  context, "차량 검색", CarSelectionArea(widget.oasis.carID));
              setState(
                () {
                  if (car != null) {
                    widget.oasis.carID = car?.id;
                    carNumCon.text = car?.carNumber;
                  } else {
                    logger.d("널");
                    widget.oasis.carID = null;
                    carNumCon.text = "";
                  }
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _courseSelector() {
    return WidgetBox.infoWidget(
      child: Row(
        children: [
          WidgetBox.keyItem("코스선택"),
          Expanded(
            child: Container(

              child: Wrap(
                // mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: OasisPayload.processSettingList.map((item) {
                  bool isSelected =
                      (widget.oasis.processSetting.course == item.course)
                          ? true
                          : false;
                  return WidgetBox.olButton(
                    title: item.gradeName,
                    onPressed: () {
                      setState(() {
                        _selectedCourse = item.course;
                        widget.oasis.processSetting = item;
                      });
                    },
                    isSelected: isSelected,
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 전화번호 입력부
  Widget _phoneNumberWidget() {
    return WidgetBox.infoWidget(
        child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text("연락처", style: WidgetBox.tsTileKey),
        Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 15),
            padding: const EdgeInsets.symmetric(vertical: 5),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.grey[200],
              borderRadius: BorderRadius.circular(10),
            ),
            child: TextField(
              controller: phoneCon,
              keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
              ],
              style: WidgetBox.tsTileKey,
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                hintText: "전화번호 (선택사항)",
                hintStyle: WidgetBox.tsTileValue,
                border: InputBorder.none,
                contentPadding: EdgeInsets.all(0),
              ),
            ),
          ),
        ),
      ],
    ));
  }

  // 실시간 공정 수행 정보
  Widget _rtProcessInfoWidget() {
    return Column(
      children: [
        WidgetBox.infoWidget(
            child: Column(
          children: [
            WidgetBox.tileItemVertical(
                "코스", widget.oasis.processSetting.strCourseName()),
            WidgetBox.tileItemVertical("차량번호", widget.oasis.carNumber ?? "N/A"),
            WidgetBox.tileItemVertical(
                "오존농도", widget.oasis.statusInfo.ppm.toString() + "ppm"),
            WidgetBox.tileItemVertical("카운트",
                "${widget.oasis.statusInfo.count} / ${widget.oasis.processSetting.getTotalTime()}"),
            WidgetBox.tileItemVertical(
                "남은시간",
                widget.oasis.statusInfo
                    .leftCount(widget.oasis.processSetting.course)
                    .toString()),
            WidgetBox.tileItemVertical("진행률",
                "${widget.oasis.statusInfo.intProgress(widget.oasis.processSetting.course).toStringAsFixed(1)}%"),
          ],
        )),
        _chartWidget(),
      ],
    );
  }

  // 공정 결과 정보
  Widget _processResultWidget() {
    return Container(
      child: Column(
        children: [
          WidgetBox.infoWidget(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    WidgetBox.keyItem("소독"),
                    WidgetBox.keyItem("유지"),
                    WidgetBox.keyItem("회수")
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    WidgetBox.valueItem(ProcessResultInfo.strGenResult(
                        widget.oasis.processResult)),
                    WidgetBox.valueItem("성공"),
                    WidgetBox.valueItem(ProcessResultInfo.strReleaseResult(
                        widget.oasis.processResult)),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    WidgetBox.keyItem("차량번호"),
                    WidgetBox.keyItem("전화번호")
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    WidgetBox.valueItem(widget.oasis.carNumber ?? "N/A"),
                    WidgetBox.valueItem(widget.oasis.phoneNumber ?? "N/A"),
                  ],
                ),
                (kDebugMode)
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          WidgetBox.keyItem("전체 데이터"),
                          WidgetBox.keyItem("데이터 수신률")
                        ],
                      )
                    : Container(),
                (kDebugMode)
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          WidgetBox.valueItem(
                              widget.oasis.statusInfo.dataLength.toString()),
                          WidgetBox.valueItem((widget
                                      .oasis.statusInfo?.nowPage ==
                                  null)
                              ? "0%"
                              : "${(widget.oasis.statusInfo.nowPage / widget.oasis.statusInfo.totalPage * 100).toInt()}%"),
                        ],
                      )
                    : Container(),
              ].map((e) {
                return Container(
                  padding: EdgeInsets.symmetric(vertical: 15.w),
                  child: e,
                );
              }).toList(),
            ),
          ),
          (widget.oasis.chartData.length > 0) ? _chartWidget() : Container(),
        ],
      ),
    );
  }

  Widget _chartWidget() {
    return Container(
      height: 200,
      child: LineChart(
        LineChartData(
          lineTouchData: LineTouchData(
            touchTooltipData: LineTouchTooltipData(
              tooltipBgColor: Colors.blueGrey.withOpacity(0.8),
            ),
            touchCallback: (LineTouchResponse touchResponse) {},
            handleBuiltInTouches: true,
          ),
          gridData: FlGridData(
            show: true,
          ),
          titlesData: FlTitlesData(
            bottomTitles: SideTitles(
              showTitles: true,
              reservedSize: 22,
              getTextStyles: (value) => const TextStyle(
                color: Color(0xff72719b),
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
              margin: 0,
              getTitles: (value) {
                if ((value % 60).toInt() == 0) {
                  return "${(value ~/ 60).toInt()}m";
                } else {
                  return "";
                }
              },
            ),
            leftTitles: SideTitles(
              showTitles: true,
              getTextStyles: (value) => const TextStyle(
                color: Color(0xff75729e),
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
              getTitles: (value) {
                switch (value.toInt()) {
                  case 1:
                    return '1ppm';
                  case 2:
                    return '2ppm';
                  case 3:
                    return '3ppm';
                  case 4:
                    return "4ppm";
                  case 5:
                    return "5ppm";
                }
                return '';
              },
              margin: 8,
              reservedSize: 30,
            ),
          ),
          borderData: FlBorderData(
            show: true,
            border: const Border(
              bottom: BorderSide(
                color: Color(0xff4e4965),
                width: 4,
              ),
              left: BorderSide(
                color: Colors.transparent,
              ),
              right: BorderSide(
                color: Colors.transparent,
              ),
              top: BorderSide(
                color: Colors.transparent,
              ),
            ),
          ),
          // minX: 0,
          // maxX: 14,
          // maxY: 7,
          // minY: 0,
          lineBarsData: [
            LineChartBarData(
              // spots: [
              //   FlSpot(1, 1),
              //   FlSpot(3, 1.5),
              //   FlSpot(5, 1.4),
              //   FlSpot(7, 3.4),
              //   FlSpot(10, 2),
              //   FlSpot(12, 2.2),
              //   FlSpot(13, 1.8),
              // ],
              spots: widget.oasis.chartData ?? [FlSpot(1, 1)],
              isCurved: true,
              colors: [
                Colors.blue,
              ],
              barWidth: 2,
              isStrokeCapRound: true,
              dotData: FlDotData(
                show: false,
              ),
              belowBarData: BarAreaData(
                show: false,
              ),
            )
          ],
        ),
      ),
    );
  }

  uploadHistory() async {
    double maximumPPM, finishPPM;
    List<double> pDataList = [];
    if (widget.oasis.chartData != null && widget.oasis.chartData.length > 0) {
      maximumPPM = 0.0;
      for (FlSpot spot in widget.oasis.chartData) {
        pDataList.add(spot.y);
        if (maximumPPM < spot.y) {
          maximumPPM = spot.y;
        }
      }
      finishPPM = pDataList.last ?? null;
    }

    if (widget.oasis.carID == null && widget.oasis.carNumber != null) {
      widget.oasis.carID = _ap.carIDByCarNumber(widget.oasis.carNumber);
    }

    History history = History(
      workerID: _ap.worker.id,
      companyID: _ap.company.id,
      carID: widget.oasis.carID,
      deviceID: _ap.getDeviceID(widget.oasis.device.id.id),
      workerName: _ap.worker.name,
      carNumber: widget.oasis.carNumber,
      deviceName: widget.oasis.device.name,
      deviceNickName: _ap.getDeviceNickName(widget.oasis.device.id.id),
      fwVersion: widget.oasis.processSetting.ver,
      maximumPPM: maximumPPM,
      finishPPM: finishPPM,
      endTime: DateTime.now().toUtc(),
      resultCode: ProcessResultInfo.resultCode(widget.oasis.processResult),
      processData: pDataList,
      course: widget.oasis.processSetting.course,
    );

    // 관리자가 등록되지 않은 장비를 동작시킨 경우
    if (_ap.isRegOasis(widget.oasis.device.id.id) == false &&
        _ap.worker.auth == Worker.Auth.MK_ADMIN_0) {
      Device device =
          await _ap.findOneDevice(context, MAC: widget.oasis.device.id.id);
      if (device != null) {
        history.companyID = device.comID;
        history.deviceID = device.id;
      }
    }

    history.setResultDetail(
      GR: widget.oasis.processResult.genResult,
      SR: widget.oasis.processResult.stayResult,
      RR: widget.oasis.processResult.releaseResult,
    );

    logger.d(history.toMap());

    ResPayload result = await _ap.createHistory(context, history);

    logger.d(result.toMap());
    if (kDebugMode && result.result) {
      ToolBox.showToast("공정 등록 완료");
    }
    if (!result.result) {
      ToolBox.showToast("공정 등록 실패");
    }

    if (phoneCon.text != null &&
        phoneCon.text.isNotEmpty &&
        phoneCon.text.length == 11) {
      _ap.shareHistory(context, result.data, phoneCon.text);
    }
    phoneCon.clear();
  }

  /// 새로운 UI


  TextStyle _areaTitle = TextStyle(fontSize: 45.w, fontWeight: FontWeight.bold);
}
