import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue/flutter_blue.dart' as BLE;
import 'package:flutter_wifi_connect/flutter_wifi_connect.dart';
import 'package:oasis_app/bt_protocol/BtProtocol.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/providers/ble_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';
import 'package:app_settings/app_settings.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class OTAPage extends StatefulWidget {
  Oasis _oasis;

  OTAPage(this._oasis);

  @override
  State<StatefulWidget> createState() => _OTAPageState(_oasis);
}

class _OTAPageState extends State<OTAPage> {
  Oasis _oasis;

  AppProvider _ap;
  BleProvider _bp;

  String _ssid;
  bool isConnectedToOasis = false;
  String _otaFilePath;
  PlatformFile _file;

  _OTAPageState(this._oasis);

  @override
  void initState() {
    super.initState();
  }

  List<Widget> widgetList = [];

  @override
  Widget build(BuildContext context) {
    // logger.d("hi"+_oasis.lastCommand.toString());
    _ap = Provider.of<AppProvider>(context);
    _bp = Provider.of<BleProvider>(context);

    genWidget();

    return Scaffold(
      appBar: AppBar(
        title: Text("OTA"),
      ),
      body: ListView(
        children: [
          Column(
            children: widgetList,
          ),
          _connectivityWidget(),
          _wifiInfoWidget(),
          _devInfoWidget(),
          _filePickerButton(),
          _reqOTAButton(),
          _reqConnectButton(),
          _reqPerformOTAtButton(),
          _otaLogWidget(),
        ],
      ),
    );
  }

  void genWidget() {
    widgetList.clear();
    widgetList.add(testHeaderWidget());
    widgetList.add(bleTestWidget());
    widgetList.add(wifieTestWidget());
  }

  Widget testHeaderWidget() {
    Widget widget = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          alignment: Alignment.center,
          width: 200.w,
          child: Text("항목"),
        ),
        Text("시도"),
        Container(
          alignment: Alignment.center,
          width: 200.w,
          child: Text("상태"),
        ),
      ],
    );
    return WidgetBox.areaContainer(widget);
  }

  Widget testItemWidget(String title, void Function() testFun, bool result) {
    Widget widget = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          alignment: Alignment.center,
          width: 200.w,
          child: Text(title),
        ),
        WidgetBox.olButton(title: "시도", onPressed: testFun),
        Container(
          alignment: Alignment.center,
          width: 200.w,
          child: Text((result == null)
              ? "N/A"
              : (result)
                  ? "성공"
                  : "실패"),
        ),
      ],
    );
    return WidgetBox.areaContainer(widget);
  }

  bool bleTestResult;

  Widget bleTestWidget() {
    return testItemWidget("Bluetooth", bleTest, bleTestResult);
  }

  void bleTest() async {
    bleTestResult = await BLE.FlutterBlue.instance.isAvailable;
    setState(() {});
  }

  bool wifiTestResult;

  Widget wifieTestWidget() {
    return testItemWidget("WiFi", wifiTest, wifiTestResult);
  }

  void wifiTest() async {
    try {
      ConnectivityResult result = await Connectivity().checkConnectivity();
      logger.d("1");
      if (result == ConnectivityResult.wifi) {
        logger.d("2");
        wifiTestResult = true;
      } else if (result == ConnectivityResult.mobile) {
        wifiTestResult = await FlutterWifiConnect.isEnabled;
        if (wifiTestResult == false) {
          await FlutterWifiConnect.activateWifi();
          ConnectivityResult result = await Connectivity().checkConnectivity();
          wifiTestResult = await FlutterWifiConnect.isEnabled;
        }
      } else if (result == ConnectivityResult.none) {
        logger.d("3");
        await FlutterWifiConnect.activateWifi();
        logger.d("4");
        ConnectivityResult result = await Connectivity().checkConnectivity();
        logger.d("5");
        wifiTestResult = await FlutterWifiConnect.isEnabled;
      }
    } on MissingPluginException catch (e) {
      logger.d(e);
    } catch (e) {
      logger.d(e);
    }
    setState(() {});
  }

  Widget _connectivityWidget() {
    Widget item(String title, bool status, void Function() onPressed) {
      return Container(
        height: 50.w,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title),
            Text(status.toString()),
            (!status)
                ? WidgetBox.elButton(title: "활성화", onPressed: onPressed)
                : Container()
          ],
        ),
      );
    }

    return WidgetBox.areaContainer(
      Column(
        children: [
          item("WIFI", _isEnabledWiFi, AppSettings.openWIFISettings),
          item("BLE", _isEnabledBT, AppSettings.openBluetoothSettings),
        ],
      ),
    );
  }

  Widget _wifiInfoWidget() {
    return Container(
      child: Column(
        children: [
          Text("SSID: $_ssid"),
          Text("isConnected: $isConnectedToOasis"),
        ],
      ),
    );
  }

  Widget _devInfoWidget() {
    return Container(
      child: Column(
        children: [
          Text(_oasis.device.name),
          Text(_oasis.device.id.id),
          Text(_oasis.lastCommand.toString())
        ],
      ),
    );
  }

  Widget _filePickerButton() {
    return ElevatedButton(onPressed: _pickFwForOTA, child: Text("File Pick"));
  }

  Widget _reqOTAButton() {
    return ElevatedButton(
        onPressed: () {
          _oasis.sendProCMD(Command.REQ_OTA);
        },
        child: Text("REQ_OTA"));
  }

  Widget _reqConnectButton() {
    return ElevatedButton(
      onPressed: _connectToOasis,
      child: Text("Connect To Oasis"),
    );
  }

  Widget _reqPerformOTAtButton() {
    return ElevatedButton(onPressed: _performOTA, child: Text("send File"));
  }

  bool _isEnabledBT = false;
  bool _isEnabledWiFi = false;

  void _checkNetwork() async {
    _isEnabledBT = (_ap.btState == BLE.BluetoothState.off) ? false : true;
    _isEnabledWiFi = (_ap.conState != ConnectivityResult.none) ? true : false;
    if (_isEnabledWiFi == false) {
      _isEnabledWiFi = await FlutterWifiConnect.isEnabled;
    }
    await FlutterWifiConnect.activateWifi();
    setState(() {});

    await FlutterWifiConnect.ssid.then((String ssid) {
      setState(() {
        _ssid = ssid;
      });
    });
  }

  void _connectToOasis() async {
    await FlutterWifiConnect.connectToSecureNetwork(
            _oasis.device.name, "here4you")
        .then((bool result) {
      setState(() {
        isConnectedToOasis = result;
      });
    });
  }

  void _pickFwForOTA() async {
    FilePickerResult result = await FilePicker.platform.pickFiles();
    if (result != null) {
      _file = result.files.first;
      _otaFilePath = _file.path;
    }
  }

  bool isSending = false;
  int _sent = 0;
  int _total = 0;

  Widget _otaLogWidget() {
    return (isSending)
        ? Container(
            child: Column(
              children: [
                Text("전송상황: $_sent/$_total"),
                Text("전송완료 후에도 펌웨어 업데이트에 시간이 걸림"),
                Text("본 창이 사라질 때 까지 기다리세요."),
              ],
            ),
          )
        : Text("전송 시작 전입니다.");
  }

  void _performOTA() async {
    setState(() {
      isSending = true;
    });
    try {
      DateTime sTime, eTime, tTime;
      sTime = DateTime.now();

      String url = "http://192.168.4.1/update";
      var dio = Dio();
      var formData = FormData.fromMap({
        'image':
            await MultipartFile.fromFile(_otaFilePath, filename: _file.name),
      });
      var response = await dio.post(
        url,
        data: formData,
        onSendProgress: (int sent, int total) {
          _sent = sent;
          _total = total;
          print('Sent: $sent $total (${sent / total * 100})');
        },
        onReceiveProgress: (int sent, int total) {
          print('Received: $sent $total (${sent / total * 100})');
        },
      );

      eTime = DateTime.now();
      logger.d(
          "Result: ${response.statusCode} / ${eTime.millisecondsSinceEpoch - sTime.millisecondsSinceEpoch}");
    } catch (e, s) {
      logger.d("문제는 ${e.toString()}");
      logger.d("문제는 ${s.toString()}");
    }

    await FlutterWifiConnect.disconnect();
    setState(() {
      isSending = false;
    });
    ToolBox.showToast("OTA 완료");
  }

  /// Logics

  void _checkConnectivity() {}
}
