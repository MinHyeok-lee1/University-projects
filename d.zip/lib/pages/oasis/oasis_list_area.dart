import 'package:flutter/material.dart';
import 'package:oasis_app/providers/ble_provider.dart';
import 'package:provider/provider.dart';

class OasisListArea extends StatefulWidget {
  @override
  _OasisListAreaState createState() => _OasisListAreaState();
}

class _OasisListAreaState extends State<OasisListArea> {
  BleProvider _bp;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _bp.startScan());
  }

  @override
  void dispose() {
    _bp.disconnectAllOasis();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _bp = Provider.of<BleProvider>(context);

    return Container(
      child: Column(
        children: [
          Expanded(child: BleProvider.oasisWidgetList),
        ],
      ),
    );
  }
}
