import 'package:flutter/material.dart';
import 'package:oasis_app/model/car.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class CarSelectionArea extends StatefulWidget {
  final String carID;

  CarSelectionArea(this.carID);

  @override
  _CarSelectionAreaState createState() => _CarSelectionAreaState();
}

class _CarSelectionAreaState extends State<CarSelectionArea> {
  AppProvider _ap;

  TextEditingController _teCon = TextEditingController();

  @override
  void initState() {
    super.initState();
    // logger.d(widget.carID);
    _teCon.addListener(() {
      setState(() {});
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _teCon.text = _ap.carNumberByID(widget.carID);
    });
  }

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return Column(
      children: [
        WidgetBox.editItem("차량번호", _teCon,
            verPadding: 15, textInputType: TextInputType.number),
        Expanded(
          child: ListView.builder(
            itemCount: _ap.carList.length,
            itemBuilder: (BuildContext context, int index) {
              Car car = _ap.carList[index];
              if (car.carNumber.contains(_teCon.text)) {
                return InkWell(
                  onTap: () {
                    Navigator.pop(context, car);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Card(
                      child: Container(
                        margin: const EdgeInsets.symmetric(
                            vertical: 20, horizontal: 20),
                        child: Text(
                          car.carNumber,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                );
              }
              return Container();
            },
          ),
        ),
      ],
    );
  }
}
