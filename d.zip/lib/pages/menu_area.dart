import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:oasis_app/model/worker.dart';
import 'package:oasis_app/pages/car/car_list_area.dart';
import 'package:oasis_app/pages/device_management/registred_device_list_area.dart';
import 'package:oasis_app/pages/common_page/edit_info_page.dart';
import 'package:oasis_app/pages/history/history_list_area.dart';
import 'package:oasis_app/pages/meter/meter_area.dart';
import 'package:oasis_app/pages/my_page/my_page.dart';
import 'package:oasis_app/pages/oasis/oasis_list_area.dart';
import 'package:oasis_app/pages/worker_management/worker_list_area.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class MenuArea extends StatefulWidget {
  @override
  _MenuAreaState createState() => _MenuAreaState();
}

class _MenuAreaState extends State<MenuArea> {
  AppProvider _ap;
  BuildContext _context;

  double _width, _height;

  @override
  Widget build(BuildContext context) {
    _context = context;
    _width = MediaQuery.of(context).size.width;
    _height = MediaQuery.of(context).size.height;
    _ap = Provider.of<AppProvider>(context);
    _ap.setScreenSize(_width, _height);
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            menuIcon("차량소독", Icons.add, OasisListArea()),
            menuIcon("소독이력", Icons.history, HistoryListArea()),
            menuIcon("마이페이지", Icons.account_box_outlined, MyPage(),
                isRequiredActivation: false),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            menuIcon(
              "장비관리",
              Icons.devices,
              RegisteredDeviceListArea(),
              isRequiredManagerAuth: true,
            ),
            menuIcon(
              "차량관리",
              Icons.car_rental,
              CarListArea(),
              isRequiredManagerAuth: true,
            ),
            menuIcon(
              "작업자관리",
              Icons.people_outline_sharp,
              WorkerListArea(),
              isVisible: (_ap.worker != null &&
                      (_ap.worker.auth == Worker.Auth.MK_ADMIN_0 ||
                          _ap.worker.auth == Worker.Auth.COM_MANAGER_2))
                  ? true
                  : false,
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            menuIcon(
              "오존측정",
              Icons.flag,
              MeterArea(),
              // 오존 측정 메뉴는 MK 관리자에게만 보여짐
              isVisible: (_ap.worker != null &&
                      _ap.worker.auth == Worker.Auth.MK_ADMIN_0)
                  ? true
                  : false,
            ),
            menuIcon("더미", Icons.history, HistoryListArea(), isVisible: false),
            menuIcon("더미", Icons.history, HistoryListArea(), isVisible: false),
          ],
        ),
      ].map((e) {
        return Container(
          margin: const EdgeInsets.only(
            top: 20,
          ),
          child: e,
        );
      }).toList(),
    );
  }

  Widget menuIcon(
    String text,
    IconData iconData,
    Widget newPage, {
    bool isRequiredActivation = true,
    bool isRequiredManagerAuth = false,
    bool isVisible = true,
  }) {
    GestureTapCallback onTap = () async {
      // 관리자 승인 여부 처리
      if (isRequiredActivation && _ap.worker.activated == false) {
        return ToolBox.showToast("아직 승인 완료되지 않은 사용자입니다. 해당 사업자에게 요청하시기 바랍니다.");
      }

      // 관리자 권한 필요 여부 처리
      if (isRequiredManagerAuth) {
        if (_ap.worker.auth == Worker.Auth.COM_WORKER_1) {
          bool result = await WidgetBox.showTrueFalseDialog(_context,
              "권한 변경 필요", "장비관리를 위해서는 사업자 권한이 필요합니다. 사업자 권한으로 변경하시겠습니까?");
          if (result) {
            String pw = await ToolBox.pushPage(
              _context,
              "권한 수정",
              EditInfoPage(
                "사업자계정 비밀번호",
                "",
              ),
            );

            if (pw != null && pw.isNotEmpty) {
              result = await _ap.confirmCompanyPW(context, pw);
              if (result) {
                _ap.worker.auth = Worker.Auth.COM_MANAGER_2;
                _ap.updateWorkerInfo(context);
                return ToolBox.showToast("관리 권한이 변경되었습니다. 다시 시도하세요.");
              } else {
                return ToolBox.showToast("비밀번호가 일치하지 않습니다.");
              }
            } else {
              return;
            }
          } else {
            return;
          }
        }
      }

      if (newPage != null) {
        ToolBox.pushPage(_context, text, newPage);
      } else {
        ToolBox.showToast("준비중입니다.");
      }
    };

    double _width = 300.w;
    double _height = 300.w;
    return (isVisible)
        ? InkWell(
            child: Container(
              width: _width,
              height: _height,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30.w),
              ),
              child: Column(
                children: [
                  Expanded(
                    child: Icon(
                      iconData,
                      size: 150.w,
                      color: Colors.cyan,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: 40.w),
                    child: Text(
                      text,
                      style: TextStyle(
                          fontSize: 42.w, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
            onTap: onTap,
          )
        : Container(
            width: _width,
            height: _height,
          );
  }
}
