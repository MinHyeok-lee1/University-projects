import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:oasis_app/model/company.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class SearchCompanyPage extends StatefulWidget {
  final bool isComName;
  final String companyInfo;

  SearchCompanyPage(this.isComName, this.companyInfo);

  @override
  State<StatefulWidget> createState() => SearchCompanyPageState();
}

class SearchCompanyPageState extends State<SearchCompanyPage> {
  AppProvider _ap;

  TextEditingController teComCon = TextEditingController();
  List<Company> companyList;

  @override
  void initState() {
    super.initState();
    if (widget.companyInfo != "N/A") {
      teComCon.text = widget.companyInfo;
    }
  }

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return Scaffold(
      appBar: WidgetBox.appBar("사업자 검색"),
      body: Column(
        children: [
          _inputArea(),
          _companyListArea(),
        ],
      ),
    );
  }

  Widget _inputArea() {
    return Container(
      child: WidgetBox.tileSearch(
        (widget.isComName) ? "상호명" : "사업자번호",
        teComCon,
        textInputType:
            (widget.isComName) ? TextInputType.text : TextInputType.number,
        onPressed: () async {
          if (teComCon.text.isEmpty) {
            ToolBox.showToast("검색어를 입력하세요");
            return;
          } else if (teComCon.text.length < 2) {
            if (widget.isComName) {
              ToolBox.showToast("두 글자 이상 입력하세요");
            } else {
              ToolBox.showToast("형식에 맞는 사업자 번호를 입력하세요.");
            }
            return;
          }
          FocusScope.of(context).unfocus();
          ResPayload payload;
          if (widget.isComName) {
            payload = await _ap.findCompanies(context,teComCon.text, null);
          } else {
            payload = await _ap.findCompanies(context,null, teComCon.text);
          }

          logger.d(payload);
          if (payload.result) {
            setState(() {
              companyList = payload.dataList.map((e) {
                return Company.fromMap(e);
              }).toList();
            });
          } else {
            setState(() {
              companyList = [];
            });
          }
        },
      ),
    );
  }

  Widget _companyListArea() {
    return Expanded(
      child: (companyList == null)
          ? Container()
          : (companyList.length == 0)
              ? Container(
                  alignment: Alignment.center,
                  child: Text(
                    "검색결과가 업습니다.",
                    style: WidgetBox.tsNormal,
                  ),
                )
              : Column(
                  children: [
                    Container(
                      margin:
                          const EdgeInsets.only(top: 30, bottom: 10, left: 20),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "검색된 업체",
                        style: WidgetBox.tsTileKey,
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: companyList.length,
                        itemBuilder: (BuildContext context, int index) {
                          Company company = companyList[index];
                          return InkWell(
                            onTap: () {
                              Navigator.pop(context, company);
                            },
                            child: Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 10),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              decoration: BoxDecoration(
                                color: Colors.grey[100],
                                border: Border.all(
                                    color: Colors.grey[400], width: 1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        WidgetBox.tileItemVertical(
                                            "상호명", company.comName),
                                        WidgetBox.tileItemVertical("사업자번호",
                                            company.comNumber.toString()),
                                        WidgetBox.tileItemVertical(
                                            "대표자", company.name),
                                        WidgetBox.tileItemVertical(
                                            "전화번호", company.phoneNumber),
                                      ],
                                    ),
                                  ),
                                  Icon(Icons.check_box_outline_blank),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}
