import 'package:flutter/material.dart';
import 'package:oasis_app/model/history.dart';
import 'package:oasis_app/pages/history/history_area.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class HistoryListArea extends StatefulWidget {
  @override
  _HistoryListAreaState createState() => _HistoryListAreaState();
}

class _HistoryListAreaState extends State<HistoryListArea> {
  AppProvider _ap;

  var refreshKey = GlobalKey<RefreshIndicatorState>();
  ScrollController _controller = ScrollController();

  List<History> historyList = [];
  int selectedPage = 0;
  bool isEnd = false;
  bool isCommunication = false;

  @override
  void initState() {
    super.initState();
    _controller.addListener(() {
      if (_controller.position.atEdge) {
        if (_controller.position.pixels == 0) {
          // logger.d("top");
          // refreshList(isFirst: true);
        } else {
          // logger.d("bottom");
          refreshList(isFirst: false);
        }
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      refreshList(isFirst: true);
    });
  }

  Future<Null> refreshList({bool isFirst = false}) async {
    refreshKey.currentState?.show(atTop: true);

    if (isFirst) {
      selectedPage = 0;
      isEnd = false;
      setState(() {
        isCommunication = true;
      });
      historyList = await _ap.findHistories(context, selectedPage++);
      setState(() {
        isCommunication = false;
      });
    } else {
      if (isEnd == true) {
        return;
      }
      setState(() {
        isCommunication = true;
      });
      List<History> list = await _ap.findHistories(context, selectedPage++);
      setState(() {
        isCommunication = false;
      });
      if (list.length == 0) {
        isEnd = true;
      } else {
        for (History history in list) {
          historyList.add(history);
        }
      }
    }

    logger.d(historyList.length);
    setState(() {});

    return null;
  }

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return Stack(
      children: [
        ListView.builder(
          controller: _controller,
          itemCount: historyList?.length,
          itemBuilder: (context, index) {
            History history = historyList[index];
            return historyWidget(history);
          },
        ),
        (isCommunication)
            ? Center(child: WidgetBox.loadingWidget(title: "통신중"))
            : Container(),
      ],
    );
  }

  Widget historyWidget(History history) {
    return WidgetBox.infoWidget(
      marginVer: 2,
      marginHor: 2,
      child: InkWell(
        onTap: () => ToolBox.pushPage(context, "소독이력", HistoryArea(history)),
        child: Container(
          child: Row(
            children: [
              Icon(Icons.history),
              Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 5),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          WidgetBox.valueItem(history.strEndTime() ?? "N/A"),
                          WidgetBox.valueItem(history.workerName ?? "N/A"),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.only(top: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.cyan[200],
                                borderRadius: BorderRadius.circular(10),
                              ),
                              padding: const EdgeInsets.symmetric(
                                  vertical: 10, horizontal: 10),
                              child: WidgetBox.keyItem(
                                history.carNumber ?? "N/A",
                                fontSize: 18,
                              ),
                            ),
                            (history.course != null)
                                ? Container(
                                    decoration: BoxDecoration(
                                      color: Colors.blue,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 10, horizontal: 10),
                                    child: WidgetBox.keyItem(
                                        history.strCourseName(),
                                        fontSize: 18,
                                        color: Colors.white))
                                : Container(),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Icon(Icons.arrow_forward_ios_outlined),
            ],
          ),
        ),
      ),
    );
  }
}
