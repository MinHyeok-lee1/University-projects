import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:oasis_app/model/history.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';
import 'package:share/share.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HistoryArea extends StatefulWidget {
  final History history;

  HistoryArea(this.history);

  @override
  _HistoryAreaState createState() => _HistoryAreaState();
}

class _HistoryAreaState extends State<HistoryArea> {
  AppProvider _ap;

  History _history;

  bool isCommunicating = false;

  List<charts.Series<PpmItem, int>> stackedValueList = [];
  int chartIndex = 0;

  @override
  void initState() {
    super.initState();
    stackedValueList.add(
      charts.Series<PpmItem, int>(
        id: "o3",
        colorFn: (_, __) => charts.MaterialPalette.blue.shadeDefault,
        domainFn: (PpmItem item, _) => item.index,
        measureFn: (PpmItem item, _) => item.ppm,
        data: [],
      ),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Future.delayed(Duration(seconds: 1), _getHistoryFromServer);
      _getHistoryFromServer();
    });
  }

  void _getHistoryFromServer() async {
    setState(() {
      isCommunicating = true;
    });
    _history = await _ap.findHistory(context, widget.history.id);

    logger.d(_history.processData?.length);
    if (_history.processData.length > 0) {
      for (double value in _history.processData) {
        stackedValueList[0].data.add(PpmItem(++chartIndex, value));
      }
    }
    setState(() {
      isCommunicating = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return (isCommunicating)
        ? Center(child: WidgetBox.loadingWidget(title: "통신 중"))
        : ListView(
            children: [
              _carInfoWidget(),
              WidgetBox.infoWidget(child: ValueChart(stackedValueList)),
              (kDebugMode) ? _processInfoWidget() : Container(),
              _detailInfoWidget(),
              _qrCodeLinkWidget(),
            ],
          );
  }

  Widget _carInfoWidget() {
    return WidgetBox.infoWidget(
      child: WidgetBox.tileItemVertical("차량번호", _history?.carNumber ?? "N/A"),
    );
  }

  Widget _processInfoWidget() {
    return WidgetBox.infoWidget(
      child: Column(
        children: [
          WidgetBox.tileItemVertical("소독 결과", _history?.strResult() ?? "N/A"),
        ],
      ),
    );
  }

  Widget _detailInfoWidget() {
    List<Widget> children = [
      WidgetBox.tileItemVertical("소독 일자", _history?.strEndTime() ?? "N/A"),
      WidgetBox.tileItemVertical("공정 코스", _history?.strCourseName() ?? "N/A"),
      WidgetBox.tileItemVertical("소요 시간", _history?.strReqTime() ?? "N/A"),
      WidgetBox.tileItemVertical("작업자명", _history?.workerName ?? "N/A"),
      WidgetBox.tileItemVertical(
          "최대 농도", _history?.maximumPPM?.toString() ?? "N/A"),
      WidgetBox.tileItemVertical(
          "최종 농도", _history?.finishPPM?.toString() ?? "N/A"),
      WidgetBox.tileItemVertical("소독기 모델", _history?.deviceName ?? "N/A"),
      WidgetBox.tileItemVertical("소독기 별칭", _history?.deviceNickName ?? "N/A"),
      WidgetBox.tileItemVertical("F/W 버전", _history?.fwVersion ?? "N/A"),
    ];
    if (kDebugMode) {
      children.add(
          WidgetBox.tileItemVertical("발생", _history?.strGenResult() ?? "N/A"));
      children.add(
          WidgetBox.tileItemVertical("유지", _history?.strStayResult() ?? "N/A"));
      children.add(WidgetBox.tileItemVertical(
          "회수", _history?.strReleaseResult() ?? "N/A"));
    }
    return WidgetBox.infoWidget(
      child: Column(children: children),
    );
  }

  Widget _qrCodeLinkWidget() {
    // String link = "${_ap.qrCodeUrl}?cn=${_history.carNumber}";
    String link = "${_ap.publishUrl}&hid=${_history?.id}";
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        WidgetBox.elButton(
          title: "웹에서 확인",
          width: 300.w,
          onPressed: () async {
            if (await canLaunch(link)) {
              await launch(link);
            }
          },
        ),
        WidgetBox.elButton(
          title: "공유",
          width: 300.w,
          onPressed: () async {
            Share.share(
                '차량용 소독기 오아시스(OASIS)의 소독공정이 완료되었습니다.\n 공정 결과를 확인하세요.\n $link');
          },
        ),
      ],
    );
  }
}

// ignore: must_be_immutable
class ValueChart extends StatelessWidget {
  List<charts.Series<PpmItem, int>> stackedValueList;

  ValueChart(this.stackedValueList);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      child: (stackedValueList[0].data.length > 0)
          ? charts.LineChart(
              stackedValueList,
              animate: false,
              defaultRenderer: new charts.LineRendererConfig(),
              // Custom renderer configuration for the point series.
              customSeriesRenderers: [
                new charts.PointRendererConfig(
                    // ID used to link series to this renderer.
                    customRendererId: 'customPoint')
              ],
              primaryMeasureAxis: new charts.NumericAxisSpec(
                  renderSpec: new charts.SmallTickRendererSpec(
                      // Tick and Label styling here.
                      )),
            )
          : Center(
              child: Text(
                "공정 데이터가 수집되지 않았습니다.",
                style: WidgetBox.tsTileValue,
              ),
            ),
    );
  }
}

class PpmItem {
  final int index;
  final double ppm;

  PpmItem(this.index, this.ppm);

  @override
  String toString() {
    return "$index / $ppm";
  }
}
