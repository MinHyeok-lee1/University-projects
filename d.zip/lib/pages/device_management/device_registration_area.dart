import 'package:flutter/material.dart';
import 'package:oasis_app/model/device.dart';
import 'package:oasis_app/pages/common_page/edit_info_page.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/providers/ble_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class DeviceRegistrationArea extends StatefulWidget {
  Oasis oasis;

  DeviceRegistrationArea(this.oasis);

  @override
  _DeviceRegistrationAreaState createState() => _DeviceRegistrationAreaState();
}

class _DeviceRegistrationAreaState extends State<DeviceRegistrationArea> {
  AppProvider _ap;
  BleProvider _bp; // 화면 재구성용으로 필요

  String nickName;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    widget.oasis.connect();
  }

  @override
  void dispose() async {
    widget.oasis.disconnect();
    _bp.doNotAnything();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    _bp = Provider.of<BleProvider>(context);
    // logger.d(widget.oasis.processSetting.ver);

    return Column(
      children: [
        Expanded(
          child: ListView(
            // crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              WidgetBox.itemTitle("장비 정보"),
              WidgetBox.tileItem("모델명", widget.oasis.device.name ?? "N/A"),
              WidgetBox.tileItem("MAC 어드레스", widget.oasis.device.id.id),
              WidgetBox.tileItem(
                  "F/W 버전", widget.oasis.processSetting.ver ?? "조회중"),
              WidgetBox.tileItem(
                "별칭",
                nickName ?? "N/A",
                onPressed: _editNickName,
                iconData: Icons.edit,
              ),
              (widget.oasis.processSetting.ver == null)
                  ? Container(
                      alignment: Alignment.center,
                      child: WidgetBox.loadingWidget(title: "통신 중"),
                    )
                  : Container(),
            ],
          ),
        ),
        _registerDevice(),
      ],
    );
  }

  // 장비의 닉네임을 변경함
  void _editNickName() async {
    var result = await ToolBox.pushPage(
        context,
        "별칭 수정",
        EditInfoPage(
          "별칭",
          nickName ?? "N/A",
          isAllowEmpty: true,
        ));
    if (result != null) {
      setState(() {
        nickName = result;
      });
    }
  }

  Widget _registerDevice() {
    GestureTapCallback onPressed;
    if (widget.oasis.processSetting.ver != null) {
      Device device = Device(
        comID: _ap.company.id,
        model: widget.oasis.device.name.trim(),
        MAC: widget.oasis.device.id.id,
        version: widget.oasis.processSetting.ver,
        nickName: nickName,
      );

      onPressed = () async {
        ResPayload payload = await _ap.registerDevice(context, device);
        if (payload.error != ResPayload.TOKEN_ERROR) {
          Navigator.pop(context);
        }
      };
    }

    return WidgetBox.elButton(title: "등록", onPressed: onPressed);
  }
}
