import 'package:flutter/material.dart';
import 'package:oasis_app/model/device.dart';
import 'package:oasis_app/pages/device_management/device_management_area.dart';
import 'package:oasis_app/pages/device_management/scanned_device_list_area.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class RegisteredDeviceListArea extends StatefulWidget {
  @override
  _RegisteredDeviceListAreaState createState() =>
      _RegisteredDeviceListAreaState();
}

class _RegisteredDeviceListAreaState extends State<RegisteredDeviceListArea> {
  AppProvider _ap;

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return Scaffold(
      body: ListView.builder(
        itemCount: _ap.deviceList.length,
        itemBuilder: (context, index) {
          Device device = _ap.deviceList[index];
          return _deviceWidget(device);
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _scanUnRegDevices,
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _deviceWidget(Device device) {
    String title = device.model;
    if (device.nickName != null && device.nickName.isNotEmpty) {
      title = device.nickName;
    }
    return WidgetBox.infoWidget(
      marginVer: 3,
      marginHor: 5,
      paddingLeft: 10,
      paddingRight: 0,
      child: InkWell(
        onTap: () async {
          ToolBox.pushPage(context, "장비 관리", DeviceManagementArea(device));
        },
        child: Row(
          children: [
            Container(
              width: 50,
              child: Icon(
                Icons.devices,
                color: Colors.black54,
                size: 30,
              ),
            ),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  WidgetBox.keyItem(title, marginVer: 5, fontSize: 20),
                  WidgetBox.valueItem(device.MAC, marginVer: 2),
                ],
              ),
            ),
            IconButton(
              icon: Icon(Icons.arrow_forward_ios_rounded),
              onPressed: null,
            )
          ],
        ),
      ),
    );
  }

  // 등록되지 않은 장비를 검색하여 추가
  void _scanUnRegDevices() {
    ToolBox.pushPage(context, "장비 검색", ScannedDeviceListArea());
  }
}
