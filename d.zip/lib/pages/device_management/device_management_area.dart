import 'package:flutter/material.dart';
import 'package:oasis_app/model/device.dart';
import 'package:oasis_app/pages/common_page/edit_info_page.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class DeviceManagementArea extends StatefulWidget {
  final Device device;

  DeviceManagementArea(this.device);

  @override
  _DeviceManagementAreaState createState() => _DeviceManagementAreaState();
}

class _DeviceManagementAreaState extends State<DeviceManagementArea> {
  AppProvider _ap;

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return ListView(
      children: [
        WidgetBox.itemTitle("장비 정보"),
        WidgetBox.tileItem(
          "별칭",
          widget.device.nickName ?? "N/A",
          onPressed: _editNickName,
          iconData: Icons.edit,
        ),
        WidgetBox.tileItem("MAC 어드레스", widget.device.MAC),
        WidgetBox.tileItem("모델명", widget.device.model),
        WidgetBox.tileItem("F/W 버전", widget.device.version),
        WidgetBox.tileItem("등록일", widget.device.strCreateTime()),
        WidgetBox.tileItem("수정일", widget.device.strUpdateTime()),
        WidgetBox.itemTitle("장비 설정"),
        WidgetBox.tileItem(
          "장비 삭제",
          "이 장비를 서버에서 삭제합니다.",
          onPressed: _deleteDevice,
          iconData: Icons.delete,
        ),
      ],
    );
  }

  // 장비의 닉네임을 변경함
  void _editNickName() async {
    var result = await ToolBox.pushPage(
        context,
        "별칭 수정",
        EditInfoPage(
          "별칭",
          widget.device.nickName ?? "N/A",
          isAllowEmpty: true,
        ));
    if (result != null) {
      _ap.updateDeviceNickName(context,widget.device.id, result);
      setState(() {
        widget.device.nickName = result;
      });
    }
  }

  // 장비를 삭제함
  void _deleteDevice() async{
    bool result = await WidgetBox.showTrueFalseDialog(
      context,
      "장비삭제",
      "정말로 장비를 삭제하시겠습니까?",
    );
    if (!result) {
      return;
    }

    ResPayload payload = await _ap.deleteDevice(context,widget.device.id, widget.device.MAC);
    if (payload.error != ResPayload.TOKEN_ERROR) {
      Navigator.pop(context);
    }
  }
}
