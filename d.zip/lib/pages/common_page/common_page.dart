// import 'package:connectivity/connectivity.dart';
import 'package:app_settings/app_settings.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';
import 'package:flutter_blue/flutter_blue.dart' as BLE;

class CommonPage extends StatefulWidget {
  final String title;
  final Widget bodyWidget;

  CommonPage(
    this.bodyWidget, {
    this.title,
  });

  @override
  State<StatefulWidget> createState() => CommonPageState();
}

class CommonPageState extends State<CommonPage> {
  AppProvider _ap;

  @override
  Widget build(BuildContext context) {
    // printScreenInformation();
    _ap = Provider.of<AppProvider>(context);
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: (widget.title != null) ? WidgetBox.appBar(widget.title) : null,
      body: (_ap.conState == ConnectivityResult.none ||
              _ap.btState != BLE.BluetoothState.on)
          ? ConnectivityOffScreen()
          : widget.bodyWidget,
    );
  }

  void printScreenInformation() {
    print('Device width dp:${1.sw}dp');
    print('Device height dp:${1.sh}dp');
    print('Device pixel density:${ScreenUtil().pixelRatio}');
    print('Bottom safe zone distance dp:${ScreenUtil().bottomBarHeight}dp');
    print('Status bar height dp:${ScreenUtil().statusBarHeight}dp');
    print('The ratio of actual width to UI design:${ScreenUtil().scaleWidth}');
    print(
        'The ratio of actual height to UI design:${ScreenUtil().scaleHeight}');
    print('System font scaling:${ScreenUtil().textScaleFactor}');
    print('0.5 times the screen width:${0.5.sw}dp');
    print('0.5 times the screen height:${0.5.sh}dp');
    print('Screen orientation:${ScreenUtil().orientation}');
  }
}

// 블루투스가 비활성화 상태일 때 출력되는 스크린
class BluetoothOffScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(
              Icons.bluetooth_disabled,
              size: 200.0,
              color: Colors.white54,
            ),
            Text(
              '블루투스를 켜주세요.',
              style: TextStyle(fontSize: 20, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

// 네트워크가 비활성화일 때 출력되는 스크린
class ConnectivityOffScreen extends StatelessWidget {
  AppProvider _ap;

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return Scaffold(
      backgroundColor: Colors.lightBlue,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(
              (_ap.conState == ConnectivityResult.none)
                  ? Icons.signal_cellular_connected_no_internet_4_bar
                  : Icons.bluetooth_disabled,
              size: 200.0,
              color: Colors.white54,
            ),
            Text(
              (_ap.conState == ConnectivityResult.none)
                  ? '인터넷 연결이 필요합니다.'
                  : "블루투스 활성화가 필요합니다.",
              style: TextStyle(fontSize: 20, color: Colors.white),
            ),
            (_ap.conState == ConnectivityResult.none)
                ? WidgetBox.elButton(
                    title: "Wi-Fi 활성화",
                    onPressed: () {
                      AppSettings.openWIFISettings();
                    })
                : (_ap.btState == BLE.BluetoothState.off)
                    ? WidgetBox.elButton(
                        title: "Bluetooth 활성화",
                        onPressed: () {
                          AppSettings.openBluetoothSettings();
                        })
                    : Container()
          ],
        ),
      ),
    );
  }
}
