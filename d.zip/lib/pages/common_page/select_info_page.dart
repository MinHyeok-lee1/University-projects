import 'package:flutter/material.dart';
import 'package:oasis_app/tool_box/widget_box.dart';

class SelectInfoPage extends StatefulWidget {
  final String infoTitle;
  final int info;
  final List<String> list;
  final bool isNumberOnly;
  final bool isAllowEmpty;

  SelectInfoPage(
    this.infoTitle,
    this.info,
    this.list, {
    this.isNumberOnly = false,
    this.isAllowEmpty = false,
  });

  @override
  _SelectInfoPageState createState() => _SelectInfoPageState();
}

class _SelectInfoPageState extends State<SelectInfoPage> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: widget.list.length,
      itemBuilder: (context, index) {
        return WidgetBox.infoWidget(
          marginVer: 3,
          marginHor: 5,
          paddingLeft: 20,
          paddingRight: 20,
          color: (widget.info == index) ? Colors.lightBlue : null,
          child: InkWell(
            onTap: () {
              Navigator.pop(context, index);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    widget.list[index],
                    style: WidgetBox.tsTileKey,
                  ),
                  Icon(
                    (widget.info == index)
                        ? Icons.check_box
                        : Icons.check_box_outline_blank_outlined,
                    color:
                        (widget.info == index) ? Colors.white : Colors.black54,
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
