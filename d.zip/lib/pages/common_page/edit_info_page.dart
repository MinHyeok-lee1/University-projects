import 'package:flutter/material.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';

class EditInfoPage extends StatefulWidget {
  final String infoTitle;
  final bool isNumberOnly;
  final bool isAllowEmpty;
  final String info;

  EditInfoPage(
    this.infoTitle,
    this.info, {
    this.isNumberOnly = false,
    this.isAllowEmpty = false,
  });

  @override
  State<StatefulWidget> createState() => EditInfoPageState();
}

class EditInfoPageState extends State<EditInfoPage> {
  TextEditingController teCon = TextEditingController();

  void initState() {
    super.initState();
    if (widget.info != "N/A") {
      teCon.text = widget.info;
    }
  }

  @override
  Widget build(BuildContext context) {
    return WidgetBox.editItem(
      widget.infoTitle,
      teCon,
      onPressed: _popPage,
      textInputType: (widget.isNumberOnly) ? TextInputType.number : null,
    );
  }

  void _popPage() {
    if (widget.isAllowEmpty == false && teCon.text.isEmpty) {
      teCon.text = widget.info;
      return ToolBox.showToast("텍스트를 입력하세요");
    }
    Navigator.pop(context, teCon.text);
  }
}
