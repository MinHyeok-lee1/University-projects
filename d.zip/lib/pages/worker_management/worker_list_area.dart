import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:oasis_app/model/worker.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class WorkerListArea extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _WorkerListAreaState();
}

class _WorkerListAreaState extends State<WorkerListArea> {
  AppProvider _ap;

  bool isCommunicating = false;
  bool isSelectedAll = false;

  List<Worker> workerList = [];
  List<Worker> newWorkerList = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      getWorkerListFromServer();
    });
  }

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);

    return Stack(
      children: [
        Column(
          children: [
            filterButtonsArea(),
            Expanded(
              child: ListView(
                  children: (isSelectedAll)
                      ? workerList
                          .map((worker) => workerWidget(worker))
                          .toList()
                      : newWorkerList
                          .map((worker) => workerWidget(worker))
                          .toList()),
            ),
          ],
        ),
        Center(child: WidgetBox.loadingWidget(isShowing: isCommunicating)),
      ],
    );
  }

  Widget filterButtonsArea() {
    return Container(
      child: Row(
        children: [
          WidgetBox.elButton(
              title: "승인요청",
              isEnabled: !isSelectedAll,
              onPressed: filterButtonsReqAuth,
              width: 250.w),
          WidgetBox.elButton(
              title: "전체",
              isEnabled: isSelectedAll,
              onPressed: filterButtonsAll,
              width: 250.w),
        ],
      ),
    );
  }

  Widget workerWidget(Worker worker) {
    if ((worker.id == _ap.worker.id)) return Container();
    return WidgetBox.areaContainer(
      Column(
        children: [
          Row(
            children: [
              Expanded(
                  child: Text(
                worker.name,
                style: WidgetBox.tsNormal,
              )),
              Container(
                alignment: Alignment.center,
                width: 200.w,
                child: Text("관리자 권한"),
              ),
              Container(
                alignment: Alignment.center,
                width: 200.w,
                child: Text("사용 승인"),
              ),
            ],
          ),
          Container(
            padding: EdgeInsets.only(top: 20.w),
            child: Row(
              children: [
                Expanded(child: Text("가입일: ${worker.strCreateTime()}")),
                Container(
                  alignment: Alignment.center,
                  width: 200.w,
                  child: Switch(
                    value: (worker.auth == Worker.Auth.MK_ADMIN_0 ||
                            worker.auth == Worker.Auth.COM_MANAGER_2)
                        ? true
                        : false,
                    onChanged: (value) => updateWorkerAuth(worker, value),
                  ),
                ),
                Container(
                  alignment: Alignment.center,
                  width: 200.w,
                  child: Switch(
                    value: worker.activated,
                    onChanged: (value) => updateWorkerActivation(worker, value),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Logics

  void getWorkerListFromServer() async {
    workerList = await _ap.findWorkers(context);
    newWorkerList.clear();
    workerList.forEach((Worker worker) {
      if (worker.activated == false) {
        newWorkerList.add(worker);
      }
    });
    setState(() {});
  }

  void updateWorkerList(Worker worker) {
    for (int i = 0; i < workerList.length; i++) {
      if (workerList[i].id == worker.id) {
        workerList[i] = worker;
        break;
      }
    }
    for (int i = 0; i < newWorkerList.length; i++) {
      if (newWorkerList[i].id == worker.id) {
        newWorkerList[i] = worker;
        break;
      }
    }
  }

  void filterButtonsReqAuth() {
    setState(() {
      isSelectedAll = false;
    });
  }

  void filterButtonsAll() {
    setState(() {
      isSelectedAll = true;
    });
  }

  void updateWorkerAuth(Worker worker, bool value) async {
    logger.d("권한: $value");
    if (value == false) {
      worker.auth = Worker.Auth.COM_WORKER_1;
    } else {
      if (_ap.worker.auth == Worker.Auth.MK_ADMIN_0) {
        worker.auth = Worker.Auth.MK_ADMIN_0;
      } else {
        worker.auth = Worker.Auth.COM_MANAGER_2;
      }
    }
    await _ap.updateWorkerInfo(context, otherWorker: worker);
    updateWorkerList(worker);
    setState(() {});
  }

  void updateWorkerActivation(Worker worker, bool value) async {
    worker.activated = value;
    await _ap.updateWorkerInfo(context, otherWorker: worker);
    updateWorkerList(worker);
    setState(() {});
  }
}
