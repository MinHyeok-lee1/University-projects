import 'dart:async';
import 'package:flutter/material.dart';
import 'package:oasis_app/pages/menu_area.dart';
import 'package:oasis_app/pages/sign/sign_up_area.dart';
import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:package_info/package_info.dart';
import 'package:provider/provider.dart';
import 'package:sign_button/constants.dart';
import 'package:sign_button/create_button.dart';

class SignInArea extends StatefulWidget {
  final int delaySec;

  SignInArea({this.delaySec = 3});

  @override
  State<StatefulWidget> createState() => SignInAreaState();
}

class SignInAreaState extends State<SignInArea> {
  AppProvider _ap;

  bool _showSignInButton = false;

  Timer loginTimer;

  String verInfo = "";

  @override
  void initState() {
    super.initState();
    _getAppInfo();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      loginTimer = Timer(Duration(seconds: widget.delaySec), () => initPage());
    });
  }

  void _getAppInfo() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String version = packageInfo.version;
    setState(() {
      verInfo = "$version";
    });
  }

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    if (_ap.currentUser != null && loginTimer?.isActive == true) {
      loginTimer.cancel();
      initPage();
    }

    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            logArea(),
            signInButton(),
          ],
        ),
      ),
    );
  }

  Widget logArea() {
    return Expanded(
      child: Container(
        alignment: Alignment.center,
        margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        child: Image.asset("assets/images/oasis.png"),
      ),
    );
  }

  Widget signInButton() {
    return (_showSignInButton)
        ? Container(
            height: 100,
            padding: const EdgeInsets.symmetric(vertical: 15),
            child: SignInButton(
                // padding: 10,
                buttonType: ButtonType.google,
                buttonSize: ButtonSize.medium,
                btnText: "구글 계정으로 로그인",
                onPressed: _signIn),
          )
        : Container(
            height: 100,
            child: Container(
              alignment: Alignment.bottomCenter,
              padding: const EdgeInsets.only(bottom: 20),
              child: Text(verInfo),
            ),
          );
  }

  void _signIn() async {
    // 구글 로그인 시작

    if (_ap.currentUser == null) {
      bool result = await _ap.signInGoogle();
      if (result == false) {
        return ToolBox.showToast("구글 계정으로 로그인에 실패했습니다.");
      }
    }

    // 구글 계정 정보로 서버 로그인 시도

    ResPayload payload;

    try {
      payload = await _ap
          .signInToServer(
            context,
          )
          .timeout(Duration(seconds: 3));

      if (payload.result) {
        payload = await _ap.findMyCompany(
          context,
        );
      }
      if (payload.result) {
        await _ap.findCars(
          context,
        );
        await _ap.findDevices(
          context,
        );
      }
    } on TimeoutException catch (_) {
      return ToolBox.showToast("서버 연결에 실패했습니다. 잠시 후 다시 시도하세요.");
    }

    // 성공하면 메뉴화면으로 이동
    if (payload.result) {
      //ToolBox.replaceNewPage(context, MenuPage(), duration: 1);
      ToolBox.replacePage(context, "서비스 메뉴", MenuArea(), duration: 1);
    }
    // 가입되지 않은 유저이면 가입 페이지로 이동
    else if (payload.error == ResPayload.NO_SUCH_DATA) {
      var result = await ToolBox.pushPage(context, "회원가입", SignUpArea());

      if (result == null) {
        _ap.signOutGoogle();
      } else if (result) {
        return _signIn();
      }
    }
  }

  void initPage() {
    if (_ap.currentUser != null) {
      _signIn();
    } else {
      setState(() {
        _showSignInButton = true;
      });
    }
  }
}
