import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:oasis_app/model/company.dart';
import 'package:oasis_app/model/worker.dart';
import 'package:oasis_app/pages/common_page/edit_info_page.dart';
import 'package:oasis_app/pages/search_company.dart';

import 'package:oasis_app/providers/app_provider.dart';
import 'package:oasis_app/tool_box/tool_box.dart';
import 'package:oasis_app/tool_box/widget_box.dart';
import 'package:provider/provider.dart';

class SignUpArea extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => SignUpAreaState();
}

class SignUpAreaState extends State<SignUpArea> {
  AppProvider _ap;

  Worker _worker = Worker();
  Company _company = Company();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        _worker.name = _ap.currentUser.displayName;
        _worker.photoURL = _ap.currentUser.photoUrl;
        _worker.email = _ap.currentUser.email;
        _worker.googleID = _ap.currentUser.id;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    _ap = Provider.of<AppProvider>(context);
    return Column(
      children: [
        _formArea(),
        _signUpButton(),
      ],
    );
  }

  Widget _formArea() {
    return Expanded(
      child: ListView(
        // crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          WidgetBox.itemTitle("개인 정보"),
          WidgetBox.tileItem("이름", _worker?.name ?? "N/A",
              onPressed: _editName, iconData: Icons.edit),
          WidgetBox.tileItem("이메일", _worker?.email ?? "N/A"),
          WidgetBox.tileItem(
            "휴대폰번호",
            _worker?.phoneNumber ?? "N/A",
            onPressed: _editPhoneNumber,
            iconData: Icons.edit,
          ),
          WidgetBox.itemTitle("사업체 정보"),
          WidgetBox.tileItem("상호명", _company?.comName ?? "N/A",
              onPressed: () => _searchCompanyInfo(true, _company?.comName),
              iconData: Icons.search),
          WidgetBox.tileItem("사업자번호", _company?.comNumber?.toString() ?? "N/A",
              onPressed: () =>
                  _searchCompanyInfo(false, _company?.comNumber?.toString()),
              iconData: Icons.search),
        ],
      ),
    );
  }

  Widget _signUpButton() {
    return WidgetBox.btWideFull("회원가입", onTap: () async {
      if (_formValidation() != true) {
        return;
      }

      // 서버에 가입 처리
      ResPayload result = await _ap.signUpToServer(context,_worker);

      // 가입에 성공하면 로그인 처리
      if (result.result == true) {
        Navigator.pop(context, true);
      } else {
        ToolBox.showToast("회원가입에 실패했습니다.");
      }
    });
  }

  void _editName() async {
    String result = await ToolBox.pushPage(
      context,
      "이름 수정",
      EditInfoPage("이름", _worker.name),
    );
    if (result != null) {
      setState(() {
        _worker.name = result;
      });
    }
  }

  void _editPhoneNumber() async {
    String result = await ToolBox.pushPage(
        context,
        "휴대폰번호 수정",
        EditInfoPage(
          "휴대폰번호",
          _worker.phoneNumber,
          isNumberOnly: true,
        ));
    if (result != null) {
      setState(() {
        _worker.phoneNumber = result;
      });
    }
  }

  void _searchCompanyInfo(bool isComName, String companyInfo) async {
    Company result = await ToolBox.pushPage(
        context, null, SearchCompanyPage(isComName, companyInfo));
    setState(() {
      _company = result;
      if (result != null) {
        _worker.comID = result.id;
      } else {
        _worker.comID = null;
      }
    });
  }

  // 입력값을 적합성 검증
  bool _formValidation() {
    if (_worker.phoneNumber == null ||
        _worker.phoneNumber.isEmpty ||
        _worker.phoneNumber.length < 10) {
      ToolBox.showToast("유효한 휴대폰번호를 입력하세요");
      return false;
    }
    if (_company?.comName == null || _company.comName.isEmpty) {
      ToolBox.showToast("유효한 사업체 정보를 입력하세요");
      return false;
    }

    return true;
  }
}
